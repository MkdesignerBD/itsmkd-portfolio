#!/bin/bash
# ==============================================================================
# MKD Grid System - 1-Click Automated Installer for macOS
# Compatible with Adobe Illustrator CC 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026+
# ==============================================================================

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
EXT_SRC="$DIR/MKDGridSystem"
TARGET_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/MKDGridSystem"

clear
echo "============================================================"
echo "    🚀 MKD GRID SYSTEM - 1-CLICK macOS INSTALLER"
echo "    MKDESIGNER PRO TOOLKIT • COMMUNITY BETA EDITION"
echo "============================================================"
echo ""

# 1. Check if source folder exists
if [ ! -d "$EXT_SRC" ]; then
    echo "❌ Error: MKDGridSystem folder not found in current directory."
    echo "Please extract the entire zip archive before running this installer."
    read -p "Press [Enter] to exit..."
    exit 1
fi

# 2. Create target directory
echo "📦 [1/3] Preparing Adobe Illustrator Extensions Directory..."
mkdir -p "$HOME/Library/Application Support/Adobe/CEP/extensions"

# 3. Copy Extension Files
echo "📁 [2/3] Installing MKD Grid System files..."
rm -rf "$TARGET_DIR"
cp -R "$EXT_SRC" "$TARGET_DIR"

# 4. Enable Adobe CEP PlayerDebugMode for all Illustrator versions
echo "⚙️  [3/3] Configuring Adobe Illustrator CEP Permissions..."
for v in 9 10 11 12 13 14 15 16 17 18 19 20; do
    defaults write com.adobe.CSXS.$v PlayerDebugMode 1 2>/dev/null
done

echo ""
echo "============================================================"
echo "    🎉 INSTALLATION SUCCESSFUL! "
echo "============================================================"
echo ""
echo "👉 HOW TO OPEN IN ADOBE ILLUSTRATOR:"
echo "   1. Launch (or Restart) Adobe Illustrator."
echo "   2. In the top menu bar, click: Window > Extensions > MKD Grid System"
echo "   3. Enjoy the ultimate Logo Grid & Geometry Studio!"
echo ""
echo "💬 Need help or want to share feedback? Visit https://mkdesigner.com/feedback"
echo "============================================================"
echo ""
read -p "Press [Enter] to finish and close this window..."
