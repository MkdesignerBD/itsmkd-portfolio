@echo off
TITLE MKD Grid System - 1-Click Windows Installer
COLOR 0F
CLS

echo ============================================================
echo     MKD GRID SYSTEM - 1-CLICK WINDOWS INSTALLER
echo     MKDESIGNER PRO TOOLKIT * COMMUNITY BETA EDITION
echo ============================================================
echo.

SET "EXT_SRC=%~dp0MKDGridSystem"
SET "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\MKDGridSystem"

:: Check if source folder exists
IF NOT EXIST "%EXT_SRC%" (
    echo [ERROR] MKDGridSystem folder was not found!
    echo Please extract all files from the zip archive before running.
    echo.
    PAUSE
    EXIT /B 1
)

echo [1/3] Preparing Adobe CEP Extensions directory...
IF NOT EXIST "%APPDATA%\Adobe\CEP\extensions" (
    MKDIR "%APPDATA%\Adobe\CEP\extensions"
)

echo [2/3] Installing MKD Grid System...
IF EXIST "%TARGET_DIR%" (
    RMDIR /S /Q "%TARGET_DIR%"
)
XCOPY "%EXT_SRC%" "%TARGET_DIR%\" /E /I /H /Y >NUL

echo [3/3] Setting Adobe Illustrator CEP permissions in Windows Registry...
FOR /L %%V IN (9,1,20) DO (
    REG ADD "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d "1" /f >NUL 2>&1
)

echo.
echo ============================================================
echo     INSTALLATION SUCCESSFUL!
echo ============================================================
echo.
echo HOW TO OPEN IN ADOBE ILLUSTRATOR:
echo   1. Launch (or Restart) Adobe Illustrator.
echo   2. In the top menu bar, click: Window ^> Extensions ^> MKD Grid System
echo   3. Start creating professional logo grids!
echo.
echo Need help or want to share feedback? Visit https://mkdesigner.com/feedback
echo ============================================================
echo.
PAUSE
