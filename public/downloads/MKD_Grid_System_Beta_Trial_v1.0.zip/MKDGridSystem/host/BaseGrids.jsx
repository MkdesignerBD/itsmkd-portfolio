/**
 * Logo Grid Studio - Base Grids Engine (v3.2 Live Sync Enabled)
 * Parametrically generates Square/Modular, Isometric, Hexagonal, Golden Ratio, and Polar base grids.
 */

var BaseGrids = (function () {
    var self = {};
    var PHI = 1.618033988749895;

    /**
     * Helper to get target bounds [left, top, right, bottom]
     * targetMode: "artboard", "selection", or "custom"
     */
    self.getTargetBounds = function (doc, targetMode, customBounds) {
        if (targetMode === "selection" && doc.selection && doc.selection.length > 0) {
            var l = Infinity, t = -Infinity, r = -Infinity, b = Infinity;
            for (var i = 0; i < doc.selection.length; i++) {
                var gb = doc.selection[i].geometricBounds; // [L, T, R, B]
                if (gb[0] < l) l = gb[0];
                if (gb[1] > t) t = gb[1];
                if (gb[2] > r) r = gb[2];
                if (gb[3] < b) b = gb[3];
            }
            return [l, t, r, b];
        } else if (targetMode === "custom" && customBounds) {
            return customBounds;
        } else {
            // Default to active artboard
            var abIndex = doc.artboards.getActiveArtboardIndex();
            var abRect = doc.artboards[abIndex].artboardRect; // [L, T, R, B]
            return abRect;
        }
    };

    function drawLine(container, p1, p2, styleOptions) {
        var line = container.pathItems.add();
        line.setEntirePath([p1, p2]);
        line.closed = false;
        StyleManager.applyStyle(line, styleOptions);
        return line;
    }

    function drawCircle(container, cx, cy, r, styleOptions) {
        var top = cy + r;
        var left = cx - r;
        var width = r * 2;
        var height = r * 2;
        var circle = container.pathItems.ellipse(top, left, width, height);
        StyleManager.applyStyle(circle, styleOptions);
        return circle;
    }

    /**
     * 1. Modular / Square Grid Generator
     */
    self.generateSquareGrid = function (doc, opts) {
        opts = opts || {};
        var bounds = self.getTargetBounds(doc, opts.targetMode, opts.customBounds);
        var left = bounds[0], top = bounds[1], right = bounds[2], bottom = bounds[3];
        var width = right - left;
        var height = top - bottom;

        var layer = StyleManager.getOrCreateLayer(doc, "[GRID] Base - Modular", opts.style && opts.style.isGuide);
        for (var g = layer.groupItems.length - 1; g >= 0; g--) {
            layer.groupItems[g].remove();
        }

        var group = layer.groupItems.add();
        group.name = "Modular Grid";

        var cols = opts.cols || 8;
        var rows = opts.rows || 8;
        var gutter = opts.gutter || 0;
        var subdivisions = opts.subdivisions || 1;
        var diagonals = !!opts.diagonals;
        var style = opts.style || { colorRgb: [180, 185, 195], strokeWidth: 0.5, opacity: 80 };

        var colWidth = (width - (cols - 1) * gutter) / cols;
        var rowHeight = (height - (rows - 1) * gutter) / rows;

        var outerRect = group.pathItems.rectangle(top, left, width, height);
        StyleManager.applyStyle(outerRect, style);

        for (var c = 0; c < cols; c++) {
            var cLeft = left + c * (colWidth + gutter);
            var cRight = cLeft + colWidth;

            for (var r = 0; r < rows; r++) {
                var rTop = top - r * (rowHeight + gutter);
                var rBottom = rTop - rowHeight;

                if (gutter > 0) {
                    var cellRect = group.pathItems.rectangle(rTop, cLeft, colWidth, rowHeight);
                    StyleManager.applyStyle(cellRect, style);
                }

                if (diagonals) {
                    var diagStyle = {
                        colorRgb: [242, 88, 34],
                        strokeWidth: 0.4,
                        opacity: 60,
                        dashed: true
                    };
                    drawLine(group, [cLeft, rTop], [cRight, rBottom], diagStyle);
                    drawLine(group, [cLeft, rBottom], [cRight, rTop], diagStyle);
                }
            }

            if (gutter === 0 && c > 0) {
                drawLine(group, [cLeft, top], [cLeft, bottom], style);
            }
        }

        if (gutter === 0) {
            for (var r2 = 1; r2 < rows; r2++) {
                var rY = top - r2 * rowHeight;
                drawLine(group, [left, rY], [right, rY], style);
            }
        }

        return group;
    };

    /**
     * 2. Isometric Grid Generator
     */
    self.generateIsometricGrid = function (doc, opts) {
        opts = opts || {};
        var bounds = self.getTargetBounds(doc, opts.targetMode, opts.customBounds);
        var left = bounds[0], top = bounds[1], right = bounds[2], bottom = bounds[3];
        var width = right - left;
        var height = top - bottom;

        var layer = StyleManager.getOrCreateLayer(doc, "[GRID] Base - Isometric", opts.style && opts.style.isGuide);
        for (var g = layer.groupItems.length - 1; g >= 0; g--) {
            layer.groupItems[g].remove();
        }

        var group = layer.groupItems.add();
        group.name = "Isometric Grid";

        var step = opts.step || 20;
        var angleDeg = opts.angle || 30;
        var angleRad = (angleDeg * Math.PI) / 180;
        var tanA = Math.tan(angleRad);
        var style = opts.style || { colorRgb: [180, 185, 195], strokeWidth: 0.5, opacity: 80 };
        var includeVerticals = (opts.includeVerticals !== false);

        var cx = (left + right) / 2;
        var cy = (top + bottom) / 2;

        var hRange = width / 2 + (height / 2) / tanA + 100;
        var startOffset = -Math.ceil(hRange / step) * step;
        var endOffset = Math.ceil(hRange / step) * step;

        for (var offset = startOffset; offset <= endOffset; offset += step) {
            var yAtLeft1 = cy + tanA * (left - (cx + offset));
            var yAtRight1 = cy + tanA * (right - (cx + offset));
            drawLine(group, [left, yAtLeft1], [right, yAtRight1], style);

            var yAtLeft2 = cy - tanA * (left - (cx + offset));
            var yAtRight2 = cy - tanA * (right - (cx + offset));
            drawLine(group, [left, yAtLeft2], [right, yAtRight2], style);
        }

        if (includeVerticals) {
            var vStartOffset = -Math.ceil((width / 2) / step) * step;
            var vEndOffset = Math.ceil((width / 2) / step) * step;
            for (var vx = cx + vStartOffset; vx <= cx + vEndOffset; vx += step) {
                drawLine(group, [vx, top], [vx, bottom], style);
            }
        }

        return group;
    };

    /**
     * 3. Hexagonal Grid Generator
     */
    self.generateHexagonalGrid = function (doc, opts) {
        opts = opts || {};
        var bounds = self.getTargetBounds(doc, opts.targetMode, opts.customBounds);
        var left = bounds[0], top = bounds[1], right = bounds[2], bottom = bounds[3];
        var width = right - left;
        var height = top - bottom;

        var layer = StyleManager.getOrCreateLayer(doc, "[GRID] Base - Hexagonal", opts.style && opts.style.isGuide);
        for (var g = layer.groupItems.length - 1; g >= 0; g--) {
            layer.groupItems[g].remove();
        }

        var group = layer.groupItems.add();
        group.name = "Hexagonal Grid";

        var s = opts.sideLength || 30;
        var style = opts.style || { colorRgb: [180, 185, 195], strokeWidth: 0.5, opacity: 80 };

        var h = s * Math.sqrt(3);
        var colDist = 1.5 * s;
        var rowDist = h;

        var cols = Math.ceil(width / colDist) + 2;
        var rows = Math.ceil(height / rowDist) + 2;

        for (var c = 0; c < cols; c++) {
            var hx = left + c * colDist;
            var offsetY = (c % 2 === 1) ? h / 2 : 0;
            for (var r = 0; r < rows; r++) {
                var hy = top - (r * rowDist + offsetY);
                var hex = group.pathItems.polygon(hy + s, hx, s, 6);
                StyleManager.applyStyle(hex, style);
            }
        }

        return group;
    };

    /**
     * 4. Golden Ratio (Fibonacci) Grid Generator
     */
    self.generateGoldenRatioGrid = function (doc, opts) {
        opts = opts || {};
        var bounds = self.getTargetBounds(doc, opts.targetMode, opts.customBounds);
        var left = bounds[0], top = bounds[1], right = bounds[2], bottom = bounds[3];
        var width = right - left;
        var height = top - bottom;
        var cx = (left + right) / 2;
        var cy = (top + bottom) / 2;

        var layer = StyleManager.getOrCreateLayer(doc, "[GRID] Base - Golden Ratio", opts.style && opts.style.isGuide);
        for (var g = layer.groupItems.length - 1; g >= 0; g--) {
            layer.groupItems[g].remove();
        }

        var group = layer.groupItems.add();
        group.name = "Golden Ratio Grid";

        var style = opts.style || { colorRgb: [180, 185, 195], strokeWidth: 0.6, opacity: 80 };
        var baseDim = Math.min(width, height);

        var circleCount = opts.concentricCount || 6;
        var rBase = (baseDim / 2) / Math.pow(PHI, 2);

        for (var i = 0; i < circleCount; i++) {
            var rIn = rBase / Math.pow(PHI, i);
            var rOut = rBase * Math.pow(PHI, i);

            if (rIn > 2) drawCircle(group, cx, cy, rIn, style);
            if (rOut <= baseDim * 1.2 && i > 0) drawCircle(group, cx, cy, rOut, style);
        }

        var phiLineStyle = { colorRgb: [242, 88, 34], strokeWidth: 0.5, opacity: 70, dashed: true };
        drawLine(group, [left, cy], [right, cy], phiLineStyle);
        drawLine(group, [cx, top], [cx, bottom], phiLineStyle);

        return group;
    };

    /**
     * 5. Polar / Radial Grid Generator
     */
    self.generatePolarGrid = function (doc, opts) {
        opts = opts || {};
        var bounds = self.getTargetBounds(doc, opts.targetMode, opts.customBounds);
        var left = bounds[0], top = bounds[1], right = bounds[2], bottom = bounds[3];
        var width = right - left;
        var height = top - bottom;
        var cx = (left + right) / 2;
        var cy = (top + bottom) / 2;

        var layer = StyleManager.getOrCreateLayer(doc, "[GRID] Base - Polar", opts.style && opts.style.isGuide);
        for (var g = layer.groupItems.length - 1; g >= 0; g--) {
            layer.groupItems[g].remove();
        }

        var group = layer.groupItems.add();
        group.name = "Polar Grid";

        var rings = opts.rings || 8;
        var spokes = opts.spokes || 16;
        var maxR = Math.min(width, height) / 2;
        var style = opts.style || { colorRgb: [180, 185, 195], strokeWidth: 0.5, opacity: 80 };

        for (var r = 1; r <= rings; r++) {
            var radius = (maxR / rings) * r;
            drawCircle(group, cx, cy, radius, style);
        }

        var spokeAngle = (2 * Math.PI) / spokes;
        for (var s = 0; s < spokes; s++) {
            var a = s * spokeAngle;
            var px = cx + maxR * Math.cos(a);
            var py = cy + maxR * Math.sin(a);
            drawLine(group, [cx, cy], [px, py], style);
        }

        return group;
    };

    return self;
})();
