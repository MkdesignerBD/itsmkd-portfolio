/**
 * Logo Grid Studio - Clearspace & Brand Lockup Proportion Engine (v5.0 Pro)
 * Features:
 * - Recursive Leaf Item Extraction (Handles grouped logos & nested compounds)
 * - Exact Video Copilot & WOVEN Standard Clearspace Grid Architecture
 * - In-Grid Spacing Annotations (Corner X, Icon-to-Text Gap X/2, Text-to-Text Gap X/4)
 * - Multi-Mode Spacing Formats: Dual "X/2 (24px)", Pixels "24px", Ratios "X/2"
 * - Multi-Element Hierarchy Level Guides & External Proportion Brackets
 */

var ClearspaceGrids = (function () {
    var self = {};

    function drawLine(container, p1, p2, styleOptions) {
        var line = container.pathItems.add();
        line.setEntirePath([p1, p2]);
        line.closed = false;
        StyleManager.applyStyle(line, styleOptions);
        return line;
    }

    function drawTextLabel(container, textStr, x, y, size, colorRgb) {
        try {
            var tf = container.textFrames.add();
            tf.contents = textStr;
            tf.top = y;
            tf.left = x;
            if (tf.textRange && tf.textRange.characterAttributes) {
                tf.textRange.characterAttributes.size = size || 7.5;
                if (colorRgb) {
                    tf.textRange.characterAttributes.fillColor = StyleManager.createRGBColor(colorRgb);
                }
            }
            return tf;
        } catch (e) {
            return null;
        }
    }

    function drawCenteredCellLabel(container, textStr, left, top, width, height, size, colorRgb) {
        var fontSize = size || Math.min(8.5, Math.max(6.5, height * 0.45));
        var approxTextWidth = textStr.length * fontSize * 0.52;
        var posX = left + (width / 2) - (approxTextWidth / 2);
        var posY = top - (height / 2) + (fontSize * 0.35);
        return drawTextLabel(container, textStr, posX, posY, fontSize, colorRgb);
    }

    function unhideAndUnlockRecursive(item) {
        if (!item) return;
        try { item.hidden = false; } catch (e) {}
        try { item.locked = false; } catch (e) {}
        try {
            if (item.typename === "GroupItem") {
                for (var g = 0; g < item.pageItems.length; g++) {
                    unhideAndUnlockRecursive(item.pageItems[g]);
                }
            } else if (item.typename === "CompoundPathItem") {
                for (var cp = 0; cp < item.pathItems.length; cp++) {
                    unhideAndUnlockRecursive(item.pathItems[cp]);
                }
            }
        } catch (e) {}
    }

    function applyTechnicalGreyToItem(item) {
        if (!item) return;
        var greyColor = StyleManager.createRGBColor([90, 95, 105]);
        unhideAndUnlockRecursive(item);

        try {
            if (item.typename === "PathItem") {
                try {
                    if (!item.filled && !item.stroked) {
                        item.filled = true;
                        item.fillColor = greyColor;
                    } else {
                        if (item.filled) item.fillColor = greyColor;
                        if (item.stroked) item.strokeColor = greyColor;
                    }
                } catch (ePath) {}
                try { item.opacity = 100; } catch (e) {}
            } else if (item.typename === "CompoundPathItem") {
                if (item.pathItems) {
                    for (var p = 0; p < item.pathItems.length; p++) {
                        applyTechnicalGreyToItem(item.pathItems[p]);
                    }
                }
                try { item.opacity = 100; } catch (e) {}
            } else if (item.typename === "GroupItem") {
                if (item.pageItems) {
                    for (var g = 0; g < item.pageItems.length; g++) {
                        applyTechnicalGreyToItem(item.pageItems[g]);
                    }
                }
                try { item.opacity = 100; } catch (e) {}
            } else if (item.typename === "TextFrame") {
                try {
                    if (item.textRange && item.textRange.characterAttributes) {
                        item.textRange.characterAttributes.fillColor = greyColor;
                    }
                } catch (eText) {}
                try { item.opacity = 100; } catch (e) {}
            } else if (item.typename === "PlacedItem" || item.typename === "RasterItem") {
                try { item.opacity = 100; } catch (e) {}
            }
        } catch (e) {}
    }

    /**
     * Draw Corner Box with Custom Icon / Shape / Text (Captured Artboard Vector, Cloned Logomark, SVG, or Custom Glyph)
     * All corner contents are rendered in a clean Technical Monochrome Grey.
     */
    function drawCornerContent(doc, container, left, top, size, cornerType, customChar, svgFilePath, sourceIconItems, styleOptions) {
        var group = container.groupItems.add();
        group.name = "Corner Box";

        // Outer Square Box
        var box = group.pathItems.rectangle(top, left, size, size);
        var bStyle = {
            colorRgb: styleOptions.boxStrokeColor || [74, 144, 226],
            strokeWidth: styleOptions.boxStrokeWidth || 0.75,
            filled: true,
            fillRgb: styleOptions.boxFillColor || [194, 224, 248],
            opacity: (typeof styleOptions.boxOpacity === "number") ? styleOptions.boxOpacity : 50,
            renderMode: "lines"
        };
        StyleManager.applyStyle(box, bStyle);

        var centerX = left + (size / 2);
        var centerY = top - (size / 2);

        // 1. If user selected "Canvas / SVG Vector" (custom_svg) and captured a template or imported SVG:
        if (cornerType === "custom_svg") {
            var templateLayer = null;
            for (var lIdx = 0; lIdx < doc.layers.length; lIdx++) {
                if (doc.layers[lIdx].name === "[GRID_TEMPLATE_CORNER]") {
                    templateLayer = doc.layers[lIdx];
                    break;
                }
            }

            if (templateLayer && templateLayer.pageItems.length > 0) {
                var tSource = templateLayer.pageItems[0];
                var clonedT = null;
                try {
                    clonedT = tSource.duplicate(group, ElementPlacement.PLACEATBEGINNING);
                } catch (eDup) {
                    try { clonedT = tSource.duplicate(group); } catch (eDup2) {}
                }

                if (clonedT) {
                    unhideAndUnlockRecursive(clonedT);
                    applyTechnicalGreyToItem(clonedT);

                    try {
                        var gbT = clonedT.geometricBounds;
                        var curWT = Math.abs(gbT[2] - gbT[0]);
                        var curHT = Math.abs(gbT[1] - gbT[3]);
                        var maxDT = Math.max(curWT, curHT);
                        var targetDT = size * 0.60;

                        if (maxDT > 0.01) {
                            var scaleFactorT = (targetDT / maxDT) * 100;
                            clonedT.resize(scaleFactorT, scaleFactorT);
                        }

                        var newGbT = clonedT.geometricBounds;
                        var nWT = Math.abs(newGbT[2] - newGbT[0]);
                        var nHT = Math.abs(newGbT[1] - newGbT[3]);
                        clonedT.position = [centerX - (nWT / 2), centerY + (nHT / 2)];
                        return group;
                    } catch (errBounds) {}
                }
            }
        }

        // 2. If user selected "Logo Icon / Mark" (use_icon) OR fallback for custom_svg with source icon items:
        if ((cornerType === "use_icon" || cornerType === "custom_svg") && sourceIconItems && sourceIconItems.length > 0) {
            try {
                var iconSubGroup = group.groupItems.add();
                iconSubGroup.name = "Cloned Icon";
                for (var ii = 0; ii < sourceIconItems.length; ii++) {
                    try {
                        var dup = sourceIconItems[ii].duplicate(iconSubGroup, ElementPlacement.PLACEATBEGINNING);
                        unhideAndUnlockRecursive(dup);
                        applyTechnicalGreyToItem(dup);
                    } catch (e) {}
                }

                unhideAndUnlockRecursive(iconSubGroup);
                applyTechnicalGreyToItem(iconSubGroup);

                var gb = iconSubGroup.geometricBounds;
                var curW = Math.abs(gb[2] - gb[0]);
                var curH = Math.abs(gb[1] - gb[3]);
                var maxD = Math.max(curW, curH);
                var targetD = size * 0.60;

                if (maxD > 0.01) {
                    var scaleFactor = (targetD / maxD) * 100;
                    iconSubGroup.resize(scaleFactor, scaleFactor);
                }

                var newGb = iconSubGroup.geometricBounds;
                var nW = Math.abs(newGb[2] - newGb[0]);
                var nH = Math.abs(newGb[1] - newGb[3]);
                iconSubGroup.position = [centerX - (nW / 2), centerY + (nH / 2)];
                return group;
            } catch (e) {}
        }

        // 3. Option: Custom SVG file path
        if (cornerType === "custom_svg" && svgFilePath) {
            try {
                var f = new File(svgFilePath);
                if (f.exists) {
                    var placed = group.placedItems.add();
                    placed.file = f;
                    placed.embed();
                    unhideAndUnlockRecursive(placed);
                    applyTechnicalGreyToItem(placed);

                    var pGb = placed.geometricBounds;
                    var pW = Math.abs(pGb[2] - pGb[0]);
                    var pH = Math.abs(pGb[1] - pGb[3]);
                    var pMax = Math.max(pW, pH);
                    var pTarget = size * 0.60;
                    if (pMax > 0.01) {
                        var pScale = (pTarget / pMax) * 100;
                        placed.resize(pScale, pScale);
                    }
                    var pNewGb = placed.geometricBounds;
                    var pnW = Math.abs(pNewGb[2] - pNewGb[0]);
                    var pnH = Math.abs(pNewGb[1] - pNewGb[3]);
                    placed.position = [centerX - (pnW / 2), centerY + (pnH / 2)];
                    return group;
                }
            } catch (e) {}
        }

        // 4. Default / Custom Character Text (e.g. "X" or custom letter)
        var charStr = (cornerType === "custom_text" && customChar) ? customChar : "X";
        drawCenteredCellLabel(group, charStr, left, top, size, size, Math.max(8.0, size * 0.42), [90, 95, 105]);
        return group;
    }

    self.captureCornerVector = function (doc) {
        if (!doc.selection || doc.selection.length === 0) {
            throw new Error("Please select a vector icon or shape on the artboard first.");
        }

        // 1. Take a fixed snapshot of current selection items before duplicating
        var selSnapshot = [];
        for (var i = 0; i < doc.selection.length; i++) {
            selSnapshot.push(doc.selection[i]);
        }

        if (selSnapshot.length === 0) {
            throw new Error("No selectable vector objects found.");
        }

        // 2. Prepare Template Layer (Keep visible & unlocked so geometry engine works, off-artboard position)
        var tLayer = StyleManager.getOrCreateLayer(doc, "[GRID_TEMPLATE_CORNER]", false);
        tLayer.locked = false;
        tLayer.visible = true;
        tLayer.printable = false;

        for (var p = tLayer.pageItems.length - 1; p >= 0; p--) {
            try { tLayer.pageItems[p].remove(); } catch (e) {}
        }

        var tGroup = tLayer.groupItems.add();
        tGroup.name = "Template_Corner_Vector";

        // 3. Duplicate each item from snapshot without mutating iteration
        for (var s = 0; s < selSnapshot.length; s++) {
            var item = selSnapshot[s];
            try { item.locked = false; } catch (e) {}
            try {
                var dup = item.duplicate(tGroup, ElementPlacement.PLACEATEND);
                try { dup.selected = false; } catch (eSel) {}
                unhideAndUnlockRecursive(dup);
            } catch (eDup) {}
        }

        unhideAndUnlockRecursive(tGroup);
        applyTechnicalGreyToItem(tGroup);

        // Position tGroup outside the active artboard boundary so user doesn't see it
        try {
            var abIndex = doc.artboards.getActiveArtboardIndex();
            var abRect = doc.artboards[abIndex].artboardRect;
            tGroup.left = abRect[2] + 400;
            tGroup.top = abRect[1];
        } catch (ePos) {}

        try { tLayer.locked = true; } catch (eLock) {}

        // Generate a crisp lightweight PNG preview thumbnail for CEP UI
        var thumbPath = "";
        var timestamp = (new Date().getTime());
        try {
            var thumbFile = new File(Folder.temp.fsName + "/mkd_corner_thumb_" + timestamp + ".png");
            var pDoc = app.documents.add(DocumentColorSpace.RGB, 120, 120);
            var clonedPreview = tGroup.duplicate(pDoc.layers[0], ElementPlacement.PLACEATBEGINNING);
            unhideAndUnlockRecursive(clonedPreview);

            var pgb = clonedPreview.geometricBounds;
            var pw = Math.abs(pgb[2] - pgb[0]);
            var ph = Math.abs(pgb[1] - pgb[3]);
            var pmax = Math.max(pw, ph);
            if (pmax > 0.01) {
                var pscale = (84 / pmax) * 100;
                clonedPreview.resize(pscale, pscale);
            }
            var postGb = clonedPreview.geometricBounds;
            var nw = Math.abs(postGb[2] - postGb[0]);
            var nh = Math.abs(postGb[1] - postGb[3]);
            clonedPreview.position = [60 - (nw / 2), 60 + (nh / 2)];

            var expOpts = new ExportOptionsPNG24();
            expOpts.antiAliasing = true;
            expOpts.transparency = true;
            expOpts.artBoardClipping = true;
            pDoc.exportFile(thumbFile, ExportType.PNG24, expOpts);
            pDoc.close(SaveOptions.DONOTSAVECHANGES);
            thumbPath = thumbFile.fsName;
        } catch (eThumb) {}

        return {
            success: true,
            count: selSnapshot.length,
            thumbPath: thumbPath,
            timestamp: timestamp
        };
    };

    self.importCornerSVG = function (doc, svgFilePath) {
        var f = new File(svgFilePath);
        if (!f.exists) throw new Error("SVG file not found on disk: " + svgFilePath);

        var tLayer = StyleManager.getOrCreateLayer(doc, "[GRID_TEMPLATE_CORNER]", false);
        tLayer.locked = false;
        tLayer.visible = true;
        tLayer.printable = false;

        for (var p = tLayer.pageItems.length - 1; p >= 0; p--) {
            try { tLayer.pageItems[p].remove(); } catch (e) {}
        }

        var placed = tLayer.placedItems.add();
        placed.file = f;
        placed.embed();
        unhideAndUnlockRecursive(placed);
        applyTechnicalGreyToItem(placed);

        try {
            var abIndex = doc.artboards.getActiveArtboardIndex();
            var abRect = doc.artboards[abIndex].artboardRect;
            placed.left = abRect[2] + 400;
            placed.top = abRect[1];
        } catch (ePos) {}

        try { tLayer.locked = true; } catch (eLock) {}

        // Generate thumbnail
        var thumbPath = "";
        var timestamp = (new Date().getTime());
        try {
            var thumbFile = new File(Folder.temp.fsName + "/mkd_corner_thumb_" + timestamp + ".png");
            var pDoc = app.documents.add(DocumentColorSpace.RGB, 120, 120);
            var placedPreview = pDoc.layers[0].placedItems.add();
            placedPreview.file = f;
            placedPreview.embed();
            unhideAndUnlockRecursive(placedPreview);
            applyTechnicalGreyToItem(placedPreview);

            var pgb = placedPreview.geometricBounds;
            var pw = Math.abs(pgb[2] - pgb[0]);
            var ph = Math.abs(pgb[1] - pgb[3]);
            var pmax = Math.max(pw, ph);
            if (pmax > 0.01) {
                var pscale = (84 / pmax) * 100;
                placedPreview.resize(pscale, pscale);
            }
            var postGb = placedPreview.geometricBounds;
            var nw = Math.abs(postGb[2] - postGb[0]);
            var nh = Math.abs(postGb[1] - postGb[3]);
            placedPreview.position = [60 - (nw / 2), 60 + (nh / 2)];

            var expOpts = new ExportOptionsPNG24();
            expOpts.antiAliasing = true;
            expOpts.transparency = true;
            expOpts.artBoardClipping = true;
            pDoc.exportFile(thumbFile, ExportType.PNG24, expOpts);
            pDoc.close(SaveOptions.DONOTSAVECHANGES);
            thumbPath = thumbFile.fsName;
        } catch (eThumb) {}

        return {
            success: true,
            path: svgFilePath,
            thumbPath: thumbPath,
            timestamp: timestamp
        };
    };

    /**
     * Draw Vertical Dimension Bracket with horizontal tick caps on top & bottom
     */
    function drawVerticalBracket(container, topY, botY, xPos, labelText, isLeftSide, styleOptions) {
        var group = container.groupItems.add();
        group.name = "Bracket " + labelText;

        var tickLen = 6.0;
        var col = styleOptions.bracketColor || [74, 144, 226];
        var bStyle = {
            colorRgb: col,
            strokeWidth: styleOptions.bracketStrokeWidth || 0.75,
            opacity: (typeof styleOptions.opacity === "number") ? styleOptions.opacity : 90,
            renderMode: "lines"
        };

        // Vertical Spine
        drawLine(group, [xPos, topY], [xPos, botY], bStyle);
        // Top Tick
        drawLine(group, [xPos - tickLen / 2, topY], [xPos + tickLen / 2, topY], bStyle);
        // Bottom Tick
        drawLine(group, [xPos - tickLen / 2, botY], [xPos + tickLen / 2, botY], bStyle);

        // Ratio Label
        var midY = (topY + botY) / 2;
        var fontSize = 7.5;
        var labelX = isLeftSide ? (xPos - 8 - (fontSize * 0.52 * labelText.length)) : (xPos + 8);
        drawTextLabel(group, labelText, labelX, midY + (fontSize * 0.35), fontSize, [50, 55, 65]);
        return group;
    }

    /**
     * Draw Horizontal Dimension Bracket with vertical tick caps on left & right
     */
    function drawHorizontalBracket(container, leftX, rightX, yPos, labelText, isAbove, styleOptions) {
        var group = container.groupItems.add();
        group.name = "Horizontal Spacing " + labelText;

        var tickLen = 6.0;
        var col = styleOptions.bracketColor || [74, 144, 226];
        var bStyle = {
            colorRgb: col,
            strokeWidth: styleOptions.bracketStrokeWidth || 0.75,
            opacity: (typeof styleOptions.opacity === "number") ? styleOptions.opacity : 90,
            renderMode: "lines"
        };

        // Horizontal Spine
        drawLine(group, [leftX, yPos], [rightX, yPos], bStyle);
        // Left Tick
        drawLine(group, [leftX, yPos - tickLen / 2], [leftX, yPos + tickLen / 2], bStyle);
        // Right Tick
        drawLine(group, [rightX, yPos - tickLen / 2], [rightX, yPos + tickLen / 2], bStyle);

        // Ratio Label
        var midX = (leftX + rightX) / 2;
        var fontSize = 7.5;
        var labelY = isAbove ? (yPos + 8 + fontSize * 0.7) : (yPos - 8);
        drawTextLabel(group, labelText, midX - (fontSize * 0.28 * labelText.length), labelY, fontSize, [50, 55, 65]);
        return group;
    }

    /**
     * Format mathematical proportion ratio string (e.g. 1.5X, X, X/2, X/3, X/4)
     */
    function formatRatio(val, baseUnit) {
        if (!baseUnit || baseUnit <= 0) return "X";
        var r = val / baseUnit;
        var rounded = Math.round(r * 10) / 10;

        if (Math.abs(rounded - 1.0) < 0.14) return "X";
        if (Math.abs(rounded - 0.5) < 0.08) return "X/2";
        if (Math.abs(rounded - 0.33) < 0.08) return "X/3";
        if (Math.abs(rounded - 0.25) < 0.08) return "X/4";
        if (Math.abs(rounded - 0.2) < 0.06) return "X/5";
        if (Math.abs(rounded - 0.75) < 0.08) return "0.75X";
        if (Math.abs(rounded - 1.25) < 0.08) return "1.25X";
        if (Math.abs(rounded - 1.5) < 0.08) return "1.5X";
        if (Math.abs(rounded - 2.0) < 0.08) return "2X";
        if (Math.abs(rounded - 2.5) < 0.08) return "2.5X";
        if (Math.abs(rounded - 3.0) < 0.08) return "3X";
        if (Math.abs(rounded - 4.0) < 0.08) return "4X";

        return rounded + "X";
    }

    /**
     * Unified Spacing Formatter (supports Dual "X/2 (24px)", Pixels "24px", and Ratio "X/2")
     */
    function formatSpacing(val, baseUnit, formatMode) {
        formatMode = formatMode || "both";
        var pxVal = Math.round(val);
        var ratioStr = formatRatio(val, baseUnit);

        if (formatMode === "pixels") {
            return pxVal + " px";
        } else if (formatMode === "ratio") {
            return ratioStr;
        } else {
            // "both" -> "X/2 • 24px" or "X • 48px"
            if (ratioStr === "X") return "X • " + pxVal + "px";
            return ratioStr + " • " + pxVal + "px";
        }
    }

    function getBoundsOfItem(item) {
        var gb = item.geometricBounds;
        return {
            left: Math.min(gb[0], gb[2]),
            top: Math.max(gb[1], gb[3]),
            right: Math.max(gb[0], gb[2]),
            bottom: Math.min(gb[1], gb[3]),
            width: Math.abs(gb[2] - gb[0]),
            height: Math.abs(gb[1] - gb[3])
        };
    }

    /**
     * Recursively unnest all items down to leaf paths and sub-groups
     */
    function collectLeafItems(items) {
        var leaves = [];
        if (!items) return leaves;

        for (var i = 0; i < items.length; i++) {
            var it = items[i];
            try {
                if (it.layer && it.layer.name && it.layer.name.indexOf("[GRID]") === 0) continue;
                if (it.name && it.name.indexOf("Clearspace") === 0) continue;
                if (it.parent && it.parent.name && it.parent.name.indexOf("Clearspace") === 0) continue;
            } catch (e) {}

            if (it.typename === "GroupItem") {
                if (it.pageItems && it.pageItems.length > 0) {
                    var subLeaves = collectLeafItems(it.pageItems);
                    for (var s = 0; s < subLeaves.length; s++) {
                        leaves.push(subLeaves[s]);
                    }
                } else {
                    leaves.push(it);
                }
            } else {
                leaves.push(it);
            }
        }
        return leaves;
    }

    /**
     * Advanced 2D Spatial Clustering: Groups selection items into cohesive semantic blocks
     * Separates Left Icon, Top Wordmark line, Bottom Tagline line, etc.
     */
    function clusterLockupBlocks(selection) {
        var leafItems = collectLeafItems(selection);
        if (!leafItems || leafItems.length === 0) return [];

        var rawBlocks = [];
        for (var i = 0; i < leafItems.length; i++) {
            var b = getBoundsOfItem(leafItems[i]);
            if (b.width > 0.5 && b.height > 0.5) {
                rawBlocks.push({ bounds: b, items: [leafItems[i]] });
            }
        }

        // Pass 1: Merge horizontally adjacent items that share the same horizontal baseline (text lines)
        var changed = true;
        while (changed) {
            changed = false;
            for (var i = 0; i < rawBlocks.length; i++) {
                for (var j = i + 1; j < rawBlocks.length; j++) {
                    var b1 = rawBlocks[i].bounds;
                    var b2 = rawBlocks[j].bounds;

                    var yOverlap = Math.min(b1.top, b2.top) - Math.max(b1.bottom, b2.bottom);
                    var minH = Math.min(b1.height, b2.height);
                    var isSameLine = (yOverlap > 0 && (yOverlap / minH) > 0.35);

                    var xDist = (b2.left > b1.right) ? (b2.left - b1.right) :
                                ((b1.left > b2.right) ? (b1.left - b2.right) : 0);

                    if (isSameLine && xDist < 30.0) {
                        rawBlocks[i].items = rawBlocks[i].items.concat(rawBlocks[j].items);
                        rawBlocks[i].bounds = {
                            left: Math.min(b1.left, b2.left),
                            top: Math.max(b1.top, b2.top),
                            right: Math.max(b1.right, b2.right),
                            bottom: Math.min(b1.bottom, b2.bottom),
                            width: Math.max(b1.right, b2.right) - Math.min(b1.left, b2.left),
                            height: Math.max(b1.top, b2.top) - Math.min(b1.bottom, b2.bottom)
                        };
                        rawBlocks.splice(j, 1);
                        changed = true;
                        break;
                    }
                }
                if (changed) break;
            }
        }

        // Pass 2: Merge overlapping parts of an icon (petals/shapes) without merging separate text lines
        changed = true;
        while (changed) {
            changed = false;
            for (var i = 0; i < rawBlocks.length; i++) {
                for (var j = i + 1; j < rawBlocks.length; j++) {
                    var b1 = rawBlocks[i].bounds;
                    var b2 = rawBlocks[j].bounds;

                    var overlapX = !(b1.right + 6 < b2.left || b1.left - 6 > b2.right);
                    var overlapY = !(b1.top + 6 < b2.bottom || b1.bottom - 6 > b2.top);

                    var isStackedText = (Math.abs(b1.left - b2.left) < 35 && Math.abs(b1.right - b2.right) < 35 &&
                                         (b1.bottom >= b2.top - 2 || b2.bottom >= b1.top - 2));

                    if (overlapX && overlapY && !isStackedText) {
                        rawBlocks[i].items = rawBlocks[i].items.concat(rawBlocks[j].items);
                        rawBlocks[i].bounds = {
                            left: Math.min(b1.left, b2.left),
                            top: Math.max(b1.top, b2.top),
                            right: Math.max(b1.right, b2.right),
                            bottom: Math.min(b1.bottom, b2.bottom),
                            width: Math.max(b1.right, b2.right) - Math.min(b1.left, b2.left),
                            height: Math.max(b1.top, b2.top) - Math.min(b1.bottom, b2.bottom)
                        };
                        rawBlocks.splice(j, 1);
                        changed = true;
                        break;
                    }
                }
                if (changed) break;
            }
        }

        var resultBlocks = [];
        for (var bIdx = 0; bIdx < rawBlocks.length; bIdx++) {
            var rb = rawBlocks[bIdx];
            resultBlocks.push({
                left: rb.bounds.left,
                top: rb.bounds.top,
                right: rb.bounds.right,
                bottom: rb.bounds.bottom,
                width: rb.bounds.width,
                height: rb.bounds.height,
                items: rb.items
            });
        }
        return resultBlocks;
    }

    /**
     * Master Clearspace Generator (Horizontal & Vertical Lockup Spacing & Proportions)
     */
    self.generateClearspace = function (doc, opts) {
        opts = opts || {};
        var selection = doc.selection;
        if (!selection || selection.length === 0) {
            throw new Error("Please select your logo artwork to generate clearspace exclusion zones.");
        }

        var bounds = BaseGrids.getTargetBounds(doc, "selection");
        var left = bounds[0], top = bounds[1], right = bounds[2], bottom = bounds[3];
        var width = right - left;
        var height = top - bottom;

        var isGuide = (opts.style && (opts.style.renderMode === "guides" || opts.style.isGuide));
        var layer = StyleManager.getOrCreateLayer(doc, isGuide ? "[GRID] Guides - Clearspace" : "[GRID] Lines - Clearspace", isGuide);
        try {
            layer.zOrder(ZOrderMethod.SENDTOBACK);
        } catch (e) {}

        // Remove existing clearspace groups
        for (var g = layer.groupItems.length - 1; g >= 0; g--) {
            var exG = layer.groupItems[g];
            if (exG.name && exG.name.indexOf("Clearspace") === 0) {
                try {
                    var egb = exG.geometricBounds;
                    var eL = Math.min(egb[0], egb[2]), eR = Math.max(egb[0], egb[2]);
                    var eT = Math.max(egb[1], egb[3]), eB = Math.min(egb[1], egb[3]);
                    var isOverlap = !(right < eL || left > eR || top < eB || bottom > eT);
                    if (isOverlap) exG.remove();
                } catch (e) {}
            }
        }

        var mainGroup = layer.groupItems.add();
        mainGroup.name = "Clearspace Brand System";
        try {
            mainGroup.zOrder(ZOrderMethod.SENDTOBACK);
        } catch (e) {}

        // 1. Detect Semantic Blocks (Icon, Wordmark lines, Tagline)
        var blocks = clusterLockupBlocks(selection);

        // Identify layout structure: Horizontal Lockup (Icon Left + Text Right) vs Vertical Lockup
        var iconBlock = null;
        var textBlocks = [];

        if (blocks.length >= 2) {
            // Find leftmost block
            var sortedByX = [];
            for (var sxi = 0; sxi < blocks.length; sxi++) {
                sortedByX.push(blocks[sxi]);
            }
            sortedByX.sort(function(a, b) { return a.left - b.left; });

            var firstB = sortedByX[0];
            var secondB = sortedByX[1];

            // If first block is horizontally separated from other blocks (like flower icon on left)
            if (secondB.left >= firstB.right - 10 && (firstB.right - firstB.left) < (right - left) * 0.65) {
                iconBlock = firstB;
                textBlocks = [];
                for (var bi = 0; bi < blocks.length; bi++) {
                    if (blocks[bi] !== iconBlock) {
                        textBlocks.push(blocks[bi]);
                    }
                }
                textBlocks.sort(function(a, b) { return b.top - a.top; }); // Sort top to bottom
            } else {
                // Pure vertical stack (Icon top, text below)
                blocks.sort(function(a, b) { return b.top - a.top; });
                iconBlock = (blocks.length >= 2 && blocks[0].width < width * 0.7) ? blocks[0] : null;
                textBlocks = [];
                var startIdx = iconBlock ? 1 : 0;
                for (var ti2 = startIdx; ti2 < blocks.length; ti2++) {
                    textBlocks.push(blocks[ti2]);
                }
            }
        } else {
            textBlocks = blocks;
        }

        // 2. Compute Base Unit X (Cap-height of Primary Wordmark)
        var unitX = 20;
        if (textBlocks.length > 0) {
            unitX = Math.round(textBlocks[0].height);
        } else if (iconBlock) {
            unitX = Math.round(iconBlock.height * 0.35);
        } else {
            unitX = Math.max(10, Math.round(height * 0.25));
        }
        if (unitX < 8) unitX = 8;

        var mult = (typeof opts.multiplier === "number") ? opts.multiplier : 1.0;
        var margin = Math.round(unitX * mult);
        if (margin < 10) margin = 10;

        var outLeft = left - margin;
        var outTop = top + margin;
        var outRight = right + margin;
        var outBottom = bottom - margin;

        var spacingFormat = opts.spacingFormat || "both"; // "both", "ratio", "pixels"
        var mode = opts.clearspaceMode || "brand";

        if (mode === "brand") {
            // =================================================================
            // VIDEO COPILOT & WOVEN BRAND LOCKUP PROPORTION STANDARD
            // =================================================================

            // A. HORIZONTAL & VERTICAL LEVEL GUIDE LINES
            var guideGroup = mainGroup.groupItems.add();
            guideGroup.name = "GRP_LEVEL_GUIDES";

            var gLineStyle = {
                colorRgb: (opts.style && opts.style.guideColor) || [180, 185, 195],
                strokeWidth: (opts.style && opts.style.guideStrokeWidth) || 0.45,
                opacity: (opts.style && typeof opts.style.guideOpacity === "number") ? opts.style.guideOpacity : 70,
                renderMode: "lines"
            };

            // Outer Bounds Level Lines (Continuous full span)
            drawLine(guideGroup, [outLeft, outTop], [outRight, outTop], gLineStyle);
            drawLine(guideGroup, [outLeft, outBottom], [outRight, outBottom], gLineStyle);
            drawLine(guideGroup, [outLeft, outTop], [outLeft, outBottom], gLineStyle);
            drawLine(guideGroup, [outRight, outTop], [outRight, outBottom], gLineStyle);

            // Icon Boundary Level Lines
            if (iconBlock) {
                drawLine(guideGroup, [outLeft, iconBlock.top], [outRight, iconBlock.top], gLineStyle);
                drawLine(guideGroup, [outLeft, iconBlock.bottom], [outRight, iconBlock.bottom], gLineStyle);
                drawLine(guideGroup, [iconBlock.left, outTop], [iconBlock.left, outBottom], gLineStyle);
                drawLine(guideGroup, [iconBlock.right, outTop], [iconBlock.right, outBottom], gLineStyle);
            }

            // Text Blocks Boundary Level Lines
            for (var t = 0; t < textBlocks.length; t++) {
                var tb = textBlocks[t];
                drawLine(guideGroup, [outLeft, tb.top], [outRight, tb.top], gLineStyle);
                drawLine(guideGroup, [outLeft, tb.bottom], [outRight, tb.bottom], gLineStyle);
                drawLine(guideGroup, [tb.left, outTop], [tb.left, outBottom], gLineStyle);
                drawLine(guideGroup, [tb.right, outTop], [tb.right, outBottom], gLineStyle);
            }

            // B. 4 CORNER BOXES (CUSTOM ICON / SVG / TEXT / 'X')
            if (opts.showCornerBoxes !== false) {
                var cornerGroup = mainGroup.groupItems.add();
                cornerGroup.name = "GRP_CORNER_BOXES";

                var boxStyle = {
                    boxStrokeColor: (opts.style && opts.style.boxStrokeColor) || [74, 144, 226],
                    boxStrokeWidth: (opts.style && opts.style.boxStrokeWidth) || 0.75,
                    boxFillColor: (opts.style && opts.style.boxFillColor) || [194, 224, 248],
                    boxOpacity: (opts.style && typeof opts.style.boxOpacity === "number") ? opts.style.boxOpacity : 50
                };

                var cType = opts.cornerType || "default_x";
                var cChar = opts.customChar || "X";
                var cSvg = opts.svgFilePath || "";
                
                var iconItems = null;
                if (iconBlock && iconBlock.items && iconBlock.items.length > 0) {
                    iconItems = iconBlock.items;
                } else {
                    var rawLeaves = collectLeafItems(selection);
                    if (rawLeaves && rawLeaves.length > 0) {
                        rawLeaves.sort(function(a, b) {
                            var ab = a.geometricBounds, bb = b.geometricBounds;
                            return Math.min(ab[0], ab[2]) - Math.min(bb[0], bb[2]);
                        });
                        iconItems = [rawLeaves[0]];
                    }
                }

                drawCornerContent(doc, cornerGroup, outLeft, outTop, margin, cType, cChar, cSvg, iconItems, boxStyle);
                drawCornerContent(doc, cornerGroup, outRight - margin, outTop, margin, cType, cChar, cSvg, iconItems, boxStyle);
                drawCornerContent(doc, cornerGroup, outLeft, outBottom + margin, margin, cType, cChar, cSvg, iconItems, boxStyle);
                drawCornerContent(doc, cornerGroup, outRight - margin, outBottom + margin, margin, cType, cChar, cSvg, iconItems, boxStyle);
            }

            // C. IN-GRID SPACING CELL LABELS (VIDEO COPILOT STYLE)
            var inGridGroup = mainGroup.groupItems.add();
            inGridGroup.name = "GRP_INGRID_SPACING_LABELS";
            var labelCol = [60, 65, 75];

            // 1. Horizontal Icon-to-Text Gap Spacing Cells (Top & Bottom Channel Cells)
            if (iconBlock && textBlocks.length > 0) {
                var textLeftMin = Infinity;
                for (var tk = 0; tk < textBlocks.length; tk++) {
                    if (textBlocks[tk].left < textLeftMin) textLeftMin = textBlocks[tk].left;
                }

                var gapW = textLeftMin - iconBlock.right;
                if (gapW >= 2.0) {
                    var gapLabel = formatSpacing(gapW, unitX, spacingFormat);
                    // Top Channel Cell
                    var topCellH = outTop - Math.max(iconBlock.top, textBlocks[0].top);
                    drawCenteredCellLabel(inGridGroup, gapLabel, iconBlock.right, outTop, gapW, Math.max(margin, topCellH), null, labelCol);
                    // Bottom Channel Cell
                    var botCellH = Math.min(iconBlock.bottom, textBlocks[textBlocks.length - 1].bottom) - outBottom;
                    drawCenteredCellLabel(inGridGroup, gapLabel, iconBlock.right, outBottom + Math.max(margin, botCellH), gapW, Math.max(margin, botCellH), null, labelCol);
                }
            }

            // 2. Vertical Text-to-Text Gap Spacing Label (Inside the interline channel)
            if (textBlocks.length >= 2) {
                for (var ti = 0; ti < textBlocks.length - 1; ti++) {
                    var curT = textBlocks[ti];
                    var nxtT = textBlocks[ti + 1];
                    var gapH = curT.bottom - nxtT.top;
                    if (gapH >= 2.0) {
                        var textGapLabel = formatSpacing(gapH, unitX, spacingFormat);
                        var textW = Math.max(curT.right, nxtT.right) - Math.min(curT.left, nxtT.left);
                        drawCenteredCellLabel(inGridGroup, textGapLabel, Math.min(curT.left, nxtT.left), curT.bottom, textW, gapH, Math.min(7.5, gapH * 0.8), labelCol);
                    }
                }
            }

            // D. PROPORTION & CLEAR SPACING BRACKETS (EXTERNAL LEADERS)
            if (opts.showBrackets !== false && !isGuide) {
                var bracketGroup = mainGroup.groupItems.add();
                bracketGroup.name = "GRP_PROPORTION_BRACKETS";

                var bStyleOpts = {
                    bracketColor: (opts.style && opts.style.bracketColor) || [74, 144, 226],
                    bracketStrokeWidth: (opts.style && opts.style.bracketStrokeWidth) || 0.75,
                    opacity: 90
                };

                var rightBracketX = outRight + 12;

                // Vertical Brackets on the Right
                if (textBlocks.length > 0) {
                    for (var tbi = 0; tbi < textBlocks.length; tbi++) {
                        var cText = textBlocks[tbi];
                        var textRatio = formatSpacing(cText.height, unitX, spacingFormat);
                        drawVerticalBracket(bracketGroup, cText.top, cText.bottom, rightBracketX, textRatio, false, bStyleOpts);

                        if (tbi < textBlocks.length - 1) {
                            var nextText = textBlocks[tbi + 1];
                            var gapBetween = cText.bottom - nextText.top;
                            if (gapBetween >= 2.0) {
                                var gapTextRatio = formatSpacing(gapBetween, unitX, spacingFormat);
                                drawVerticalBracket(bracketGroup, cText.bottom, nextText.top, rightBracketX, gapTextRatio, false, bStyleOpts);
                            }
                        }
                    }
                }

                // Horizontal Clear Spacing Bracket between Icon and Text
                if (iconBlock && textBlocks.length > 0) {
                    var minTLeft = Infinity;
                    for (var k2 = 0; k2 < textBlocks.length; k2++) {
                        if (textBlocks[k2].left < minTLeft) minTLeft = textBlocks[k2].left;
                    }

                    var iconToText = minTLeft - iconBlock.right;
                    if (iconToText >= 2.0) {
                        var gapXText = formatSpacing(iconToText, unitX, spacingFormat);
                        var bracketY = top + 10;
                        drawHorizontalBracket(bracketGroup, iconBlock.right, minTLeft, bracketY, gapXText, true, bStyleOpts);
                    }

                    // Left-side Bracket for Icon Height
                    var leftBracketX = outLeft - 12;
                    var iconHeightText = formatSpacing(iconBlock.height, unitX, spacingFormat);
                    drawVerticalBracket(bracketGroup, iconBlock.top, iconBlock.bottom, leftBracketX, iconHeightText, true, bStyleOpts);
                }
            }

        } else {
            // Classic Mode
            var innerBox = mainGroup.pathItems.rectangle(top, left, width, height);
            var innerStyle = { colorRgb: [160, 165, 175], strokeWidth: 0.5, opacity: 80, dashed: true, renderMode: isGuide ? "guides" : "lines" };
            StyleManager.applyStyle(innerBox, innerStyle);

            var outerBox = mainGroup.pathItems.rectangle(outTop, outLeft, outRight - outLeft, outTop - outBottom);
            var outerStyle = { colorRgb: [150, 155, 165], strokeWidth: 0.75, opacity: 100, dashed: false, renderMode: isGuide ? "guides" : "lines" };
            StyleManager.applyStyle(outerBox, outerStyle);
        }

        return mainGroup;
    };

    return self;
})();
