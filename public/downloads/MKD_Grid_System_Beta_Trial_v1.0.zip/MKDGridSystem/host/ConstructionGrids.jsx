/**
 * Logo Grid Studio - Shape-Aware Construction Grids & Advanced Geometry Engine (v5.0 Pro)
 * Features:
 * - Shape-Aware Edge Ray Projection (Direct collinear extension along any angled/straight edge)
 * - True Arc & Circle Fitting (Quadrant arcs, tangent circles, inner/outer loops)
 * - Dual Dimension Styles:
 *     1. Hatched Dimension Bars (45° diagonal hatching on parallel lines, e.g. x, 3x, 4x)
 *     2. Arrow Dimension Lines (Double-ended arrows with extension ticks, e.g. 4.5X, x, X/2)
 * - Intersecting Angle Callouts (Degrees between angled structural rays, e.g. 68.2°, 25.7°)
 * - Dashed Centerline Axis (Horizontal & Vertical)
 * - Strict 10-15% Bounded Perimeter (No canvas sprawling)
 * - Real-Time Live Sync & Full Layer Hierarchy
 */

var ConstructionGrids = (function () {
    var self = {};

    self.collectPathItems = function (items, result) {
        result = result || [];
        if (!items) return result;
        for (var i = 0; i < items.length; i++) {
            var it = items[i];
            if (it.typename === "PathItem") {
                result.push(it);
            } else if (it.typename === "CompoundPathItem") {
                for (var cp = 0; cp < it.pathItems.length; cp++) {
                    result.push(it.pathItems[cp]);
                }
            } else if (it.typename === "GroupItem") {
                self.collectPathItems(it.pageItems, result);
            }
        }
        return result;
    };

    function bezierPoint(p0, p1, p2, p3, t) {
        var mt = 1 - t;
        var mt2 = mt * mt, mt3 = mt2 * mt;
        var t2 = t * t, t3 = t2 * t;
        return [
            mt3 * p0[0] + 3 * mt2 * t * p1[0] + 3 * mt * t2 * p2[0] + t3 * p3[0],
            mt3 * p0[1] + 3 * mt2 * t * p1[1] + 3 * mt * t2 * p2[1] + t3 * p3[1]
        ];
    }

    function dist(p1, p2) {
        var dx = p1[0] - p2[0];
        var dy = p1[1] - p2[1];
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Compute 1st derivative vector of cubic Bezier at parameter t
     */
    function bezierDerivative(p0, p1, p2, p3, t) {
        var mt = 1 - t;
        var dx = 3 * mt * mt * (p1[0] - p0[0]) + 6 * mt * t * (p2[0] - p1[0]) + 3 * t * t * (p3[0] - p2[0]);
        var dy = 3 * mt * mt * (p1[1] - p0[1]) + 6 * mt * t * (p2[1] - p1[1]) + 3 * t * t * (p3[1] - p2[1]);
        return [dx, dy];
    }

    /**
     * Algebraic Least-Squares Circle Fitting on an array of 2D points (Kåsa method)
     */
    function fitCircleLeastSquares(pts) {
        var n = pts.length;
        if (n < 3) return null;
        var sumX = 0, sumY = 0;
        for (var i = 0; i < n; i++) {
            sumX += pts[i][0];
            sumY += pts[i][1];
        }
        var meanX = sumX / n, meanY = sumY / n;

        var Suv = 0, Suu = 0, Svv = 0, Suuu = 0, Svvv = 0, Suvv = 0, Svuu = 0;
        for (var j = 0; j < n; j++) {
            var u = pts[j][0] - meanX;
            var v = pts[j][1] - meanY;
            Suu += u * u;
            Svv += v * v;
            Suv += u * v;
            Suuu += u * u * u;
            Svvv += v * v * v;
            Suvv += u * v * v;
            Svuu += v * u * u;
        }

        var det = Suu * Svv - Suv * Suv;
        if (Math.abs(det) < 1e-6) return null;

        var uc = (Svv * (Suuu + Suvv) - Suv * (Svvv + Svuu)) / (2 * det);
        var vc = (Suu * (Svvv + Svuu) - Suv * (Suuu + Suvv)) / (2 * det);

        var cx = uc + meanX;
        var cy = vc + meanY;
        var r = Math.sqrt(uc * uc + vc * vc + (Suu + Svv) / n);

        var totalErr = 0;
        for (var k = 0; k < n; k++) {
            var d = dist([cx, cy], pts[k]);
            totalErr += Math.abs(d - r) / r;
        }
        return { cx: cx, cy: cy, r: r, err: totalErr / n };
    }

    /**
     * Precision Circle Fitting for Bezier Curve Segments
     * Uses Tangent Normal Intersection (CAD exact) + Algebraic Least-Squares optimization
     */
    function fitCircleToArc(p0, p1, p2, p3) {
        // 1. Get exact start and end tangent direction vectors
        var t0x = p1[0] - p0[0], t0y = p1[1] - p0[1];
        var t3x = p3[0] - p2[0], t3y = p3[1] - p2[1];

        var len0 = Math.sqrt(t0x * t0x + t0y * t0y);
        var len3 = Math.sqrt(t3x * t3x + t3y * t3y);

        if (len0 < 0.1) {
            var d0 = bezierDerivative(p0, p1, p2, p3, 0.05);
            t0x = d0[0]; t0y = d0[1]; len0 = Math.sqrt(t0x * t0x + t0y * t0y);
        }
        if (len3 < 0.1) {
            var d3 = bezierDerivative(p0, p1, p2, p3, 0.95);
            t3x = d3[0]; t3y = d3[1]; len3 = Math.sqrt(t3x * t3x + t3y * t3y);
        }

        // Method A: Tangent Normal Intersection
        if (len0 >= 0.1 && len3 >= 0.1) {
            var A1 = t0x, B1 = t0y, C1 = t0x * p0[0] + t0y * p0[1];
            var A2 = t3x, B2 = t3y, C2 = t3x * p3[0] + t3y * p3[1];
            var det = A1 * B2 - A2 * B1;

            if (Math.abs(det) > 1e-4) {
                var cx = (C1 * B2 - C2 * B1) / det;
                var cy = (A1 * C2 - A2 * C1) / det;
                var r0 = dist([cx, cy], p0);
                var r3 = dist([cx, cy], p3);
                var r = (r0 + r3) / 2;

                // Validate with 7 sample points along the Bezier curve
                var sampleTs = [0.15, 0.3, 0.5, 0.7, 0.85];
                var totalErr = 0;
                for (var s = 0; s < sampleTs.length; s++) {
                    var sPt = bezierPoint(p0, p1, p2, p3, sampleTs[s]);
                    var sDist = dist([cx, cy], sPt);
                    totalErr += Math.abs(sDist - r) / r;
                }
                var avgErr = totalErr / sampleTs.length;

                if (avgErr <= 0.035) { // 3.5% error threshold (Pixel-perfect fit)
                    return { cx: cx, cy: cy, r: r, err: avgErr };
                }
            }
        }

        // Method B: High-Precision 9-point Algebraic Least-Squares fit
        var pts = [];
        var numSamples = 9;
        for (var k = 0; k <= numSamples; k++) {
            pts.push(bezierPoint(p0, p1, p2, p3, k / numSamples));
        }
        var fitLS = fitCircleLeastSquares(pts);
        if (fitLS && fitLS.err <= 0.04) {
            return fitLS;
        }

        return null;
    }

    function drawLine(container, p1, p2, styleOptions) {
        var line = container.pathItems.add();
        line.setEntirePath([p1, p2]);
        line.closed = false;
        StyleManager.applyStyle(line, styleOptions);
        return line;
    }

    function drawCircle(container, cx, cy, r, styleOptions) {
        var circle = container.pathItems.ellipse(cy + r, cx - r, r * 2, r * 2);
        StyleManager.applyStyle(circle, styleOptions);
        return circle;
    }

    function drawTextLabel(container, textStr, x, y, size, colorRgb) {
        try {
            var tf = container.textFrames.add();
            tf.contents = textStr;
            tf.top = y;
            tf.left = x;
            if (tf.textRange && tf.textRange.characterAttributes) {
                tf.textRange.characterAttributes.size = size || 7.5;
                if (colorRgb) {
                    tf.textRange.characterAttributes.fillColor = StyleManager.createRGBColor(colorRgb);
                }
            }
            return tf;
        } catch (e) {
            return null;
        }
    }

    function clusterCoordinates(arr, tolerance) {
        if (!arr || arr.length === 0) return [];
        arr.sort(function (a, b) { return a - b; });
        var clusters = [arr[0]];
        for (var i = 1; i < arr.length; i++) {
            if (Math.abs(arr[i] - clusters[clusters.length - 1]) > tolerance) {
                clusters.push(arr[i]);
            }
        }
        return clusters;
    }

    /**
     * Intersect an infinite 2D line through point P with direction angle theta against rectangle [L, T, R, B]
     */
    function clipRayToRect(px, py, theta, left, top, right, bottom) {
        var cosT = Math.cos(theta);
        var sinT = Math.sin(theta);
        var pts = [];

        // Intersect Left (x = left)
        if (Math.abs(cosT) > 1e-5) {
            var tL = (left - px) / cosT;
            var yL = py + tL * sinT;
            if (yL >= bottom - 1 && yL <= top + 1) pts.push({ x: left, y: yL, t: tL });
        }
        // Intersect Right (x = right)
        if (Math.abs(cosT) > 1e-5) {
            var tR = (right - px) / cosT;
            var yR = py + tR * sinT;
            if (yR >= bottom - 1 && yR <= top + 1) pts.push({ x: right, y: yR, t: tR });
        }
        // Intersect Top (y = top)
        if (Math.abs(sinT) > 1e-5) {
            var tT = (top - py) / sinT;
            var xT = px + tT * cosT;
            if (xT >= left - 1 && xT <= right + 1) pts.push({ x: xT, y: top, t: tT });
        }
        // Intersect Bottom (y = bottom)
        if (Math.abs(sinT) > 1e-5) {
            var tB = (bottom - py) / sinT;
            var xB = px + tB * cosT;
            if (xB >= left - 1 && xB <= right + 1) pts.push({ x: xB, y: bottom, t: tB });
        }

        if (pts.length < 2) return null;
        // Sort by parameter t and return entry & exit
        pts.sort(function (a, b) { return a.t - b.t; });
        return [ [pts[0].x, pts[0].y], [pts[pts.length - 1].x, pts[pts.length - 1].y] ];
    }

    /**
     * Compute perpendicular distance from point (px, py) to line segment (x1, y1)-(x2, y2)
     */
    function pointLineDist(px, py, x1, y1, x2, y2) {
        var dx = x2 - x1;
        var dy = y2 - y1;
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-4) return dist([px, py], [x1, y1]);
        return Math.abs((px - x1) * dy - (py - y1) * dx) / len;
    }

    /**
     * Extract Shape-Aware Directional Rays from all straight edges of the logo
     * Uses robust geometric collinearity check so straight edges with tangent handles
     * (e.g. adjacent to rounded corners) are accurately detected.
     */
    self.extractEdgeRays = function (pathItems, left, top, right, bottom, overflow) {
        var rawRays = [];
        var spanL = left - overflow, spanR = right + overflow;
        var spanT = top + overflow, spanB = bottom - overflow;

        for (var p = 0; p < pathItems.length; p++) {
            var pi = pathItems[p];
            var pts = pi.pathPoints;
            var num = pi.closed ? pts.length : pts.length - 1;

            for (var i = 0; i < num; i++) {
                var p0 = pts[i];
                var p1 = pts[(i + 1) % pts.length];

                var ax0 = p0.anchor[0], ay0 = p0.anchor[1];
                var ax1 = p1.anchor[0], ay1 = p1.anchor[1];
                var rx0 = p0.rightDirection[0], ry0 = p0.rightDirection[1];
                var lx1 = p1.leftDirection[0], ly1 = p1.leftDirection[1];

                var segLen = dist([ax0, ay0], [ax1, ay1]);
                if (segLen < 4.0) continue; // Ignore microscopic segments

                // 1. Both control handles must be strictly collinear with the chord (rejects all arcs & circles)
                var d1 = pointLineDist(rx0, ry0, ax0, ay0, ax1, ay1);
                var d2 = pointLineDist(lx1, ly1, ax0, ay0, ax1, ay1);
                var maxAllowedHandleDist = Math.min(0.25, segLen * 0.015);
                if (d1 > maxAllowedHandleDist || d2 > maxAllowedHandleDist) continue;

                // 2. Multi-point sample check along the Bezier curve (t = 0.2, 0.4, 0.5, 0.6, 0.8)
                var isCurved = false;
                var sampleTs = [0.2, 0.4, 0.5, 0.6, 0.8];
                for (var st = 0; st < sampleTs.length; st++) {
                    var sPt = bezierPoint([ax0, ay0], [rx0, ry0], [lx1, ly1], [ax1, ay1], sampleTs[st]);
                    var dPt = pointLineDist(sPt[0], sPt[1], ax0, ay0, ax1, ay1);
                    if (dPt > Math.min(0.2, segLen * 0.01)) {
                        isCurved = true;
                        break;
                    }
                }
                if (isCurved) continue; // Strictly ignore all circular curves, arcs, and rounded shapes

                var angle = Math.atan2(ay1 - ay0, ax1 - ax0);
                while (angle < 0) angle += Math.PI;
                while (angle >= Math.PI) angle -= Math.PI;

                // Normal distance from origin: d = x*sin(angle) - y*cos(angle)
                var normDist = ax0 * Math.sin(angle) - ay0 * Math.cos(angle);

                rawRays.push({
                    p1: [ax0, ay0],
                    p2: [ax1, ay1],
                    angle: angle,
                    normDist: normDist,
                    length: segLen
                });
            }
        }

        // Deduplicate Collinear Rays (Keep each distinct parallel edge, merge only identical coincident lines)
        var deduped = [];
        for (var r = 0; r < rawRays.length; r++) {
            var ray = rawRays[r];
            var isDup = false;
            for (var d = 0; d < deduped.length; d++) {
                var dRay = deduped[d];
                var angleDiff = Math.abs(ray.angle - dRay.angle);
                if (angleDiff > Math.PI / 2) angleDiff = Math.PI - angleDiff;
                var distDiff = Math.abs(ray.normDist - dRay.normDist);

                // Very tight threshold (< 1.5 pt distance) so parallel bars are NEVER merged
                if (angleDiff < 0.025 && distDiff < 1.5) {
                    isDup = true;
                    if (ray.length > dRay.length) {
                        deduped[d] = ray; // Keep longer representative
                    }
                    break;
                }
            }
            if (!isDup) deduped.push(ray);
        }

        // Clip each ray to the 10-15% bounding perimeter
        var clippedRays = [];
        for (var c = 0; c < deduped.length; c++) {
            var dR = deduped[c];
            var clip = clipRayToRect(dR.p1[0], dR.p1[1], dR.angle, spanL, spanT, spanR, spanB);
            if (clip) {
                clippedRays.push({
                    p1: clip[0],
                    p2: clip[1],
                    angle: dR.angle,
                    origP1: dR.p1,
                    origP2: dR.p2
                });
            }
        }

        return clippedRays;
    };

    /**
     * Smart Major Curve & Tangent Circle Detection (Image 1 Style)
     * Fits pixel-perfect CAD-exact tangent circles for all petal curves and circular arcs.
     * Strictly bounded to 10-15% perimeter to prevent giant canvas-sprawling circles.
     */
    self.detectMajorCurves = function (pathItems, left, top, right, bottom, maxDim, spanL, spanT, spanR, spanB) {
        var detected = [];
        var minRadius = Math.max(8, maxDim * 0.05);
        var maxRadius = maxDim * 0.65; // Strict cap to prevent giant off-canvas circles

        var boundL = (typeof spanL === "number") ? spanL - 10 : left - maxDim * 0.15;
        var boundR = (typeof spanR === "number") ? spanR + 10 : right + maxDim * 0.15;
        var boundT = (typeof spanT === "number") ? spanT + 10 : top + maxDim * 0.15;
        var boundB = (typeof spanB === "number") ? spanB - 10 : bottom - maxDim * 0.15;

        for (var p = 0; p < pathItems.length; p++) {
            var pi = pathItems[p];
            var pts = pi.pathPoints;
            var num = pi.closed ? pts.length : pts.length - 1;

            for (var i = 0; i < num; i++) {
                var p0 = [pts[i].anchor[0], pts[i].anchor[1]];
                var p1 = [pts[i].rightDirection[0], pts[i].rightDirection[1]];
                var nextP = pts[(i + 1) % pts.length];
                var p2 = [nextP.leftDirection[0], nextP.leftDirection[1]];
                var p3 = [nextP.anchor[0], nextP.anchor[1]];

                // Strict check: Ignore straight lines or micro segments
                var d01 = dist(p0, p1);
                var d23 = dist(p2, p3);
                if (d01 < 1.5 && d23 < 1.5) continue; // Straight line
                if (dist(p0, p3) < maxDim * 0.04) continue; // Micro segment

                var circ = fitCircleToArc(p0, p1, p2, p3);
                if (!circ || circ.r < minRadius || circ.r > maxRadius) continue;

                // Center must be within reasonable proximity of the artwork
                if (circ.cx < left - maxDim * 0.25 || circ.cx > right + maxDim * 0.25 ||
                    circ.cy < bottom - maxDim * 0.25 || circ.cy > top + maxDim * 0.25) continue;

                // Circle perimeter must stay within the 10-15% boundary
                if (circ.cx - circ.r < boundL - 15 || circ.cx + circ.r > boundR + 15 ||
                    circ.cy - circ.r < boundB - 15 || circ.cy + circ.r > boundT + 15) continue;

                var dup = false;
                for (var d = 0; d < detected.length; d++) {
                    if (dist([detected[d].cx, detected[d].cy], [circ.cx, circ.cy]) < 3.0 &&
                        Math.abs(detected[d].r - circ.r) < 3.0) {
                        dup = true;
                        break;
                    }
                }
                if (!dup) detected.push(circ);
            }
        }

        // Sort by radius prominence and retain authentic design circles
        detected.sort(function (a, b) { return b.r - a.r; });
        return detected.slice(0, 24);
    };

    /**
     * Draw Double-Ended Arrow Dimension with extension ticks (Image 1 Style: 4.5X, x, X/2)
     */
    function drawArrowDimension(container, p1, p2, labelText, isVertical, styleOptions) {
        var dimGroup = container.groupItems.add();
        dimGroup.name = "Arrow Dim " + labelText;

        var col = (styleOptions && styleOptions.colorRgb) || [140, 145, 155];
        var sColor = StyleManager.createRGBColor(col);
        var arrowSize = 3.5;

        // Main dimension line
        var line = dimGroup.pathItems.add();
        line.setEntirePath([p1, p2]);
        line.stroked = true;
        line.strokeColor = sColor;
        line.strokeWidth = 0.45;
        line.filled = false;

        // Arrowheads
        if (isVertical) {
            // Top arrowhead
            var aTop = dimGroup.pathItems.add();
            aTop.setEntirePath([[p1[0] - arrowSize * 0.6, p1[1] - arrowSize], [p1[0], p1[1]], [p1[0] + arrowSize * 0.6, p1[1] - arrowSize]]);
            aTop.stroked = true; aTop.strokeColor = sColor; aTop.strokeWidth = 0.45; aTop.filled = false;

            // Bottom arrowhead
            var aBot = dimGroup.pathItems.add();
            aBot.setEntirePath([[p2[0] - arrowSize * 0.6, p2[1] + arrowSize], [p2[0], p2[1]], [p2[0] + arrowSize * 0.6, p2[1] + arrowSize]]);
            aBot.stroked = true; aBot.strokeColor = sColor; aBot.strokeWidth = 0.45; aBot.filled = false;

            // Centered text label
            if (labelText) {
                var midY = (p1[1] + p2[1]) / 2;
                drawTextLabel(dimGroup, labelText, p1[0] + (p1[0] > 0 ? 6 : -22), midY + 3, 7.5, col);
            }
        } else {
            // Left arrowhead
            var aLeft = dimGroup.pathItems.add();
            aLeft.setEntirePath([[p1[0] + arrowSize, p1[1] + arrowSize * 0.6], [p1[0], p1[1]], [p1[0] + arrowSize, p1[1] - arrowSize * 0.6]]);
            aLeft.stroked = true; aLeft.strokeColor = sColor; aLeft.strokeWidth = 0.45; aLeft.filled = false;

            // Right arrowhead
            var aRight = dimGroup.pathItems.add();
            aRight.setEntirePath([[p2[0] - arrowSize, p2[1] + arrowSize * 0.6], [p2[0], p2[1]], [p2[0] - arrowSize, p2[1] - arrowSize * 0.6]]);
            aRight.stroked = true; aRight.strokeColor = sColor; aRight.strokeWidth = 0.45; aRight.filled = false;

            // Centered text label above
            if (labelText) {
                var midX = (p1[0] + p2[0]) / 2;
                drawTextLabel(dimGroup, labelText, midX - 6, p1[1] + 9, 8.0, col);
            }
        }

        return dimGroup;
    }

    /**
     * Draw 45° Diagonal Hatched Dimension Bar (Image 2 Style: x, 3x, 4x)
     */
    function drawHatchedDimensionBar(container, left, top, width, height, isVertical, labelText, styleOptions) {
        var barGroup = container.groupItems.add();
        barGroup.name = "Hatched Dim " + labelText;

        var col = (styleOptions && styleOptions.colorRgb) || [135, 140, 150];
        var sCol = StyleManager.createRGBColor(col);

        // Border box
        var box = barGroup.pathItems.rectangle(top, left, width, height);
        box.stroked = true;
        box.strokeColor = sCol;
        box.strokeWidth = 0.4;
        box.filled = false;

        // Diagonal hatching
        var spacing = 4.0;
        if (!isVertical) {
            for (var hx = left - height; hx <= left + width + height; hx += spacing) {
                var p1x = Math.max(left, hx);
                var p1y = top - (p1x - hx);
                var p2x = Math.min(left + width, hx + height);
                var p2y = top - (p2x - hx);
                if (p1x < p2x && p1y <= top && p2y >= top - height) {
                    var l = barGroup.pathItems.add();
                    l.setEntirePath([[p1x, p1y], [p2x, p2y]]);
                    l.stroked = true; l.strokeColor = sCol; l.strokeWidth = 0.35; l.opacity = 70;
                }
            }
            if (labelText) {
                drawTextLabel(barGroup, labelText, left + (width / 2) - 5, top + 9, 7.5, col);
            }
        } else {
            for (var hy = top + width; hy >= top - height - width; hy -= spacing) {
                var v1y = Math.min(top, hy);
                var v1x = left + (top - v1y);
                var v2y = Math.max(top - height, hy - width);
                var v2x = left + (top - v2y);
                if (v1y > v2y && v1x >= left && v2x <= left + width) {
                    var lv = barGroup.pathItems.add();
                    lv.setEntirePath([[v1x, v1y], [v2x, v2y]]);
                    lv.stroked = true; lv.strokeColor = sCol; lv.strokeWidth = 0.35; lv.opacity = 70;
                }
            }
            if (labelText) {
                drawTextLabel(barGroup, labelText, left - 16, top - (height / 2) + 3, 7.5, col);
            }
        }

        return barGroup;
    }

    /**
     * Draw Intersecting Angle Arcs & Degree Labels ONLY at genuine logo corner vertices
     */
    function drawAngleCallouts(container, pathItems, styleOptions) {
        var angleGroup = container.groupItems.add();
        angleGroup.name = "GRP_ANGLES";
        var col = (styleOptions && styleOptions.colorRgb) || [120, 125, 135];
        var sCol = StyleManager.createRGBColor(col);

        var arcR = 14.0;
        var drawnCorners = [];

        for (var p = 0; p < pathItems.length; p++) {
            var pi = pathItems[p];
            var pts = pi.pathPoints;
            if (!pts || pts.length < 3) continue;
            var num = pi.closed ? pts.length : pts.length - 2;

            for (var i = 0; i < num; i++) {
                var prevIdx = (i - 1 + pts.length) % pts.length;
                var nextIdx = (i + 1) % pts.length;

                var prevPt = [pts[prevIdx].anchor[0], pts[prevIdx].anchor[1]];
                var currPt = [pts[i].anchor[0], pts[i].anchor[1]];
                var nextPt = [pts[nextIdx].anchor[0], pts[nextIdx].anchor[1]];

                // Vector 1 (curr -> prev) and Vector 2 (curr -> next)
                var v1x = prevPt[0] - currPt[0], v1y = prevPt[1] - currPt[1];
                var v2x = nextPt[0] - currPt[0], v2y = nextPt[1] - currPt[1];
                var len1 = Math.sqrt(v1x * v1x + v1y * v1y);
                var len2 = Math.sqrt(v2x * v2x + v2y * v2y);

                if (len1 < 10 || len2 < 10) continue;

                // Check that both segments are relatively straight into this corner
                var rd1 = dist(currPt, [pts[i].rightDirection[0], pts[i].rightDirection[1]]);
                var ld1 = dist(currPt, [pts[i].leftDirection[0], pts[i].leftDirection[1]]);
                if (rd1 > 2.0 || ld1 > 2.0) continue; // Skip smooth curve anchors

                var angle1 = Math.atan2(v1y, v1x);
                var angle2 = Math.atan2(v2y, v2x);

                var dot = (v1x * v2x + v1y * v2y) / (len1 * len2);
                if (dot > 1) dot = 1;
                if (dot < -1) dot = -1;
                var interiorAngle = Math.acos(dot);
                var deg = interiorAngle * 180 / Math.PI;

                // Only call out significant acute/obtuse design angles (e.g. 25° to 80° or 100° to 155°)
                if ((deg >= 25.0 && deg <= 80.0) || (deg >= 100.0 && deg <= 155.0)) {
                    // Check duplicate / proximity to already drawn corner
                    var isDup = false;
                    for (var d = 0; d < drawnCorners.length; d++) {
                        if (dist(currPt, drawnCorners[d]) < 12.0) {
                            isDup = true;
                            break;
                        }
                    }
                    if (isDup) continue;
                    drawnCorners.push(currPt);

                    var startA = Math.min(angle1, angle2);
                    var endA = Math.max(angle1, angle2);
                    if (endA - startA > Math.PI) {
                        var tmp = startA;
                        startA = endA;
                        endA = tmp + 2 * Math.PI;
                    }

                    var arcPts = [];
                    var steps = 6;
                    for (var st = 0; st <= steps; st++) {
                        var curA = startA + (st / steps) * (endA - startA);
                        arcPts.push([currPt[0] + arcR * Math.cos(curA), currPt[1] + arcR * Math.sin(curA)]);
                    }

                    var arcLine = angleGroup.pathItems.add();
                    arcLine.setEntirePath(arcPts);
                    arcLine.stroked = true;
                    arcLine.strokeColor = sCol;
                    arcLine.strokeWidth = 0.4;
                    arcLine.filled = false;

                    var midAngle = (startA + endA) / 2;
                    var lblX = currPt[0] + (arcR + 6) * Math.cos(midAngle);
                    var lblY = currPt[1] + (arcR + 6) * Math.sin(midAngle);
                    drawTextLabel(angleGroup, deg.toFixed(1) + "°", lblX - 4, lblY + 3, 6.5, col);
                }
            }
        }
        return angleGroup;
    }

    function findAllGroupsRecursive(container, targetName, result) {
        result = result || [];
        if (!container || !container.groupItems) return result;
        for (var i = 0; i < container.groupItems.length; i++) {
            var g = container.groupItems[i];
            if (g.name === targetName) {
                result.push(g);
            }
            findAllGroupsRecursive(g, targetName, result);
        }
        return result;
    }

    /**
     * Spatially partition selection into individual logo artwork clusters
     */
    function groupSelectionIntoArtworks(selection) {
        if (!selection || selection.length === 0) return [];

        var rawUnits = [];
        for (var s = 0; s < selection.length; s++) {
            var it = selection[s];
            var gb = it.geometricBounds;
            var bLeft = Math.min(gb[0], gb[2]);
            var bRight = Math.max(gb[0], gb[2]);
            var bTop = Math.max(gb[1], gb[3]);
            var bBottom = Math.min(gb[1], gb[3]);

            rawUnits.push({
                items: [it],
                bounds: { left: bLeft, top: bTop, right: bRight, bottom: bBottom }
            });
        }

        // Iteratively merge units that are spatially adjacent/overlapping (gap < 25 pt)
        var gap = 25;
        var changed = true;
        while (changed) {
            changed = false;
            for (var i = 0; i < rawUnits.length; i++) {
                for (var j = i + 1; j < rawUnits.length; j++) {
                    var u1 = rawUnits[i].bounds;
                    var u2 = rawUnits[j].bounds;

                    var overlapX = !(u1.right + gap < u2.left || u1.left - gap > u2.right);
                    var overlapY = !(u1.top + gap < u2.bottom || u1.bottom - gap > u2.top);

                    if (overlapX && overlapY) {
                        // Merge j into i
                        rawUnits[i].items = rawUnits[i].items.concat(rawUnits[j].items);
                        rawUnits[i].bounds.left = Math.min(u1.left, u2.left);
                        rawUnits[i].bounds.right = Math.max(u1.right, u2.right);
                        rawUnits[i].bounds.top = Math.max(u1.top, u2.top);
                        rawUnits[i].bounds.bottom = Math.min(u1.bottom, u2.bottom);
                        rawUnits.splice(j, 1);
                        changed = true;
                        break;
                    }
                }
                if (changed) break;
            }
        }

        return rawUnits;
    }

    /**
     * Applies Technical Blueprint / Presentation Styling to the main logo artwork
     * Subdues the logo fill to 35% opacity and adds clean dark outline so grids stand out.
     * Or preserves 100% of original logo colors, fills, and strokes when Original Mode is selected.
     */
    function applyPresentationStylingToArtwork(items, params) {
        if (!items || items.length === 0 || !params) return;

        var isOriginal = (params.logoStyleMode === "original" || params.dimLogo === false);
        var shouldDim = !isOriginal;
        var opacityVal = (typeof params.logoOpacity === "number") ? params.logoOpacity : (shouldDim ? 65 : 100);

        var darkOutline = StyleManager.createRGBColor([60, 65, 75]);
        var technicalFill = StyleManager.createRGBColor([200, 205, 215]);

        for (var i = 0; i < items.length; i++) {
            styleItemRecursive(items[i], shouldDim, opacityVal, darkOutline, technicalFill);
        }
    }

    function styleItemRecursive(it, shouldDim, opacityVal, darkOutline, technicalFill) {
        if (!it) return;

        // Skip [GRID] layers and construction system groups
        try {
            if (it.layer && it.layer.name && it.layer.name.indexOf("[GRID") === 0) return;
            if (it.name && it.name.indexOf("Construction System") === 0) return;
            if (it.parent && it.parent.name && it.parent.name.indexOf("Construction System") === 0) return;
        } catch (e) {}

        try {
            if (it.layer && it.layer.locked) it.layer.locked = false;
            it.locked = false;
        } catch (e) {}

        // Tag original appearance so we can 100% restore it when clearing grid or switching to original mode
        StyleManager.tagOriginalAppearance(it);

        if (shouldDim) {
            try {
                it.opacity = opacityVal;
            } catch (e) {}

            if (it.typename === "PathItem") {
                try {
                    if (it.filled) {
                        it.fillColor = technicalFill;
                    }
                    if (it.stroked) {
                        it.strokeColor = darkOutline;
                        if (it.strokeWidth < 0.8) it.strokeWidth = 1.0;
                    } else if (it.filled) {
                        it.stroked = true;
                        it.strokeColor = darkOutline;
                        it.strokeWidth = 1.0;
                    }
                } catch (e) {}
            } else if (it.typename === "CompoundPathItem") {
                for (var cp = 0; cp < it.pathItems.length; cp++) {
                    styleItemRecursive(it.pathItems[cp], shouldDim, opacityVal, darkOutline, technicalFill);
                }
            } else if (it.typename === "GroupItem") {
                for (var g = 0; g < it.pageItems.length; g++) {
                    styleItemRecursive(it.pageItems[g], shouldDim, opacityVal, darkOutline, technicalFill);
                }
            }
        } else {
            // MODE: Original (Keep Colors & Style)
            StyleManager.restoreItemAppearanceRecursive(it);
            try {
                it.opacity = opacityVal;
            } catch (eO) {}
        }
    }

    /**
     * Builds a complete Construction Grid system for a single logo artwork unit
     */
    self.buildSingleConstructionGrid = function (doc, mainGroup, pathItems, left, top, right, bottom, maxDim, params, isGuide) {
        var overflowPercent = (params.gridlines && params.gridlines.overflowPercent) ? params.gridlines.overflowPercent : 15;
        var overflow = Math.round(maxDim * (overflowPercent / 100));
        if (overflow < 15) overflow = 15;

        var rayOverflowPercent = (params.edgeRays && typeof params.edgeRays.overflowPercent === "number") ? params.edgeRays.overflowPercent : 15;
        var rayOverflow = Math.round(maxDim * (rayOverflowPercent / 100));
        if (rayOverflow < 15) rayOverflow = 15;

        var spanL = left - overflow, spanR = right + overflow;
        var spanT = top + overflow, spanB = bottom - overflow;

        // 1. SMART CURVES & CIRCLES (Image 1 Style - Bounded to 10-15%)
        var outlineGroup = mainGroup.groupItems.add();
        outlineGroup.name = "GRP_OUTLINES";
        outlineGroup.hidden = (params.enableOutlines === false);

        var oStyle = {
            colorRgb: (params.outlines && params.outlines.strokeColor) || [140, 150, 165],
            strokeWidth: (params.outlines && params.outlines.strokeWidth) || 0.6,
            opacity: (params.outlines && typeof params.outlines.opacity === "number") ? params.outlines.opacity : 85,
            dashed: (params.outlines && params.outlines.dashed),
            renderMode: params.renderMode
        };

        var detectedCircles = (params.enableOutlines !== false || params.enableGridlines !== false) ?
            self.detectMajorCurves(pathItems, left, top, right, bottom, maxDim, spanL, spanT, spanR, spanB) : [];

        if (params.enableOutlines !== false) {
            for (var c = 0; c < detectedCircles.length; c++) {
                var circ = detectedCircles[c];
                drawCircle(outlineGroup, circ.cx, circ.cy, circ.r, oStyle);
            }
        }

        // 2. SHAPE-AWARE EDGE RAYS (Angled Rays - Purely Angled Shape Edges)
        var edgeRaysGroup = mainGroup.groupItems.add();
        edgeRaysGroup.name = "GRP_EDGERAYS";
        edgeRaysGroup.hidden = (params.enableEdgeRays === false);

        var rayStyle = {
            colorRgb: (params.edgeRays && params.edgeRays.strokeColor) || [175, 180, 190],
            strokeWidth: (params.edgeRays && params.edgeRays.strokeWidth) || 0.45,
            opacity: (params.edgeRays && typeof params.edgeRays.opacity === "number") ? params.edgeRays.opacity : 75,
            renderMode: params.renderMode
        };

        var edgeRays = (params.enableEdgeRays !== false) ?
            self.extractEdgeRays(pathItems, left, top, right, bottom, rayOverflow) : [];

        if (params.enableEdgeRays !== false) {
            for (var er = 0; er < edgeRays.length; er++) {
                drawLine(edgeRaysGroup, edgeRays[er].p1, edgeRays[er].p2, rayStyle);
            }
        }

        // 3. ANCHOR-ALIGNED ORTHOGONAL GRIDLINES
        var gridGroup = mainGroup.groupItems.add();
        gridGroup.name = "GRP_GRIDLINES";
        gridGroup.hidden = (params.enableGridlines === false);

        var rawX = [left, right];
        var rawY = [top, bottom];

        // Include Path Anchors
        for (var pa = 0; pa < pathItems.length; pa++) {
            var ptsPa = pathItems[pa].pathPoints;
            for (var ipa = 0; ipa < ptsPa.length; ipa++) {
                rawX.push(ptsPa[ipa].anchor[0]);
                rawY.push(ptsPa[ipa].anchor[1]);
            }
        }

        // Include Circle Tangents & Centers
        if (params.enableOutlines !== false) {
            for (var tc = 0; tc < detectedCircles.length; tc++) {
                var dc = detectedCircles[tc];
                rawX.push(dc.cx - dc.r); rawX.push(dc.cx + dc.r);
                rawY.push(dc.cy - dc.r); rawY.push(dc.cy + dc.r);
            }
        }

        var tol = Math.max(5.0, maxDim * 0.025);
        var distinctX = clusterCoordinates(rawX, tol);
        var distinctY = clusterCoordinates(rawY, tol);

        var gStyle = {
            colorRgb: (params.gridlines && params.gridlines.strokeColor) || [180, 185, 195],
            strokeWidth: (params.gridlines && params.gridlines.strokeWidth) || 0.45,
            opacity: (params.gridlines && typeof params.gridlines.opacity === "number") ? params.gridlines.opacity : 70,
            renderMode: params.renderMode
        };

        if (params.enableGridlines !== false) {
            for (var vx = 0; vx < distinctX.length; vx++) {
                drawLine(gridGroup, [distinctX[vx], spanT], [distinctX[vx], spanB], gStyle);
            }
            for (var hy = 0; hy < distinctY.length; hy++) {
                drawLine(gridGroup, [spanL, distinctY[hy]], [spanR, distinctY[hy]], gStyle);
            }
        }

        // 4. CENTERLINE AXIS (Dashed - Only when Gridlines is active)
        if (params.enableCenterlines === true && params.enableGridlines !== false && !isGuide) {
            var centerGroup = mainGroup.groupItems.add();
            centerGroup.name = "GRP_CENTERLINES";
            var midX = (left + right) / 2;
            var midY = (top + bottom) / 2;
            var cStyle = { colorRgb: [160, 165, 175], strokeWidth: 0.5, opacity: 60, dashed: true, renderMode: "lines" };
            drawLine(centerGroup, [midX, spanT], [midX, spanB], cStyle);
            drawLine(centerGroup, [spanL, midY], [spanR, midY], cStyle);
        }

        // 5. ANGLE CALLOUTS (Genuine Logo Corners Only)
        if (params.enableAngleCallouts === true && !isGuide) {
            drawAngleCallouts(mainGroup, pathItems, { colorRgb: [115, 120, 130] });
        }

        // 6. DUAL DIMENSION SYSTEM (Hatched Bars vs Arrow Callouts)
        if (params.enableDimensions !== false && !isGuide) {
            var dimGroup = mainGroup.groupItems.add();
            dimGroup.name = "GRP_DIMENSIONS";

            var dimStyleChoice = params.dimensionStyle || "arrows";

            var deltasY = [];
            for (var dy1 = 0; dy1 < distinctY.length - 1; dy1++) {
                var dVal = distinctY[dy1 + 1] - distinctY[dy1];
                if (dVal >= maxDim * 0.02) deltasY.push(dVal);
            }
            var baseUnit = deltasY.length > 0 ? Math.min.apply(null, deltasY) : 20;
            if (baseUnit < 5) baseUnit = 20;

            if (dimStyleChoice === "arrows") {
                // Image 1 Style: Top Overall Width Arrow (e.g. 4.5X)
                var totalW = right - left;
                var ratioW = Math.round((totalW / baseUnit) * 10) / 10;
                var lblW = ratioW + "X";
                drawArrowDimension(dimGroup, [left, spanT + 12], [right, spanT + 12], lblW, false, { colorRgb: [130, 135, 145] });

                // Left Spacing Arrows (e.g. x, x, x)
                for (var ly = 0; ly < distinctY.length - 1; ly++) {
                    var segH = distinctY[ly + 1] - distinctY[ly];
                    if (segH >= maxDim * 0.03) {
                        var rSeg = Math.round((segH / baseUnit) * 2) / 2;
                        var lblH = (rSeg === 1) ? "x" : (rSeg === 0.5 ? "X/2" : (rSeg + "x"));
                        var xPos = spanL - 14;
                        drawArrowDimension(dimGroup, [xPos, distinctY[ly + 1]], [xPos, distinctY[ly]], lblH, true, { colorRgb: [130, 135, 145] });
                    }
                }

                // Right Spacing Arrows (e.g. X/2, X/2)
                for (var ry = 0; ry < distinctY.length - 1; ry++) {
                    var rSegH = distinctY[ry + 1] - distinctY[ry];
                    if (rSegH >= maxDim * 0.03) {
                        var rSeg2 = Math.round((rSegH / baseUnit) * 2) / 2;
                        var lblR = (rSeg2 === 0.5) ? "X/2" : (rSeg2 === 1 ? "x" : (rSeg2 + "x"));
                        var xPosR = spanR + 14;
                        drawArrowDimension(dimGroup, [xPosR, distinctY[ry + 1]], [xPosR, distinctY[ry]], lblR, true, { colorRgb: [130, 135, 145] });
                    }
                }
            } else {
                // Image 2 Style: Hatched Dimension Bars (x, 3x, 4x)
                var barThick = 7.5;
                for (var tx = 0; tx < distinctX.length - 1; tx++) {
                    var wX = distinctX[tx + 1] - distinctX[tx];
                    if (wX >= maxDim * 0.035) {
                        var rX = Math.round((wX / baseUnit) * 2) / 2;
                        var lblX = (rX === 1) ? "x" : (rX + "x");
                        drawHatchedDimensionBar(dimGroup, distinctX[tx], spanT + barThick + 3, wX, barThick, false, lblX, { colorRgb: [130, 135, 145] });
                    }
                }

                for (var ty = 0; ty < distinctY.length - 1; ty++) {
                    var hY = distinctY[ty + 1] - distinctY[ty];
                    if (hY >= maxDim * 0.035) {
                        var rY = Math.round((hY / baseUnit) * 2) / 2;
                        var lblY = (rY === 1) ? "x" : (rY + "x");
                        drawHatchedDimensionBar(dimGroup, spanL - barThick - 3, distinctY[ty + 1], barThick, hY, true, lblY, { colorRgb: [130, 135, 145] });
                    }
                }
            }
        }

        // 7. ANCHORS & HANDLES GROUP
        var anchorGroup = mainGroup.groupItems.add();
        anchorGroup.name = "GRP_ANCHORS";
        anchorGroup.hidden = (params.enableAnchors === false);

        if (params.enableAnchors !== false && !isGuide) {
            var aScale = (params.anchors && params.anchors.scale) || 3.2;
            var aStrokeW = (params.anchors && params.anchors.strokeWidth) || 0.65;
            var aFillCol = (params.anchors && params.anchors.fillColor);
            var aStrokeCol = (params.anchors && params.anchors.strokeColor) || [60, 65, 75];
            var aOpacity = (params.anchors && typeof params.anchors.opacity === "number") ? params.anchors.opacity : 100;

            var aStyle = {
                colorRgb: aStrokeCol, strokeWidth: aStrokeW,
                filled: !!aFillCol, fillRgb: aFillCol || [255, 255, 255],
                opacity: aOpacity, renderMode: "lines"
            };

            for (var pa2 = 0; pa2 < pathItems.length; pa2++) {
                var apts2 = pathItems[pa2].pathPoints;
                for (var ap2 = 0; ap2 < apts2.length; ap2++) {
                    var apt = apts2[ap2];
                    var aDot = anchorGroup.pathItems.ellipse(apt.anchor[1] + (aScale / 2), apt.anchor[0] - (aScale / 2), aScale, aScale);
                    StyleManager.applyStyle(aDot, aStyle);
                }
            }
        }

        // 8. HANDLES GROUP
        var handleGroup = mainGroup.groupItems.add();
        handleGroup.name = "GRP_HANDLES";
        handleGroup.hidden = (params.enableHandles !== true);

        if (params.enableHandles === true && !isGuide) {
            var hStyle = {
                colorRgb: [130, 135, 145], strokeWidth: 0.4,
                opacity: 75, renderMode: "lines"
            };
            var hDotStyle = {
                colorRgb: [130, 135, 145], strokeWidth: 0.4,
                filled: true, fillRgb: [130, 135, 145],
                opacity: 80, renderMode: "lines"
            };

            for (var ph = 0; ph < pathItems.length; ph++) {
                var hPts = pathItems[ph].pathPoints;
                for (var ih = 0; ih < hPts.length; ih++) {
                    var ptH = hPts[ih];
                    var anc = [ptH.anchor[0], ptH.anchor[1]];
                    var ld = [ptH.leftDirection[0], ptH.leftDirection[1]];
                    var rd = [ptH.rightDirection[0], ptH.rightDirection[1]];

                    if (dist(anc, ld) > 1.0) {
                        drawLine(handleGroup, anc, ld, hStyle);
                        var lDot = handleGroup.pathItems.ellipse(ld[1] + 1.2, ld[0] - 1.2, 2.4, 2.4);
                        StyleManager.applyStyle(lDot, hDotStyle);
                    }
                    if (dist(anc, rd) > 1.0) {
                        drawLine(handleGroup, anc, rd, hStyle);
                        var rDot = handleGroup.pathItems.ellipse(rd[1] + 1.2, rd[0] - 1.2, 2.4, 2.4);
                        StyleManager.applyStyle(rDot, hDotStyle);
                    }
                }
            }
        }

        return mainGroup;
    };

    // Helper: Extract precise core logo bounds from tagged group or tight anchor/outline bounds (Ignores outer extended rays)
    function getGroupCoreBounds(group) {
        if (!group) return null;
        try {
            if (group.tags) {
                for (var t = 0; t < group.tags.length; t++) {
                    if (group.tags[t].name === "MKD_CORE_BOUNDS") {
                        var parts = group.tags[t].value.split(",");
                        return {
                            left: parseFloat(parts[0]),
                            top: parseFloat(parts[1]),
                            right: parseFloat(parts[2]),
                            bottom: parseFloat(parts[3])
                        };
                    }
                }
            }
        } catch (eTag) {}

        try {
            var anchorGrps = findAllGroupsRecursive(group, "GRP_ANCHORS");
            if (anchorGrps && anchorGrps.length > 0) {
                var ab = anchorGrps[0].geometricBounds;
                return {
                    left: Math.min(ab[0], ab[2]),
                    top: Math.max(ab[1], ab[3]),
                    right: Math.max(ab[0], ab[2]),
                    bottom: Math.min(ab[1], ab[3])
                };
            }
        } catch (eA) {}

        try {
            var outlines = findAllGroupsRecursive(group, "GRP_OUTLINES");
            if (outlines && outlines.length > 0) {
                var ob = outlines[0].geometricBounds;
                return {
                    left: Math.min(ob[0], ob[2]),
                    top: Math.max(ob[1], ob[3]),
                    right: Math.max(ob[0], ob[2]),
                    bottom: Math.min(ob[1], ob[3])
                };
            }
        } catch (eO) {}

        try {
            var gb = group.geometricBounds;
            var cx = (gb[0] + gb[2]) / 2;
            var cy = (gb[1] + gb[3]) / 2;
            return {
                left: cx - 40, top: cy + 40, right: cx + 40, bottom: cy - 40
            };
        } catch (eC) {
            return null;
        }
    }

    function checkCoreOverlap(b1, b2, padding) {
        if (!b1 || !b2) return false;
        var pad = (typeof padding === "number") ? padding : 20;
        return !(b1.right < b2.left - pad ||
                 b1.left > b2.right + pad ||
                 b1.top < b2.bottom - pad ||
                 b1.bottom > b2.top + pad);
    }

    /**
     * Master Construction Grid Generator (Supports Multiple Logos & Non-Destructive Multi-Selection)
     */
    self.generateAllConstruction = function (doc, params) {
        params = params || {};
        var selection = doc.selection;
        if (!selection || selection.length === 0) {
            throw new Error("Please select your logo vector artwork first.");
        }

        // Explicitly unlock selected artwork and its layer
        for (var s = 0; s < selection.length; s++) {
            try {
                if (selection[s].layer && selection[s].layer.locked) selection[s].layer.locked = false;
                selection[s].locked = false;
            } catch (e) {}
        }

        var clusters = groupSelectionIntoArtworks(selection);
        if (clusters.length === 0) {
            throw new Error("No vector objects found in selection.");
        }

        var isGuide = (params.renderMode === "guides");
        var rootLayer = StyleManager.getOrCreateLayer(doc, isGuide ? "[GRID] Guides" : "[GRID] Construction", isGuide);
        try {
            rootLayer.locked = false;
            rootLayer.visible = true;
            rootLayer.zOrder(ZOrderMethod.SENDTOBACK);
        } catch (e) {}

        var generatedCount = 0;

        for (var cl = 0; cl < clusters.length; cl++) {
            var cluster = clusters[cl];
            var pathItems = self.collectPathItems(cluster.items);
            if (pathItems.length === 0) continue;

            var left = cluster.bounds.left;
            var top = cluster.bounds.top;
            var right = cluster.bounds.right;
            var bottom = cluster.bounds.bottom;
            var width = right - left;
            var height = top - bottom;
            var maxDim = Math.max(width, height);
            if (maxDim < 5) continue;

            // Remove existing construction group ONLY if its CORE LOGO matches this specific cluster
            for (var g = rootLayer.groupItems.length - 1; g >= 0; g--) {
                var exG = rootLayer.groupItems[g];
                if (exG.name && exG.name.indexOf("Construction System") === 0) {
                    var exCore = getGroupCoreBounds(exG);
                    if (exCore) {
                        var isMatch = checkCoreOverlap({ left: left, top: top, right: right, bottom: bottom }, exCore, 25);
                        if (isMatch) {
                            exG.remove();
                        }
                    }
                }
            }

            var mainGroup = rootLayer.groupItems.add();
            mainGroup.name = "Construction System" + (clusters.length > 1 ? (" #" + (cl + 1)) : "");
            try {
                var tagB = mainGroup.tags.add();
                tagB.name = "MKD_CORE_BOUNDS";
                tagB.value = Math.round(left) + "," + Math.round(top) + "," + Math.round(right) + "," + Math.round(bottom);
            } catch (eTag) {}

            try {
                mainGroup.zOrder(ZOrderMethod.SENDTOBACK);
            } catch (e) {}

            // Apply Blueprint Presentation Styling (Subdued / Dimmed logo with dark outline)
            applyPresentationStylingToArtwork(cluster.items, params);

            self.buildSingleConstructionGrid(doc, mainGroup, pathItems, left, top, right, bottom, maxDim, params, isGuide);
            generatedCount++;
        }

        if (generatedCount === 0) {
            throw new Error("No vector paths could be processed.");
        }

        return { success: true, count: generatedCount };
    };

    /**
     * Real-Time Live Sync Engine (Selection-Targeted: Only updates the selected logo's grid)
     */
    self.liveUpdateStyles = function (doc, params) {
        params = params || {};
        var foundAny = false;

        // Target only the active selection's bounding zone if something is selected
        var selBounds = null;
        if (doc.selection && doc.selection.length > 0) {
            try {
                var sgb = BaseGrids.getTargetBounds(doc, "selection");
                selBounds = {
                    left: sgb[0], top: sgb[1], right: sgb[2], bottom: sgb[3]
                };
                // Live update the logo artwork styling if selected
                applyPresentationStylingToArtwork(doc.selection, params);
            } catch (e) {}
        }

        for (var l = 0; l < doc.layers.length; l++) {
            var layer = doc.layers[l];
            if (layer.name.indexOf("[GRID]") === 0) {
                var systemGroups = [];
                for (var gi = 0; gi < layer.groupItems.length; gi++) {
                    var tg = layer.groupItems[gi];
                    if (tg.name && tg.name.indexOf("Construction System") === 0) {
                        systemGroups.push(tg);
                    }
                }

                if (systemGroups.length === 0) {
                    systemGroups.push(layer);
                }

                for (var s = 0; s < systemGroups.length; s++) {
                    var sysGroup = systemGroups[s];

                    // When an object is selected, strictly target only the grid matching that selected object's CORE bounds!
                    if (selBounds && sysGroup !== layer) {
                        var sysCore = getGroupCoreBounds(sysGroup);
                        if (sysCore) {
                            var isMatch = checkCoreOverlap(selBounds, sysCore, 30);
                            if (!isMatch) {
                                continue; // Keep other logo/text grids completely untouched!
                            }
                        }
                    }

                    // A. GRP_GRIDLINES
                    var gGrps = findAllGroupsRecursive(sysGroup, "GRP_GRIDLINES");
                    for (var gg = 0; gg < gGrps.length; gg++) {
                        var gGrp = gGrps[gg];
                        foundAny = true;
                        if (typeof params.enableGridlines === "boolean") gGrp.hidden = !params.enableGridlines;
                        if (params.gridlines) {
                            var gCol = StyleManager.createRGBColor(params.gridlines.strokeColor || [180, 185, 195]);
                            for (var gi2 = 0; gi2 < gGrp.pathItems.length; gi2++) {
                                var gItem = gGrp.pathItems[gi2];
                                if (params.gridlines.strokeWidth) gItem.strokeWidth = params.gridlines.strokeWidth;
                                if (params.gridlines.strokeColor) gItem.strokeColor = gCol;
                                if (typeof params.gridlines.opacity === "number") gItem.opacity = params.gridlines.opacity;
                            }
                        }
                    }

                    // B. GRP_EDGERAYS
                    var erGrps = findAllGroupsRecursive(sysGroup, "GRP_EDGERAYS");
                    for (var eg = 0; eg < erGrps.length; eg++) {
                        var erGrp = erGrps[eg];
                        foundAny = true;
                        if (typeof params.enableEdgeRays === "boolean") erGrp.hidden = !params.enableEdgeRays;
                        if (params.edgeRays) {
                            var erW = params.edgeRays.strokeWidth;
                            var erCol = params.edgeRays.strokeColor;
                            var erOp = params.edgeRays.opacity;
                            var erC = erCol ? StyleManager.createRGBColor(erCol) : null;
                            for (var eri = 0; eri < erGrp.pathItems.length; eri++) {
                                var erItem = erGrp.pathItems[eri];
                                if (typeof erW === "number") erItem.strokeWidth = erW;
                                if (erC) erItem.strokeColor = erC;
                                if (typeof erOp === "number") erItem.opacity = erOp;
                            }
                        }
                    }

                    // C. GRP_OUTLINES (Curves & Circles)
                    var oGrps = findAllGroupsRecursive(sysGroup, "GRP_OUTLINES");
                    for (var og = 0; og < oGrps.length; og++) {
                        var oGrp = oGrps[og];
                        foundAny = true;
                        if (typeof params.enableOutlines === "boolean") oGrp.hidden = !params.enableOutlines;
                        if (params.outlines) {
                            var oCol = StyleManager.createRGBColor(params.outlines.strokeColor || [140, 150, 165]);
                            for (var oi = 0; oi < oGrp.pathItems.length; oi++) {
                                var oItem = oGrp.pathItems[oi];
                                if (typeof params.outlines.strokeWidth === "number") oItem.strokeWidth = params.outlines.strokeWidth;
                                if (params.outlines.strokeColor) oItem.strokeColor = oCol;
                                if (typeof params.outlines.opacity === "number") oItem.opacity = params.outlines.opacity;
                            }
                        }
                    }

                    // D. GRP_DIMENSIONS
                    var dGrps = findAllGroupsRecursive(sysGroup, "GRP_DIMENSIONS");
                    for (var dg = 0; dg < dGrps.length; dg++) {
                        foundAny = true;
                        if (typeof params.enableDimensions === "boolean") dGrps[dg].hidden = !params.enableDimensions;
                    }

                    // E. GRP_ANGLES
                    var anGrps = findAllGroupsRecursive(sysGroup, "GRP_ANGLES");
                    for (var ag = 0; ag < anGrps.length; ag++) {
                        foundAny = true;
                        if (typeof params.enableAngleCallouts === "boolean") anGrps[ag].hidden = !params.enableAngleCallouts;
                    }

                    // F. GRP_HANDLES
                    var hGrps = findAllGroupsRecursive(sysGroup, "GRP_HANDLES");
                    for (var hg = 0; hg < hGrps.length; hg++) {
                        foundAny = true;
                        if (typeof params.enableHandles === "boolean") hGrps[hg].hidden = !params.enableHandles;
                    }

                    // G. GRP_ANCHORS
                    var aGrps = findAllGroupsRecursive(sysGroup, "GRP_ANCHORS");
                    for (var aag = 0; aag < aGrps.length; aag++) {
                        foundAny = true;
                        if (typeof params.enableAnchors === "boolean") aGrps[aag].hidden = !params.enableAnchors;
                        if (params.anchors) {
                            var aCol = StyleManager.createRGBColor(params.anchors.strokeColor || [60, 65, 75]);
                            var aFill = params.anchors.fillColor ? StyleManager.createRGBColor(params.anchors.fillColor) : null;
                            for (var ai = 0; ai < aGrps[aag].pathItems.length; ai++) {
                                var aDot = aGrps[aag].pathItems[ai];
                                if (typeof params.anchors.strokeWidth === "number") aDot.strokeWidth = params.anchors.strokeWidth;
                                if (params.anchors.strokeColor) aDot.strokeColor = aCol;
                                if (aFill) {
                                    aDot.filled = true;
                                    aDot.fillColor = aFill;
                                } else if (params.anchors.fillColor === null) {
                                    aDot.filled = false;
                                }
                                if (typeof params.anchors.opacity === "number") aDot.opacity = params.anchors.opacity;
                                if (typeof params.anchors.scale === "number" && aDot.width && aDot.height) {
                                    var cx = aDot.left + aDot.width / 2;
                                    var cy = aDot.top - aDot.height / 2;
                                    var newSize = params.anchors.scale * 2;
                                    aDot.width = newSize;
                                    aDot.height = newSize;
                                    aDot.left = cx - newSize / 2;
                                    aDot.top = cy + newSize / 2;
                                }
                            }
                        }
                    }
                }
            }
        }

        return { success: true, updated: foundAny };
    };

    return self;
})();
