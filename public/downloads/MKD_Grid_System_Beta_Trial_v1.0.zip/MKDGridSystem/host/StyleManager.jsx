/**
 * Logo Grid Studio - Style & Layer Manager (Upgraded)
 * Supports both Native Guide Mode and Vector Lines Mode (with Hatching, Dimension text, and Style Presets).
 */

var StyleManager = (function () {
    var self = {};

    // Built-in Color Themes
    self.PALETTES = {
        slate: {
            name: "Technical Slate (Reference)",
            primary: [150, 155, 165],     // Clean Technical Gray
            secondary: [185, 190, 200],   // Faded Grid Gray
            accent: [60, 64, 72],         // Dark Charcoal for Text & Marks
            subtle: [210, 215, 225],      // Light Gray Hatching
            text: [50, 55, 65]            // Crisp Dark Gray for Dimension Labels
        },
        blueprint: {
            name: "Cyan Blueprint",
            primary: [0, 210, 255],
            secondary: [0, 140, 200],
            accent: [255, 107, 107],
            subtle: [0, 90, 140],
            text: [0, 210, 255]
        },
        golden: {
            name: "Golden Hour",
            primary: [245, 166, 35],
            secondary: [210, 120, 20],
            accent: [255, 75, 75],
            subtle: [190, 140, 50],
            text: [245, 166, 35]
        },
        monochrome: {
            name: "Monochrome Black",
            primary: [80, 80, 80],
            secondary: [160, 160, 160],
            accent: [30, 30, 30],
            subtle: [200, 200, 200],
            text: [30, 30, 30]
        },
        cyber: {
            name: "Neon Cyber",
            primary: [255, 0, 128],
            secondary: [121, 40, 202],
            accent: [0, 245, 212],
            subtle: [90, 30, 110],
            text: [255, 0, 128]
        }
    };

    /**
     * Get or create a target layer by name.
     */
    self.getOrCreateLayer = function (doc, layerName, isGuideLayer) {
        var layer;
        try {
            layer = doc.layers.getByName(layerName);
        } catch (e) {
            layer = doc.layers.add();
            layer.name = layerName;
        }

        try {
            layer.locked = false;
            layer.visible = true;
        } catch (e) {}

        if (isGuideLayer) {
            layer.printable = false;
        }

        // Place [GRID] layer at the bottom of the layer stack (underneath the logo)
        try {
            layer.zOrder(ZOrderMethod.SENDTOBACK);
        } catch (e) {}

        return layer;
    };

    /**
     * Convert an RGB array [r, g, b] into an Illustrator RGBColor object.
     */
    self.createRGBColor = function (rgbArray) {
        var color = new RGBColor();
        color.red = Math.round(rgbArray[0]);
        color.green = Math.round(rgbArray[1]);
        color.blue = Math.round(rgbArray[2]);
        return color;
    };

    /**
     * Apply styling to a PathItem.
     * @param {PathItem} pathItem
     * @param {Object} options - { colorRgb, strokeWidth, opacity, dashed, renderMode: "lines"|"guides", filled, fillRgb }
     */
    self.applyStyle = function (pathItem, options) {
        if (!pathItem) return;
        options = options || {};

        // If Guide Mode is selected, make it a native Illustrator guide
        if (options.renderMode === "guides" || options.isGuide === true) {
            pathItem.guides = true;
            return;
        }

        // Vector Lines Mode
        pathItem.stroked = true;
        var strokeCol = options.colorRgb || [150, 155, 165];
        pathItem.strokeColor = self.createRGBColor(strokeCol);
        pathItem.strokeWidth = (typeof options.strokeWidth === "number") ? options.strokeWidth : 0.6;
        pathItem.opacity = (typeof options.opacity === "number") ? options.opacity : 100;

        if (options.dashed) {
            pathItem.strokeDashes = [4, 4];
        } else {
            pathItem.strokeDashes = [];
        }

        if (options.filled && options.fillRgb) {
            pathItem.filled = true;
            pathItem.fillColor = self.createRGBColor(options.fillRgb);
        } else {
            pathItem.filled = false;
        }
    };

    /**
     * Tags original appearance (opacity, fill, stroke) on a page item so it can be restored 100% later.
     */
    self.tagOriginalAppearance = function (it) {
        if (!it) return;
        try {
            if (it.layer && it.layer.name && it.layer.name.indexOf("[GRID") === 0) return;
            if (it.name && (it.name.indexOf("Construction System") === 0 || it.name.indexOf("Clearspace") === 0)) return;
        } catch (e) {}

        try {
            if (it.typename === "PathItem" && it.tags) {
                var hasTag = false;
                for (var t = 0; t < it.tags.length; t++) {
                    if (it.tags[t].name === "MKD_ORIG_OPACITY") { hasTag = true; break; }
                }
                if (!hasTag) {
                    var tagOp = it.tags.add();
                    tagOp.name = "MKD_ORIG_OPACITY";
                    tagOp.value = String(it.opacity);

                    var tagFilled = it.tags.add();
                    tagFilled.name = "MKD_ORIG_FILLED";
                    tagFilled.value = it.filled ? "1" : "0";

                    if (it.filled && it.fillColor && it.fillColor.typename === "RGBColor") {
                        var tagFillCol = it.tags.add();
                        tagFillCol.name = "MKD_ORIG_FILL_RGB";
                        tagFillCol.value = Math.round(it.fillColor.red) + "," + Math.round(it.fillColor.green) + "," + Math.round(it.fillColor.blue);
                    }

                    var tagStroked = it.tags.add();
                    tagStroked.name = "MKD_ORIG_STROKED";
                    tagStroked.value = it.stroked ? "1" : "0";

                    if (it.stroked) {
                        var tagSW = it.tags.add();
                        tagSW.name = "MKD_ORIG_STROKE_WIDTH";
                        tagSW.value = String(it.strokeWidth);

                        if (it.strokeColor && it.strokeColor.typename === "RGBColor") {
                            var tagStrCol = it.tags.add();
                            tagStrCol.name = "MKD_ORIG_STROKE_RGB";
                            tagStrCol.value = Math.round(it.strokeColor.red) + "," + Math.round(it.strokeColor.green) + "," + Math.round(it.strokeColor.blue);
                        }
                    }
                }
            } else if (it.typename === "CompoundPathItem") {
                for (var cp = 0; cp < it.pathItems.length; cp++) {
                    self.tagOriginalAppearance(it.pathItems[cp]);
                }
            } else if (it.typename === "GroupItem") {
                for (var g = 0; g < it.pageItems.length; g++) {
                    self.tagOriginalAppearance(it.pageItems[g]);
                }
            }
        } catch (e) {}
    };

    /**
     * Restores original appearance (opacity, fill, stroke) on a page item.
     */
    self.restoreItemAppearanceRecursive = function (it) {
        if (!it) return;
        try {
            if (it.layer && it.layer.name && it.layer.name.indexOf("[GRID") === 0) return;
            if (it.name && (it.name.indexOf("Construction System") === 0 || it.name.indexOf("Clearspace") === 0)) return;
        } catch (e) {}

        try {
            if (it.layer && it.layer.locked) it.layer.locked = false;
            it.hidden = false;
            it.locked = false;
            it.opacity = 100;
        } catch (e) {}

        try {
            var origOpacity = null, origFilled = null, origFillRgb = null, origStroked = null, origSW = null, origStrCol = null;
            if (it.tags) {
                for (var t = it.tags.length - 1; t >= 0; t--) {
                    var tName = it.tags[t].name;
                    var tVal = it.tags[t].value;
                    if (tName === "MKD_ORIG_OPACITY") origOpacity = parseFloat(tVal);
                    else if (tName === "MKD_ORIG_FILLED") origFilled = (tVal === "1");
                    else if (tName === "MKD_ORIG_FILL_RGB") origFillRgb = tVal.split(",");
                    else if (tName === "MKD_ORIG_STROKED") origStroked = (tVal === "1");
                    else if (tName === "MKD_ORIG_STROKE_WIDTH") origSW = parseFloat(tVal);
                    else if (tName === "MKD_ORIG_STROKE_RGB") origStrCol = tVal.split(",");
                    try { it.tags[t].remove(); } catch (e) {}
                }
            }

            if (origOpacity !== null) it.opacity = origOpacity;

            if (it.typename === "PathItem") {
                if (origFilled !== null) it.filled = origFilled;
                if (origFillRgb && it.filled) {
                    var fRgb = self.createRGBColor([parseInt(origFillRgb[0], 10), parseInt(origFillRgb[1], 10), parseInt(origFillRgb[2], 10)]);
                    it.fillColor = fRgb;
                }
                if (origStroked !== null) {
                    it.stroked = origStroked;
                    if (origStroked) {
                        if (origSW !== null) it.strokeWidth = origSW;
                        if (origStrCol) {
                            var sRgb = self.createRGBColor([parseInt(origStrCol[0], 10), parseInt(origStrCol[1], 10), parseInt(origStrCol[2], 10)]);
                            it.strokeColor = sRgb;
                        }
                    }
                }
            } else if (it.typename === "CompoundPathItem") {
                for (var cp2 = 0; cp2 < it.pathItems.length; cp2++) {
                    self.restoreItemAppearanceRecursive(it.pathItems[cp2]);
                }
            } else if (it.typename === "GroupItem") {
                for (var g2 = 0; g2 < it.pageItems.length; g2++) {
                    self.restoreItemAppearanceRecursive(it.pageItems[g2]);
                }
            }
        } catch (e) {}
    };

    return self;
})();
