/**
 * Logo Grid Studio - ExtendScript Host Entry Point (v3.0 Live Customization)
 */

#include "StyleManager.jsx"
#include "BaseGrids.jsx"
#include "ConstructionGrids.jsx"
#include "ClearspaceGrids.jsx"

// ES3 Array Polyfills for ExtendScript compatibility
if (!Array.prototype.map) {
    Array.prototype.map = function (callback, thisArg) {
        var T, A, k;
        if (this == null) throw new TypeError('this is null or not defined');
        var O = Object(this);
        var len = O.length >>> 0;
        if (typeof callback !== 'function') throw new TypeError(callback + ' is not a function');
        if (arguments.length > 1) T = thisArg;
        A = new Array(len);
        k = 0;
        while (k < len) {
            var kValue, mappedValue;
            if (k in O) {
                kValue = O[k];
                mappedValue = callback.call(T, kValue, k, O);
                A[k] = mappedValue;
            }
            k++;
        }
        return A;
    };
}

if (!Array.prototype.filter) {
    Array.prototype.filter = function (func, thisArg) {
        if (this == null) throw new TypeError('this is null or not defined');
        var t = Object(this);
        var len = t.length >>> 0;
        if (typeof func !== 'function') throw new TypeError(func + ' is not a function');
        var res = [];
        var thisArgVal = arguments.length >= 2 ? thisArg : void 0;
        for (var i = 0; i < len; i++) {
            if (i in t) {
                var val = t[i];
                if (func.call(thisArgVal, val, i, t)) res.push(val);
            }
        }
        return res;
    };
}

if (!Array.prototype.forEach) {
    Array.prototype.forEach = function (callback, thisArg) {
        if (this == null) throw new TypeError('this is null or not defined');
        var T, k;
        var O = Object(this);
        var len = O.length >>> 0;
        if (typeof callback !== 'function') throw new TypeError(callback + ' is not a function');
        if (arguments.length > 1) T = thisArg;
        k = 0;
        while (k < len) {
            if (k in O) callback.call(T, O[k], k, O);
            k++;
        }
    };
}

if (typeof JSON === "undefined") {
    JSON = {
        parse: function (s) { return eval("(" + s + ")"); },
        stringify: function (obj) {
            var t = typeof obj;
            if (t !== "object" || obj === null) {
                if (t === "string") return '"' + obj.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
                return String(obj);
            }
            var json = [];
            var isArr = (obj && obj.constructor === Array);
            for (var k in obj) {
                if (obj.hasOwnProperty(k)) {
                    var v = obj[k];
                    var str = (isArr ? "" : '"' + k + '":') + JSON.stringify(v);
                    json.push(str);
                }
            }
            return (isArr ? "[" : "{") + json.join(",") + (isArr ? "]" : "}");
        }
    };
}

var LogoGridHost = (function () {
    var self = {};

    self.execute = function (action, jsonParams) {
        try {
            if (!app.documents || app.documents.length === 0) {
                return JSON.stringify({ success: false, error: "No active document open in Illustrator. Please open or create a document." });
            }

            var doc = app.activeDocument;
            var params = jsonParams ? JSON.parse(jsonParams) : {};

            switch (action) {
                case "ping":
                    return JSON.stringify({ success: true, message: "Logo Grid Studio connected.", docName: doc.name });

                case "generateAllConstruction":
                    ConstructionGrids.generateAllConstruction(doc, params);
                    break;

                case "liveUpdateStyles":
                    ConstructionGrids.liveUpdateStyles(doc, params);
                    break;

                case "generateSquareGrid":
                    BaseGrids.generateSquareGrid(doc, params);
                    break;

                case "generateIsometricGrid":
                    BaseGrids.generateIsometricGrid(doc, params);
                    break;

                case "generateGoldenRatioGrid":
                    BaseGrids.generateGoldenRatioGrid(doc, params);
                    break;

                case "generatePolarGrid":
                    BaseGrids.generatePolarGrid(doc, params);
                    break;

                case "generateClearspace":
                    ClearspaceGrids.generateClearspace(doc, params);
                    break;

                case "captureCornerVector":
                    var capRes = ClearspaceGrids.captureCornerVector(doc);
                    return JSON.stringify(capRes);

                case "importCornerSVG":
                    var impRes = ClearspaceGrids.importCornerSVG(doc, params.path || params);
                    return JSON.stringify(impRes);

                case "clearGridLayers":
                    var sel = doc.selection;
                    var hasSelection = (sel && sel.length > 0);

                    if (hasSelection) {
                        // Case A: Targeted Selection Clear (Selected Logo Only)
                        var selBounds = BaseGrids.getTargetBounds(doc, "selection");
                        var sL = selBounds[0], sT = selBounds[1], sR = selBounds[2], sB = selBounds[3];
                        var removedCount = 0;

                        // 1. Restore the selected logo artwork's appearance
                        for (var si = 0; si < sel.length; si++) {
                            StyleManager.restoreItemAppearanceRecursive(sel[si]);
                        }

                        // 2. Iterate through all [GRID*] layers and remove only groups/items overlapping this logo
                        for (var li = doc.layers.length - 1; li >= 0; li--) {
                            var lyr = doc.layers[li];
                            if (lyr.name.indexOf("[GRID") === 0 && lyr.name !== "[GRID_TEMPLATE_CORNER]") {
                                try { lyr.locked = false; } catch (e) {}
                                for (var gi = lyr.groupItems.length - 1; gi >= 0; gi--) {
                                    var grp = lyr.groupItems[gi];
                                    try {
                                        var ggb = grp.geometricBounds;
                                        var gL = Math.min(ggb[0], ggb[2]), gR = Math.max(ggb[0], ggb[2]);
                                        var gT = Math.max(ggb[1], ggb[3]), gB = Math.min(ggb[1], ggb[3]);

                                        var isOverlap = !(sR + 40 < gL || sL - 40 > gR || sT + 40 < gB || sB - 40 > gT);
                                        if (isOverlap) {
                                            grp.remove();
                                            removedCount++;
                                        }
                                    } catch (e) {}
                                }

                                for (var pi = lyr.pathItems.length - 1; pi >= 0; pi--) {
                                    var pth = lyr.pathItems[pi];
                                    try {
                                        var pgb = pth.geometricBounds;
                                        var pL = Math.min(pgb[0], pgb[2]), pR = Math.max(pgb[0], pgb[2]);
                                        var pT = Math.max(pgb[1], pgb[3]), pB = Math.min(pgb[1], pgb[3]);

                                        var isOverlapP = !(sR + 40 < pL || sL - 40 > pR || sT + 40 < pB || sB - 40 > pT);
                                        if (isOverlapP) {
                                            pth.remove();
                                            removedCount++;
                                        }
                                    } catch (e) {}
                                }

                                // If layer is now completely empty, remove the layer
                                if (lyr.pageItems.length === 0) {
                                    try { lyr.remove(); } catch (e) {}
                                }
                            }
                        }

                        app.redraw();
                        return JSON.stringify({ success: true, message: "Cleared grid for selected logo and restored original artwork appearance." });

                    } else {
                        // Case B: Full Canvas Clear (Nothing Selected)
                        var deletedCount = 0;
                        for (var i = doc.layers.length - 1; i >= 0; i--) {
                            var lName = doc.layers[i].name;
                            if (lName.indexOf("[GRID") === 0 && lName !== "[GRID_TEMPLATE_CORNER]") {
                                doc.layers[i].remove();
                                deletedCount++;
                            }
                        }

                        // Restore all items in all remaining layers to 100% opacity & original style
                        for (var rem = 0; rem < doc.layers.length; rem++) {
                            var rLyr = doc.layers[rem];
                            if (rLyr.name.indexOf("[GRID") !== 0) {
                                for (var rpi = 0; rpi < rLyr.pageItems.length; rpi++) {
                                    StyleManager.restoreItemAppearanceRecursive(rLyr.pageItems[rpi]);
                                }
                            }
                        }

                        app.redraw();
                        return JSON.stringify({ success: true, message: "Cleared all " + deletedCount + " grid layers across artboard." });
                    }

                default:
                    return JSON.stringify({ success: false, error: "Unknown action: " + action });
            }

            app.redraw();
            return JSON.stringify({ success: true, message: "Action executed successfully." });
        } catch (err) {
            return JSON.stringify({ success: false, error: err.message || String(err) });
        }
    };

    return self;
})();
