/**
 * MKD Grid System - Frontend Client Application Logic (v4.1 Live Post-Generation Styling)
 */

document.addEventListener("DOMContentLoaded", function () {
    var csInterface = new CSInterface();

    var statusMsg = document.getElementById("status-msg");
    function setStatus(text, isError) {
        if (!statusMsg) return;
        statusMsg.textContent = text;
        statusMsg.style.color = isError ? "var(--accent-coral)" : "var(--text-muted)";
    }

    // Ping Host
    csInterface.evalScript("LogoGridHost.execute('ping')", function (res) {
        try {
            var data = JSON.parse(res);
            if (data && data.success) {
                setStatus("Connected: " + (data.docName || "Active Doc"));
            }
        } catch (e) {}
    });

    function hexToRgb(hex) {
        if (!hex) return [0, 0, 0];
        var c = hex.replace("#", "");
        if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
        var num = parseInt(c, 16);
        return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
    }

    // =========================================================================
    // 1. TOP TABS SWITCHING (Base, Construction, Clearspace)
    // =========================================================================
    var tabBtns = document.querySelectorAll(".tab-btn");
    var tabContents = document.querySelectorAll(".tab-content");

    tabBtns.forEach(function (btn) {
        btn.addEventListener("click", function () {
            tabBtns.forEach(function (b) { b.classList.remove("active"); });
            tabContents.forEach(function (tc) { tc.classList.remove("active"); });
            btn.classList.add("active");
            var targetId = btn.getAttribute("data-tab");
            var target = document.getElementById(targetId);
            if (target) target.classList.add("active");
        });
    });

    // =========================================================================
    // 2. BASE GRIDS TAB (EXPLICIT GENERATE ONLY)
    // =========================================================================
    var baseCards = document.querySelectorAll(".base-card");
    var activeBaseType = "square";

    baseCards.forEach(function (card) {
        card.addEventListener("click", function () {
            baseCards.forEach(function (c) { c.classList.remove("active"); });
            card.classList.add("active");
            activeBaseType = card.getAttribute("data-type");
            var cardName = card.querySelector(".base-card-name") ? card.querySelector(".base-card-name").textContent : activeBaseType;
            setStatus("Selected: " + cardName + " pattern. Click 'Generate Base Grid' to apply.");
        });
    });

    var rngBaseDiv = document.getElementById("rng-base-divisions");
    var numBaseDiv = document.getElementById("num-base-divisions");
    if (rngBaseDiv && numBaseDiv) {
        var baseDivHandler = function () {
            numBaseDiv.textContent = rngBaseDiv.value;
        };
        rngBaseDiv.addEventListener("input", baseDivHandler);
        rngBaseDiv.addEventListener("change", baseDivHandler);
    }

    function generateBaseGrid() {
        var targetMode = document.getElementById("base-target-select") ? document.getElementById("base-target-select").value : "selection";
        var divisions = parseInt(document.getElementById("rng-base-divisions").value, 10) || 8;
        var diagonals = document.getElementById("chk-base-diagonals") ? document.getElementById("chk-base-diagonals").checked : false;
        var spiral = document.getElementById("chk-base-spiral") ? document.getElementById("chk-base-spiral").checked : true;

        var action = "generateSquareGrid";
        var params = { targetMode: targetMode, cols: divisions, rows: divisions, diagonals: diagonals };

        if (activeBaseType === "isometric") {
            action = "generateIsometricGrid";
            params = { targetMode: targetMode, step: Math.max(8, Math.round(300 / divisions)), includeVerticals: true };
        } else if (activeBaseType === "golden") {
            action = "generateGoldenRatioGrid";
            params = { targetMode: targetMode, concentricCount: Math.min(12, divisions), includeSpiral: spiral };
        } else if (activeBaseType === "polar") {
            action = "generatePolarGrid";
            params = { targetMode: targetMode, rings: divisions, spokes: Math.max(8, divisions * 2) };
        } else if (activeBaseType === "hexagonal") {
            action = "generateHexagonalGrid";
            params = { targetMode: targetMode, sideLength: Math.max(10, Math.round(350 / divisions)), mode: "hexagons" };
        }

        setStatus("Generating Base Grid: " + activeBaseType.toUpperCase() + " (" + divisions + ")...");
        var jsonStr = JSON.stringify(params);
        var escaped = jsonStr.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
        csInterface.evalScript('LogoGridHost.execute("' + action + '", "' + escaped + '")', function (res) {
            try {
                var data = JSON.parse(res);
                if (data && data.success) {
                    setStatus("Base Grid Generated: " + activeBaseType.toUpperCase() + " (" + divisions + ")");
                } else if (data && data.error) {
                    setStatus("Error: " + data.error, true);
                    alert("MKD Grid System: " + data.error);
                } else {
                    setStatus("Base Grid Generated!");
                }
            } catch (e) {
                setStatus("Base Grid Generated!");
            }
        });
    }

    var btnGenBase = document.getElementById("btn-generate-base");
    if (btnGenBase) {
        btnGenBase.addEventListener("click", generateBaseGrid);
    }

    // =========================================================================
    // 3. CONSTRUCTION TAB (REAL-TIME LIVE POST-GENERATION STYLING)
    // =========================================================================
    var constrLiveTimer = null;
    function triggerConstructionLiveUpdate() {
        if (constrLiveTimer) clearTimeout(constrLiveTimer);
        constrLiveTimer = setTimeout(function () {
            var params = collectConstructionParams();
            var jsonStr = JSON.stringify(params);
            var escaped = jsonStr.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
            csInterface.evalScript('LogoGridHost.execute("liveUpdateStyles", "' + escaped + '")', function (res) {
                try {
                    var data = JSON.parse(res);
                    if (data && data.success && data.updated) {
                        setStatus("Live Grid Styling Updated");
                    }
                } catch (e) {}
            });
        }, 25);
    }

    var compBtns = document.querySelectorAll(".comp-btn");
    compBtns.forEach(function (btn) {
        btn.addEventListener("click", function () {
            btn.classList.toggle("active");
            triggerConstructionLiveUpdate();
        });
    });

    // Accordion Toggle
    var accHeader = document.getElementById("acc-header");
    var accBody = document.getElementById("acc-body");
    var arrowIcon = document.querySelector(".arrow-icon");

    if (accHeader && accBody) {
        accHeader.addEventListener("click", function () {
            var isHidden = (accBody.style.display === "none");
            accBody.style.display = isHidden ? "flex" : "none";
            if (arrowIcon) arrowIcon.textContent = isHidden ? "▲" : "▼";
        });
    }

    function collectConstructionParams() {
        var isEdgeRays = document.getElementById("tog-edgerays") ? document.getElementById("tog-edgerays").classList.contains("active") : true;
        var isOutlines = document.getElementById("tog-outlines") ? document.getElementById("tog-outlines").classList.contains("active") : true;
        var isGridlines = document.getElementById("tog-gridlines") ? document.getElementById("tog-gridlines").classList.contains("active") : true;
        var isDimensions = document.getElementById("tog-dimensions") ? document.getElementById("tog-dimensions").classList.contains("active") : true;
        var isAnchors = document.getElementById("tog-anchors") ? document.getElementById("tog-anchors").classList.contains("active") : true;
        var isHandles = document.getElementById("tog-handles") ? document.getElementById("tog-handles").classList.contains("active") : false;

        var dimStyle = document.getElementById("sel-dim-style") ? document.getElementById("sel-dim-style").value : "arrows";
        var isAngles = document.getElementById("chk-angle-callouts") ? document.getElementById("chk-angle-callouts").checked : false;
        var isCenter = document.getElementById("chk-centerlines") ? document.getElementById("chk-centerlines").checked : true;

        var logoStyleMode = "blueprint";
        var btnOrig = document.getElementById("btn-style-original");
        if (btnOrig && btnOrig.classList.contains("active")) {
            logoStyleMode = "original";
        }
        var dimLogo = (logoStyleMode === "blueprint");
        if (document.getElementById("chk-logo-dimming")) {
            dimLogo = document.getElementById("chk-logo-dimming").checked;
            if (!dimLogo) logoStyleMode = "original";
        }
        var logoOpacity = document.getElementById("rng-logo-opacity") ? parseInt(document.getElementById("rng-logo-opacity").value, 10) : (dimLogo ? 65 : 100);

        return {
            renderMode: "lines",
            dimensionStyle: dimStyle,
            logoStyleMode: logoStyleMode,
            dimLogo: dimLogo,
            logoOpacity: logoOpacity,
            enableEdgeRays: isEdgeRays,
            enableOutlines: isOutlines,
            enableGridlines: isGridlines,
            enableDimensions: isDimensions,
            enableAngleCallouts: isAngles,
            enableCenterlines: isCenter,
            enableAnchors: isAnchors,
            enableHandles: isHandles,

            edgeRays: {
                strokeColor: hexToRgb(document.getElementById("col-edgeray-stroke") ? document.getElementById("col-edgeray-stroke").value : "#afb4be"),
                strokeWidth: parseFloat(document.getElementById("rng-edgeray-stroke") ? document.getElementById("rng-edgeray-stroke").value : "0.45") || 0.45,
                overflowPercent: parseInt(document.getElementById("rng-edgeray-overflow") ? document.getElementById("rng-edgeray-overflow").value : "15", 10) || 15,
                opacity: parseInt(document.getElementById("rng-edgeray-opacity") ? document.getElementById("rng-edgeray-opacity").value : "75", 10) || 75
            },
            gridlines: {
                strokeColor: hexToRgb(document.getElementById("col-gridline-stroke").value),
                strokeWidth: parseFloat(document.getElementById("rng-gridline-stroke").value) || 0.45,
                overflowPercent: parseInt(document.getElementById("rng-gridline-overflow").value, 10) || 15,
                opacity: parseInt(document.getElementById("rng-gridline-opacity").value, 10) || 70
            },
            outlines: {
                strokeColor: hexToRgb(document.getElementById("col-outline-stroke").value),
                strokeWidth: parseFloat(document.getElementById("rng-outline-stroke").value) || 0.6,
                opacity: parseInt(document.getElementById("rng-outline-opacity").value, 10) || 85
            },
            anchors: {
                fillColor: document.getElementById("chk-anchor-fill").checked ? hexToRgb(document.getElementById("col-anchor-fill").value) : null,
                strokeColor: hexToRgb(document.getElementById("col-anchor-stroke").value),
                strokeWidth: parseFloat(document.getElementById("rng-anchor-stroke").value) || 0.65,
                scale: parseFloat(document.getElementById("rng-anchor-scale").value) || 3.2,
                opacity: parseInt(document.getElementById("rng-anchor-opacity").value, 10) || 100
            }
        };
    }

    function triggerFullGenerate() {
        setStatus("Generating Shape-Aware Construction Grid...");
        var params = collectConstructionParams();
        var jsonStr = JSON.stringify(params);
        var escaped = jsonStr.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
        csInterface.evalScript('LogoGridHost.execute("generateAllConstruction", "' + escaped + '")', function (res) {
            try {
                var data = JSON.parse(res);
                if (data && data.success) {
                    setStatus("Shape-Aware Construction Grid Generated!");
                } else if (data && data.error) {
                    setStatus("Error: " + data.error, true);
                    alert("MKD Grid System: " + data.error);
                }
            } catch (e) {
                setStatus("Construction Grid Generated!");
            }
        });
    }

    function bindSlider(sliderId, badgeId, suffix, isDec, onChangeCallback) {
        var sl = document.getElementById(sliderId);
        var bd = document.getElementById(badgeId);
        if (!sl || !bd) return;

        var handler = function () {
            var val = parseFloat(sl.value);
            bd.textContent = (isDec ? val.toFixed(2) : Math.round(val)) + (suffix || "");
            if (onChangeCallback) onChangeCallback();
        };

        sl.addEventListener("input", handler);
        sl.addEventListener("change", handler);
    }

    bindSlider("rng-logo-opacity", "num-logo-opacity", "%", false, triggerConstructionLiveUpdate);
    bindSlider("rng-anchor-stroke", "num-anchor-stroke", "", true, triggerConstructionLiveUpdate);
    bindSlider("rng-anchor-scale", "num-anchor-scale", "", true, triggerConstructionLiveUpdate);
    bindSlider("rng-anchor-opacity", "num-anchor-opacity", "%", false, triggerConstructionLiveUpdate);

    bindSlider("rng-edgeray-stroke", "num-edgeray-stroke", "", true, triggerConstructionLiveUpdate);
    bindSlider("rng-edgeray-overflow", "num-edgeray-overflow", "%", false, triggerConstructionLiveUpdate);
    bindSlider("rng-edgeray-opacity", "num-edgeray-opacity", "%", false, triggerConstructionLiveUpdate);

    bindSlider("rng-outline-stroke", "num-outline-stroke", "", true, triggerConstructionLiveUpdate);
    bindSlider("rng-outline-opacity", "num-outline-opacity", "%", false, triggerConstructionLiveUpdate);

    bindSlider("rng-gridline-stroke", "num-gridline-stroke", "", true, triggerConstructionLiveUpdate);
    bindSlider("rng-gridline-overflow", "num-gridline-overflow", "%", false, triggerConstructionLiveUpdate);
    bindSlider("rng-gridline-opacity", "num-gridline-opacity", "%", false, triggerConstructionLiveUpdate);

    var constructionColorInputs = document.querySelectorAll("#tab-construction .color-picker-input");
    constructionColorInputs.forEach(function (inp) {
        inp.addEventListener("input", triggerConstructionLiveUpdate);
        inp.addEventListener("change", triggerConstructionLiveUpdate);
    });

    var constructionToggles = document.querySelectorAll("#tab-construction .toggle-switch input");
    constructionToggles.forEach(function (tog) {
        tog.addEventListener("change", triggerConstructionLiveUpdate);
    });

    // Logo Appearance Mode Toggle Handlers
    var btnStyleBlueprint = document.getElementById("btn-style-blueprint");
    var btnStyleOriginal = document.getElementById("btn-style-original");
    var chkLogoDimming = document.getElementById("chk-logo-dimming");

    if (btnStyleBlueprint && btnStyleOriginal) {
        btnStyleBlueprint.addEventListener("click", function () {
            btnStyleBlueprint.classList.add("active");
            btnStyleOriginal.classList.remove("active");
            if (chkLogoDimming) chkLogoDimming.checked = true;
            triggerConstructionLiveUpdate();
        });

        btnStyleOriginal.addEventListener("click", function () {
            btnStyleOriginal.classList.add("active");
            btnStyleBlueprint.classList.remove("active");
            if (chkLogoDimming) chkLogoDimming.checked = false;
            triggerConstructionLiveUpdate();
        });
    }

    if (chkLogoDimming) {
        chkLogoDimming.addEventListener("change", function () {
            if (chkLogoDimming.checked) {
                if (btnStyleBlueprint) btnStyleBlueprint.classList.add("active");
                if (btnStyleOriginal) btnStyleOriginal.classList.remove("active");
            } else {
                if (btnStyleOriginal) btnStyleOriginal.classList.add("active");
                if (btnStyleBlueprint) btnStyleBlueprint.classList.remove("active");
            }
            triggerConstructionLiveUpdate();
        });
    }

    var btnGenAll = document.getElementById("btn-generate-all");
    if (btnGenAll) {
        btnGenAll.addEventListener("click", triggerFullGenerate);
    }

    // =========================================================================
    // 4. UNIVERSAL CLEAR GRIDS HANDLER (SMART SELECTION AWARE)
    // =========================================================================
    function clearAllGrids() {
        setStatus("Processing grid removal...");
        csInterface.evalScript('LogoGridHost.execute("clearGridLayers", "{}")', function (res) {
            try {
                var data = JSON.parse(res);
                if (data && data.success) {
                    setStatus(data.message || "Grid cleared successfully.");
                } else if (data && data.error) {
                    setStatus("Error: " + data.error, true);
                } else {
                    setStatus("Grid cleared.");
                }
            } catch (e) {
                setStatus("Grid cleared.");
            }
        });
    }

    var btnClearBase = document.getElementById("btn-clear-base");
    if (btnClearBase) btnClearBase.addEventListener("click", clearAllGrids);

    var btnClearLayers = document.getElementById("btn-clear-layers");
    if (btnClearLayers) btnClearLayers.addEventListener("click", clearAllGrids);

    var btnClearClearspace = document.getElementById("btn-clear-clearspace");
    if (btnClearClearspace) btnClearClearspace.addEventListener("click", clearAllGrids);

    // =========================================================================
    // 5. UNIVERSAL RESET SETTINGS HANDLERS
    // =========================================================================
    var btnResetBase = document.getElementById("btn-reset-base");
    if (btnResetBase) {
        btnResetBase.addEventListener("click", function () {
            if (document.getElementById("base-target-select")) document.getElementById("base-target-select").value = "selection";
            if (document.getElementById("rng-base-divisions")) {
                document.getElementById("rng-base-divisions").value = 8;
                document.getElementById("num-base-divisions").textContent = "8";
            }
            if (document.getElementById("chk-base-diagonals")) document.getElementById("chk-base-diagonals").checked = false;
            if (document.getElementById("chk-base-spiral")) document.getElementById("chk-base-spiral").checked = true;
            var baseCards = document.querySelectorAll(".base-card");
            baseCards.forEach(function (card) {
                if (card.getAttribute("data-type") === "square") card.classList.add("active");
                else card.classList.remove("active");
            });
            activeBaseType = "square";
            setStatus("Base Grid settings reset to default.");
        });
    }

    var btnResetConstruction = document.getElementById("btn-reset-construction");
    if (btnResetConstruction) {
        btnResetConstruction.addEventListener("click", function () {
            var compBtns = document.querySelectorAll(".comp-btn");
            compBtns.forEach(function (b) {
                var key = b.getAttribute("data-key");
                if (key === "handles") b.classList.remove("active");
                else b.classList.add("active");
            });

            if (document.getElementById("rng-logo-opacity")) {
                document.getElementById("rng-logo-opacity").value = 65;
                if (document.getElementById("num-logo-opacity")) document.getElementById("num-logo-opacity").textContent = "65%";
            }

            if (document.getElementById("sel-dim-style")) document.getElementById("sel-dim-style").value = "arrows";
            if (document.getElementById("chk-angle-callouts")) document.getElementById("chk-angle-callouts").checked = false;
            if (document.getElementById("col-outline-stroke")) document.getElementById("col-outline-stroke").value = "#8c96a5";
            if (document.getElementById("col-edgeray-stroke")) document.getElementById("col-edgeray-stroke").value = "#afb4be";
            if (document.getElementById("col-gridline-stroke")) document.getElementById("col-gridline-stroke").value = "#b4b9c3";
            if (document.getElementById("col-anchor-stroke")) document.getElementById("col-anchor-stroke").value = "#3c4048";
            if (document.getElementById("col-anchor-fill")) document.getElementById("col-anchor-fill").value = "#ffffff";
            if (document.getElementById("chk-anchor-fill")) document.getElementById("chk-anchor-fill").checked = true;

            if (document.getElementById("rng-edgeray-stroke")) { document.getElementById("rng-edgeray-stroke").value = 0.45; document.getElementById("num-edgeray-stroke").textContent = "0.45"; }
            if (document.getElementById("rng-edgeray-overflow")) { document.getElementById("rng-edgeray-overflow").value = 15; document.getElementById("num-edgeray-overflow").textContent = "15%"; }
            if (document.getElementById("rng-edgeray-opacity")) { document.getElementById("rng-edgeray-opacity").value = 75; document.getElementById("num-edgeray-opacity").textContent = "75%"; }

            if (document.getElementById("rng-outline-stroke")) { document.getElementById("rng-outline-stroke").value = 0.6; document.getElementById("num-outline-stroke").textContent = "0.60"; }
            if (document.getElementById("rng-outline-opacity")) { document.getElementById("rng-outline-opacity").value = 85; document.getElementById("num-outline-opacity").textContent = "85%"; }
            if (document.getElementById("rng-gridline-stroke")) { document.getElementById("rng-gridline-stroke").value = 0.45; document.getElementById("num-gridline-stroke").textContent = "0.45"; }
            if (document.getElementById("rng-gridline-overflow")) { document.getElementById("rng-gridline-overflow").value = 15; document.getElementById("num-gridline-overflow").textContent = "15%"; }
            if (document.getElementById("rng-gridline-opacity")) { document.getElementById("rng-gridline-opacity").value = 70; document.getElementById("num-gridline-opacity").textContent = "70%"; }
            if (document.getElementById("rng-anchor-stroke")) { document.getElementById("rng-anchor-stroke").value = 0.65; document.getElementById("num-anchor-stroke").textContent = "0.65"; }
            if (document.getElementById("rng-anchor-scale")) { document.getElementById("rng-anchor-scale").value = 3.2; document.getElementById("num-anchor-scale").textContent = "3.20"; }
            if (document.getElementById("rng-anchor-opacity")) { document.getElementById("rng-anchor-opacity").value = 100; document.getElementById("num-anchor-opacity").textContent = "100%"; }

            triggerConstructionLiveUpdate();
            setStatus("Construction settings reset to default.");
        });
    }

    var btnResetClearspace = document.getElementById("btn-reset-clearspace");
    if (btnResetClearspace) {
        btnResetClearspace.addEventListener("click", function () {
            if (document.getElementById("sel-clear-mode")) document.getElementById("sel-clear-mode").value = "brand";
            if (document.getElementById("clear-mult-select")) document.getElementById("clear-mult-select").value = "1.0";
            if (document.getElementById("sel-spacing-format")) document.getElementById("sel-spacing-format").value = "both";
            if (document.getElementById("sel-corner-type")) document.getElementById("sel-corner-type").value = "default_x";
            if (document.getElementById("row-custom-text")) document.getElementById("row-custom-text").style.display = "none";
            if (document.getElementById("row-custom-dropzone")) document.getElementById("row-custom-dropzone").style.display = "none";
            if (document.getElementById("inp-custom-char")) document.getElementById("inp-custom-char").value = "X";
            if (document.getElementById("col-corner-fill")) document.getElementById("col-corner-fill").value = "#c2e0f8";
            if (document.getElementById("chk-corner-boxes")) document.getElementById("chk-corner-boxes").checked = true;
            if (document.getElementById("chk-level-guides")) document.getElementById("chk-level-guides").checked = true;
            if (document.getElementById("chk-clear-brackets")) document.getElementById("chk-clear-brackets").checked = true;
            customSvgPath = null;
            resetDropZoneUI();
            setStatus("Clearspace settings reset to default.");
        });
    }

    // =========================================================================
    // 6. CLEARSPACE TAB (EXPLICIT GENERATE ONLY)
    // =========================================================================
    var selCornerType = document.getElementById("sel-corner-type");
    var rowCustomText = document.getElementById("row-custom-text");
    var rowCustomDropzone = document.getElementById("row-custom-dropzone");
    var cornerDropZone = document.getElementById("corner-drop-zone");
    var inpCornerFile = document.getElementById("inp-corner-file");
    var btnCaptureCanvasShape = document.getElementById("btn-capture-canvas-shape");
    var customSvgPath = null;

    function renderCapturedThumbnail(thumbPath, label, timestamp) {
        var dropZone = document.getElementById("corner-drop-zone");
        if (!dropZone) return;

        var imgHtml = "";
        if (thumbPath) {
            var fileUrl = "file://" + thumbPath.replace(/\\/g, "/") + "?t=" + (timestamp || new Date().getTime());
            imgHtml = '<img src="' + fileUrl + '" style="width: 40px; height: 40px; object-fit: contain; background: rgba(255,255,255,0.06); padding: 3px; border-radius: 5px; border: 1px solid var(--accent); box-shadow: 0 0 10px rgba(255,107,0,0.3);">';
        } else {
            imgHtml = '<svg viewBox="0 0 24 24" width="28" height="28" stroke="var(--accent)" stroke-width="2" fill="none"><polyline points="20 6 9 17 4 12"/></svg>';
        }

        dropZone.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: center; gap: 10px; padding: 4px 6px;">
                ${imgHtml}
                <div style="text-align: left;">
                    <div style="font-size: 11px; font-weight: 700; color: var(--accent); display: flex; align-items: center; gap: 4px;">
                        <span>✓</span> <span>Captured Active</span>
                    </div>
                    <div style="font-size: 9.5px; font-weight: 600; color: var(--text-primary); margin-top: 1px;">${label || "Custom Vector"}</div>
                    <div style="font-size: 8.5px; color: var(--text-muted); margin-top: 1px;">Ready for Clearspace Corner Boxes</div>
                </div>
            </div>
            <input type="file" id="inp-corner-file" accept=".svg,.ai,.eps,.png" style="display: none;">
        `;
        dropZone.style.borderColor = "var(--accent)";
        dropZone.style.background = "rgba(255, 107, 0, 0.08)";
        bindDropZoneFileInput();
    }

    function resetDropZoneUI() {
        var dropZone = document.getElementById("corner-drop-zone");
        if (dropZone) {
            dropZone.innerHTML = `
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none" style="margin-bottom: 3px; color: var(--accent);"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                <div style="font-size: 10.5px; font-weight: 600; color: var(--text-primary);" id="drop-zone-text">Drop SVG File or Click to Upload</div>
                <div style="font-size: 9px; color: var(--text-muted); margin-top: 1px;">Drag vector file here or select file from disk</div>
                <input type="file" id="inp-corner-file" accept=".svg,.ai,.eps,.png" style="display: none;">
            `;
            dropZone.style.borderColor = "";
            dropZone.style.background = "";
            bindDropZoneFileInput();
        }
    }

    function bindDropZoneFileInput() {
        var inp = document.getElementById("inp-corner-file");
        if (inp) {
            inp.addEventListener("change", function (e) {
                if (e.target.files && e.target.files.length > 0) {
                    handleCornerFile(e.target.files[0]);
                }
            });
        }
    }

    if (selCornerType) {
        selCornerType.addEventListener("change", function () {
            var val = selCornerType.value;
            if (rowCustomText) rowCustomText.style.display = (val === "custom_text") ? "flex" : "none";
            if (rowCustomDropzone) rowCustomDropzone.style.display = (val === "custom_svg") ? "block" : "none";
        });
    }

    if (cornerDropZone) {
        cornerDropZone.addEventListener("click", function () {
            var inp = document.getElementById("inp-corner-file");
            if (inp) inp.click();
        });

        bindDropZoneFileInput();

        cornerDropZone.addEventListener("dragover", function (e) {
            e.preventDefault();
            cornerDropZone.style.borderColor = "var(--accent)";
            cornerDropZone.style.background = "rgba(255, 107, 0, 0.12)";
        });

        cornerDropZone.addEventListener("dragleave", function (e) {
            e.preventDefault();
            cornerDropZone.style.borderColor = "";
            cornerDropZone.style.background = "";
        });

        cornerDropZone.addEventListener("drop", function (e) {
            e.preventDefault();
            cornerDropZone.style.borderColor = "";
            cornerDropZone.style.background = "";
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                handleCornerFile(e.dataTransfer.files[0]);
            }
        });
    }

    if (btnCaptureCanvasShape) {
        btnCaptureCanvasShape.addEventListener("click", function () {
            setStatus("Capturing selected vector from artboard...");
            csInterface.evalScript('LogoGridHost.execute("captureCornerVector", "{}")', function (res) {
                try {
                    var data = JSON.parse(res);
                    if (data && data.success) {
                        renderCapturedThumbnail(data.thumbPath, "Artboard Vector (" + (data.count || 1) + " items)", data.timestamp);
                        setStatus("Artboard vector captured! Click 'Generate Brand Clearspace' to apply.");
                        if (selCornerType) selCornerType.value = "custom_svg";
                    } else if (data && data.error) {
                        setStatus("Error: " + data.error, true);
                        alert("MKD Grid System: " + data.error);
                    }
                } catch (e) {
                    setStatus("Error capturing vector: " + e.message, true);
                }
            });
        });
    }

    function handleCornerFile(file) {
        if (!file) return;
        customSvgPath = file.path || "";
        renderCapturedThumbnail(customSvgPath, file.name, new Date().getTime());
        setStatus("Loading SVG: " + file.name + "...");

        if (customSvgPath) {
            var escaped = customSvgPath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
            csInterface.evalScript('LogoGridHost.execute("importCornerSVG", "' + escaped + '")', function (res) {
                try {
                    var data = JSON.parse(res);
                    if (data && data.success) {
                        renderCapturedThumbnail(data.thumbPath || customSvgPath, file.name, data.timestamp);
                        setStatus("SVG loaded into corner templates! Click 'Generate Brand Clearspace' to apply.");
                        if (selCornerType) selCornerType.value = "custom_svg";
                    } else if (data && data.error) {
                        setStatus("Error: " + data.error, true);
                    }
                } catch (e) {}
            });
        }
    }

    var btnGenClearTab = document.getElementById("btn-gen-clear-tab");
    if (btnGenClearTab) {
        btnGenClearTab.addEventListener("click", function () {
            setStatus("Generating Brand Clearspace & Proportions...");
            var mode = document.getElementById("sel-clear-mode") ? document.getElementById("sel-clear-mode").value : "brand";
            var mult = parseFloat(document.getElementById("clear-mult-select").value) || 1.0;
            var spacingFormat = document.getElementById("sel-spacing-format") ? document.getElementById("sel-spacing-format").value : "both";
            var cornerType = document.getElementById("sel-corner-type") ? document.getElementById("sel-corner-type").value : "default_x";
            var customChar = document.getElementById("inp-custom-char") ? document.getElementById("inp-custom-char").value : "X";
            var isCornerBoxes = document.getElementById("chk-corner-boxes") ? document.getElementById("chk-corner-boxes").checked : true;
            var isGuides = document.getElementById("chk-level-guides") ? document.getElementById("chk-level-guides").checked : true;
            var isBrackets = document.getElementById("chk-clear-brackets") ? document.getElementById("chk-clear-brackets").checked : true;
            var boxFill = document.getElementById("col-corner-fill") ? hexToRgb(document.getElementById("col-corner-fill").value) : [194, 224, 248];

            var params = {
                clearspaceMode: mode,
                multiplier: mult,
                spacingFormat: spacingFormat,
                cornerType: cornerType,
                customChar: customChar,
                svgFilePath: customSvgPath,
                showCornerBoxes: isCornerBoxes,
                showGuides: isGuides,
                showBrackets: isBrackets,
                showHatching: true,
                style: {
                    boxFillColor: boxFill,
                    boxStrokeColor: [74, 144, 226],
                    boxOpacity: 45,
                    bracketColor: [74, 144, 226],
                    guideColor: [180, 185, 195],
                    guideStrokeWidth: 0.45,
                    guideOpacity: 75
                }
            };

            var jsonStr = JSON.stringify(params);
            var escaped = jsonStr.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
            csInterface.evalScript('LogoGridHost.execute("generateClearspace", "' + escaped + '")', function (res) {
                try {
                    var data = JSON.parse(res);
                    if (data && data.success) {
                        setStatus("Brand Clearspace Generated!");
                    } else if (data && data.error) {
                        setStatus("Error: " + data.error, true);
                        alert("MKD Grid System: " + data.error);
                    }
                } catch (e) {
                    setStatus("Brand Clearspace Generated!");
                }
            });
        });
    }

    // =========================================================================
    // 7. 3-DAY COMMUNITY BETA TRIAL & FEEDBACK ENGINE
    // =========================================================================
    var FEEDBACK_URL = "https://itsmkd.com/tools#feedback";
    var PREORDER_URL = "https://itsmkd.com/tools#pricing";

    function openExternalUrl(url) {
        try {
            if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
                window.cep.util.openURLInDefaultBrowser(url);
            } else if (csInterface && csInterface.openURLInDefaultBrowser) {
                csInterface.openURLInDefaultBrowser(url);
            } else {
                window.open(url, "_blank");
            }
        } catch (e) {
            window.open(url, "_blank");
        }
    }

    var btnOpenFeedback = document.getElementById("btn-open-feedback");
    if (btnOpenFeedback) {
        btnOpenFeedback.addEventListener("click", function () {
            openExternalUrl(FEEDBACK_URL);
        });
    }

    var btnModalFeedback = document.getElementById("btn-modal-feedback");
    if (btnModalFeedback) {
        btnModalFeedback.addEventListener("click", function () {
            openExternalUrl(FEEDBACK_URL);
        });
    }

    var btnModalPreorder = document.getElementById("btn-modal-preorder");
    if (btnModalPreorder) {
        btnModalPreorder.addEventListener("click", function () {
            openExternalUrl(PREORDER_URL);
        });
    }

    // =========================================================================
    // 3-DAY (72-HOUR) TRIAL ENGINE - PRODUCTION LOGIC
    // =========================================================================
    var TRIAL_DURATION_MS = 3 * 24 * 60 * 60 * 1000; // 72 Hours in Milliseconds

    function initTrialEngine() {
        var installTimeStr = localStorage.getItem("mkd_trial_install_ts");
        var now = Date.now();
        var installTime = now;

        if (!installTimeStr) {
            // First Launch: Record installation timestamp
            localStorage.setItem("mkd_trial_install_ts", String(now));
            installTime = now;
        } else {
            installTime = parseInt(installTimeStr, 10) || now;
        }

        var elapsedMs = now - installTime;
        var remainingMs = TRIAL_DURATION_MS - elapsedMs;

        var trialBadge = document.getElementById("trial-badge");
        var trialModal = document.getElementById("trial-expired-modal");

        if (remainingMs <= 0) {
            // 72 Hours Elapsed: Show Expiration Lock Screen
            if (trialBadge) {
                trialBadge.textContent = "⚠️ Trial Expired";
                trialBadge.style.color = "var(--accent-coral)";
                trialBadge.style.borderColor = "var(--accent-coral)";
            }
            if (trialModal) {
                trialModal.style.display = "flex";
            }
        } else {
            // Trial Active: Ensure modal is closed and show countdown
            if (trialModal) {
                trialModal.style.display = "none";
            }
            var remainingHours = Math.ceil(remainingMs / (1000 * 60 * 60));
            var remainingDays = Math.ceil(remainingHours / 24);

            if (trialBadge) {
                if (remainingHours <= 24) {
                    trialBadge.textContent = "⏳ " + remainingHours + "h Left";
                    trialBadge.style.color = "var(--accent)";
                    trialBadge.style.borderColor = "var(--accent)";
                } else {
                    trialBadge.textContent = "⏳ " + remainingDays + " Days Left";
                }
            }
        }
    }

    initTrialEngine();
});
