========================================================================
   MKD GRID SYSTEM - ADOBE ILLUSTRATOR EXTENSION
   MKDESIGNER PRO TOOLKIT • COMMUNITY BETA EDITION
========================================================================

🍏 FOR macOS USERS:
------------------------------------------------------------------------
1. Double-click "Install_Mac.pkg" and follow the installer wizard.
2. If macOS asks to verify the package:
   Right-Click (or Control-Click) "Install_Mac.pkg" > click "Open" > click "Open".
3. Open (or restart) Adobe Illustrator.
4. In the top menu bar, click: Window > Extensions > MKD Grid System.
5. Done! Enjoy precision logo grid generation!

🪟 FOR WINDOWS USERS:
------------------------------------------------------------------------
1. Double-click "Install_Windows.bat".
2. Open (or restart) Adobe Illustrator.
3. In the top menu bar, click: Window > Extensions > MKD Grid System.

💬 NEED HELP OR HAVE FEEDBACK?
------------------------------------------------------------------------
Website: https://itsmkd.com/tools
Feedback: https://itsmkd.com/tools#feedback
Direct Contact: contact@itsmkd.com
========================================================================
Designed by MKD • All Rights Reserved
========================================================================
