========================================================================
   MKD GRID SYSTEM - ADOBE ILLUSTRATOR EXTENSION (macOS)
   MKDESIGNER PRO TOOLKIT • COMMUNITY BETA EDITION
========================================================================

⚡ FAST 1-CLICK INSTALLATION:
------------------------------------------------------------------------
1. Double-click "Install_Mac.command".
2. If macOS displays a Gatekeeper prompt ("unidentified developer"), 
   simply Right-Click "Install_Mac.command" > Open > Click "Open".
3. Open (or restart) Adobe Illustrator.
4. Go to: Window > Extensions > MKD Grid System.
5. That's it! Start gridding your logo marks effortlessly.

💬 SHARE YOUR FEEDBACK:
------------------------------------------------------------------------
We value your suggestions and feedback during this beta trial!
Submit feedback or feature requests at: https://mkdesigner.com/feedback

========================================================================
Designed by MKDESIGNER • All Rights Reserved
========================================================================
