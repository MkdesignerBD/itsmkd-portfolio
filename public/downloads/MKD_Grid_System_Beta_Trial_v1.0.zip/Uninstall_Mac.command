#!/bin/bash
TARGET_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/MKDGridSystem"
clear
echo "============================================================"
echo "    🗑️  MKD GRID SYSTEM - macOS UNINSTALLER"
echo "============================================================"
echo ""
if [ -d "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
    echo "✅ MKD Grid System has been cleanly removed from your Mac."
else
    echo "ℹ️  MKD Grid System is not installed."
fi
echo ""
read -p "Press [Enter] to exit..."
