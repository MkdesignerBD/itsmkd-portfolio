@echo off
TITLE MKD Grid System - Uninstaller
COLOR 0C
CLS

echo ============================================================
echo     MKD GRID SYSTEM - WINDOWS UNINSTALLER
echo ============================================================
echo.
SET "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\MKDGridSystem"

IF EXIST "%TARGET_DIR%" (
    RMDIR /S /Q "%TARGET_DIR%"
    echo [SUCCESS] MKD Grid System has been cleanly uninstalled.
) ELSE (
    echo [INFO] MKD Grid System is not installed.
)
echo.
PAUSE
