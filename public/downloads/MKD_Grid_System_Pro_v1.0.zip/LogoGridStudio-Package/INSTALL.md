# ⚡ LogoGridStudio Pro - Installation Guide for Any Computer

This package allows you to install **LogoGridStudio Pro** on any Mac or Windows computer running Adobe Illustrator (CS6 through 2026+).

---

## 🍏 Method 1: Automatic 1-Click Install (macOS)

1. Unzip `LogoGridStudio-Extension.zip` on your Mac.
2. Open **Terminal**, drag and drop `install-mac.sh` into Terminal and press `Enter`:
   ```bash
   bash install-mac.sh
   ```
3. Restart Adobe Illustrator and go to:
   **`Window > Extensions > LogoGridStudio Pro`**

---

## 🪟 Method 2: Automatic 1-Click Install (Windows)

1. Unzip `LogoGridStudio-Extension.zip` on your Windows PC.
2. Double-click **`install-windows.bat`**.
3. Restart Adobe Illustrator and go to:
   **`Window > Extensions > LogoGridStudio Pro`**

---

## 📂 Method 3: Manual Drag & Drop Install (No Terminal Needed)

Copy the **`io.logogrid.studio`** folder into your computer's Adobe CEP extensions directory:

### On macOS:
* Open Finder, press `Cmd + Shift + G`, paste:  
  `~/Library/Application Support/Adobe/CEP/extensions/`
* Paste the `io.logogrid.studio` folder here.
* Open Terminal and run:
  ```bash
  defaults write com.adobe.CSXS.11 PlayerDebugMode 1
  defaults write com.adobe.CSXS.12 PlayerDebugMode 1
  ```

### On Windows:
* Press `Win + R`, type `%APPDATA%\Adobe\CEP\extensions`, and press `Enter`.
* Paste the `io.logogrid.studio` folder here.
* In Registry Editor (`regedit`), under `HKEY_CURRENT_USER\Software\Adobe\CSXS.11` (and `.12`), add a String Value named `PlayerDebugMode` with value `1`.

---

## ⚡ Method 4: Instant Zero-Install Script (Mac & Windows)

If you don't want to install an extension at all:
1. Open Illustrator.
2. Press **`Cmd + F12`** (Mac) or **`Ctrl + F12`** (Windows).
3. Select **`LogoGridStudioPro.jsx`** included in this package.
