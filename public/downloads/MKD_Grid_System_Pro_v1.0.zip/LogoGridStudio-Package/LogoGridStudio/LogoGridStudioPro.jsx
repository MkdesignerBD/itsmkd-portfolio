/**
 * LogoGridStudio Pro v1.0.0
 * Professional Logo Grid & Brand Geometry Studio for Adobe Illustrator
 * Compatible with Adobe Illustrator CS6 to 2026+ (macOS & Windows)
 *
 * 100% Standalone ExtendScript (Zero installation, zero DRM, zero latency)
 * Features:
 *   1. Construction Grids (Anchors, Handles, Wireframes, Tangent Extensions, Arc Circles)
 *   2. Clearspace & Exclusion Zones (Auto 'X' Detection, Dimension Lines, Callouts, Hatching)
 *   3. Lockup & Alignment (Symbol-to-Wordmark axes, Baselines, Cap-heights, Spacing Brackets)
 *   4. Base Grids (Modular Square, Isometric 30/60, Hexagonal, Golden Ratio, Polar Radial)
 *   5. Bento Matrix (Presentation layouts: Simple, Brick, Centered across 3-12 sections)
 *   6. Multi-Theme Presets (Blueprint Cyan, Tech Magenta, Minimal Slate, Dark Neon)
 */

// =================== src/core/Constants.jsx ===================
/**
 * LogoGridStudio Pro - Constants & Default Settings
 * Compatible with Adobe Illustrator CS6 to 2026+ (ExtendScript ES3)
 */

var LGS_CONSTANTS = {
    APP_NAME: "LogoGridStudio Pro",
    VERSION: "1.0.0",
    AUTHOR: "Antigravity",
    ROOT_LAYER_NAME: "_LOGO_GRID_SYSTEM",
    
    // Sublayer Names
    SUBLAYERS: {
        CONSTRUCTION: "_Construction_Grid",
        ANCHORS: "_Anchors",
        HANDLES: "_Handles",
        OUTLINES: "_Outlines",
        GRIDLINES: "_Gridlines",
        CIRCLES: "_Fitted_Circles",
        CLEARSPACE: "_Clearspace_System",
        LOCKUP: "_Lockup_Alignment",
        BASE_GRID: "_Base_Grid",
        BENTO: "_Bento_Presentation",
        ANNOTATIONS: "_Annotations"
    },

    // Anchor Marker Styles
    ANCHOR_STYLES: ["Square", "Circle", "Diamond", "Crosshair"],

    // Themes (RGB 0-255 format)
    THEMES: {
        CYAN: {
            name: "Blueprint Cyan",
            anchorFill: [0, 210, 255],
            anchorStroke: [0, 120, 200],
            handleLine: [0, 180, 240],
            handleTip: [0, 230, 255],
            outline: [0, 150, 220],
            gridline: [0, 190, 255],
            circle: [0, 220, 255],
            clearspaceBox: [0, 210, 255],
            clearspaceHatch: [0, 180, 240],
            dimension: [0, 220, 255],
            lockupAxis: [0, 210, 255],
            baseGridMajor: [0, 180, 240],
            baseGridMinor: [0, 120, 180],
            bentoFill: [240, 248, 255],
            bentoStroke: [0, 180, 240]
        },
        MAGENTA: {
            name: "Tech Magenta",
            anchorFill: [255, 40, 140],
            anchorStroke: [180, 10, 90],
            handleLine: [255, 70, 160],
            handleTip: [255, 120, 190],
            outline: [220, 30, 120],
            gridline: [255, 50, 150],
            circle: [255, 80, 170],
            clearspaceBox: [255, 40, 140],
            clearspaceHatch: [255, 80, 170],
            dimension: [255, 50, 150],
            lockupAxis: [255, 40, 140],
            baseGridMajor: [255, 60, 150],
            baseGridMinor: [180, 40, 100],
            bentoFill: [255, 240, 248],
            bentoStroke: [255, 60, 150]
        },
        SLATE: {
            name: "Minimal Slate",
            anchorFill: [80, 90, 105],
            anchorStroke: [40, 45, 55],
            handleLine: [120, 130, 145],
            handleTip: [70, 80, 95],
            outline: [60, 70, 85],
            gridline: [140, 150, 165],
            circle: [110, 120, 135],
            clearspaceBox: [80, 90, 105],
            clearspaceHatch: [160, 170, 185],
            dimension: [70, 80, 95],
            lockupAxis: [80, 90, 105],
            baseGridMajor: [100, 110, 125],
            baseGridMinor: [180, 190, 200],
            bentoFill: [245, 247, 250],
            bentoStroke: [140, 150, 165]
        },
        DARK_MODE: {
            name: "Dark Neon",
            anchorFill: [50, 255, 170],
            anchorStroke: [20, 180, 110],
            handleLine: [80, 255, 190],
            handleTip: [120, 255, 210],
            outline: [40, 220, 140],
            gridline: [60, 240, 160],
            circle: [70, 255, 180],
            clearspaceBox: [50, 255, 170],
            clearspaceHatch: [40, 200, 130],
            dimension: [60, 255, 180],
            lockupAxis: [50, 255, 170],
            baseGridMajor: [60, 230, 150],
            baseGridMinor: [30, 140, 90],
            bentoFill: [20, 30, 25],
            bentoStroke: [50, 255, 170]
        }
    },

    // Default configuration object
    DEFAULTS: {
        themeKey: "CYAN",
        
        // Construction Tab
        enableAnchors: true,
        anchorStyle: "Circle",
        anchorSize: 4.5,
        enableHandles: true,
        handleStrokeWidth: 0.4,
        enableOutlines: true,
        outlineWidth: 0.5,
        enableGridlines: true,
        gridlineSensitivity: 1, // 0 = low, 1 = med, 2 = all
        enableCircles: true,
        circleTolerance: 0.08,
        overflowPadding: 80,

        // Clearspace Tab
        unitMode: "Logomark", // "Logomark", "Height", "Width", "Custom"
        multiplier: 1.0,
        customXPt: 40,
        enableHatching: true,
        enableDimensionLines: true,
        enableXBadges: true,

        // Lockup Tab
        enableLockupAxes: true,
        enableBaselineCap: true,
        enableGapBracket: true,

        // Base Grid Tab
        baseGridType: "Square", // "Square", "Isometric", "Hexagon", "Golden", "Polar"
        gridCellSize: 20,
        gridSubdivisions: 4,
        goldenScale: 100,
        polarRings: 6,
        polarSpokes: 12,

        // Bento Tab
        bentoLayout: "simple", // "simple", "brick", "centered"
        bentoSections: 6,
        bentoGutter: 12,
        bentoCornerRadius: 8,
        bentoRandomWidths: false
    }
};


// =================== src/math/Vector2D.jsx ===================
/**
 * LogoGridStudio Pro - Vector2D Math Engine
 * High-performance 2D vector and linear geometry utilities
 */

var Vector2D = {
    create: function(x, y) {
        return [x, y];
    },

    add: function(v1, v2) {
        return [v1[0] + v2[0], v1[1] + v2[1]];
    },

    sub: function(v1, v2) {
        return [v1[0] - v2[0], v1[1] - v2[1]];
    },

    scale: function(v, s) {
        return [v[0] * s, v[1] * s];
    },

    length: function(v) {
        return Math.sqrt(v[0] * v[0] + v[1] * v[1]);
    },

    lengthSq: function(v) {
        return v[0] * v[0] + v[1] * v[1];
    },

    dist: function(v1, v2) {
        var dx = v1[0] - v2[0];
        var dy = v1[1] - v2[1];
        return Math.sqrt(dx * dx + dy * dy);
    },

    distSq: function(v1, v2) {
        var dx = v1[0] - v2[0];
        var dy = v1[1] - v2[1];
        return dx * dx + dy * dy;
    },

    normalize: function(v) {
        var len = Math.sqrt(v[0] * v[0] + v[1] * v[1]);
        if (len === 0) return [0, 0];
        return [v[0] / len, v[1] / len];
    },

    dot: function(v1, v2) {
        return v1[0] * v2[0] + v1[1] * v2[1];
    },

    cross: function(v1, v2) {
        return v1[0] * v2[1] - v1[1] * v2[0];
    },

    lerp: function(v1, v2, t) {
        return [v1[0] + (v2[0] - v1[0]) * t, v1[1] + (v2[1] - v1[1]) * t];
    },

    rotate: function(v, angleRad) {
        var cosA = Math.cos(angleRad);
        var sinA = Math.sin(angleRad);
        return [v[0] * cosA - v[1] * sinA, v[0] * sinA + v[1] * cosA];
    },

    rotateAround: function(pt, center, angleRad) {
        var translated = [pt[0] - center[0], pt[1] - center[1]];
        var rotated = this.rotate(translated, angleRad);
        return [rotated[0] + center[0], rotated[1] + center[1]];
    },

    perp: function(v) {
        return [-v[1], v[0]];
    },

    // Raycast intersection of infinite line through (p1, p2) with bounding box [top, left, bottom, right]
    lineBoxIntersection: function(p1, p2, box) {
        var top = box[0], left = box[1], bottom = box[2], right = box[3];
        var dx = p2[0] - p1[0];
        var dy = p2[1] - p1[1];
        var hits = [];

        // Vertical line
        if (Math.abs(dx) < 1e-7) {
            if (p1[0] >= left && p1[0] <= right) {
                return [[p1[0], top], [p1[0], bottom]];
            }
            return null;
        }

        // Horizontal line
        if (Math.abs(dy) < 1e-7) {
            if (p1[1] <= top && p1[1] >= bottom) {
                return [[left, p1[1]], [right, p1[1]]];
            }
            return null;
        }

        // Check intersection with all 4 boundaries: y = top, y = bottom, x = left, x = right
        // 1. y = top
        var xTop = p1[0] + (top - p1[1]) * (dx / dy);
        if (xTop >= left && xTop <= right) hits.push([xTop, top]);

        // 2. y = bottom
        var xBot = p1[0] + (bottom - p1[1]) * (dx / dy);
        if (xBot >= left && xBot <= right) hits.push([xBot, bottom]);

        // 3. x = left
        var yLeft = p1[1] + (left - p1[0]) * (dy / dx);
        if (yLeft <= top && yLeft >= bottom) hits.push([left, yLeft]);

        // 4. x = right
        var yRight = p1[1] + (right - p1[0]) * (dy / dx);
        if (yRight <= top && yRight >= bottom) hits.push([right, yRight]);

        // Deduplicate close points
        var uniqueHits = [];
        for (var i = 0; i < hits.length; i++) {
            var isDup = false;
            for (var j = 0; j < uniqueHits.length; j++) {
                if (this.distSq(hits[i], uniqueHits[j]) < 1.0) {
                    isDup = true;
                    break;
                }
            }
            if (!isDup) uniqueHits.push(hits[i]);
        }

        if (uniqueHits.length >= 2) {
            return [uniqueHits[0], uniqueHits[1]];
        }
        return null;
    }
};


// =================== src/math/BezierMath.jsx ===================
/**
 * LogoGridStudio Pro - Bézier Calculus & Arc Fitting Engine
 * High-precision cubic Bézier evaluation, curvature radius, osculating circles, and extrema detection
 */

var BezierMath = {
    // Evaluate cubic Bézier point at parameter t in [0, 1]
    evaluate: function(p0, p1, p2, p3, t) {
        var mt = 1.0 - t;
        var mt2 = mt * mt;
        var mt3 = mt2 * mt;
        var t2 = t * t;
        var t3 = t2 * t;
        return [
            mt3 * p0[0] + 3.0 * mt2 * t * p1[0] + 3.0 * mt * t2 * p2[0] + t3 * p3[0],
            mt3 * p0[1] + 3.0 * mt2 * t * p1[1] + 3.0 * mt * t2 * p2[1] + t3 * p3[1]
        ];
    },

    // First derivative B'(t) = velocity vector
    derivative: function(p0, p1, p2, p3, t) {
        var mt = 1.0 - t;
        return [
            3.0 * mt * mt * (p1[0] - p0[0]) + 6.0 * mt * t * (p2[0] - p1[0]) + 3.0 * t * t * (p3[0] - p2[0]),
            3.0 * mt * mt * (p1[1] - p0[1]) + 6.0 * mt * t * (p2[1] - p1[1]) + 3.0 * t * t * (p3[1] - p2[1])
        ];
    },

    // Second derivative B''(t) = acceleration vector
    secondDerivative: function(p0, p1, p2, p3, t) {
        var mt = 1.0 - t;
        return [
            6.0 * mt * (p2[0] - 2.0 * p1[0] + p0[0]) + 6.0 * t * (p3[0] - 2.0 * p2[0] + p1[0]),
            6.0 * mt * (p2[1] - 2.0 * p1[1] + p0[1]) + 6.0 * t * (p3[1] - 2.0 * p2[1] + p1[1])
        ];
    },

    // Curvature kappa, radius R = 1/|kappa|, and osculating circle center
    curvature: function(p0, p1, p2, p3, t) {
        var d1 = this.derivative(p0, p1, p2, p3, t);
        var d2 = this.secondDerivative(p0, p1, p2, p3, t);
        var num = d1[0] * d2[1] - d1[1] * d2[0];
        var speedSq = d1[0] * d1[0] + d1[1] * d1[1];
        var den = Math.pow(speedSq, 1.5);

        if (den < 1e-7 || Math.abs(num) < 1e-7) {
            return { kappa: 0, radius: Infinity, center: null };
        }

        var kappa = num / den;
        var radius = 1.0 / Math.abs(kappa);
        var speed = Math.sqrt(speedSq);
        var nx = -d1[1] / speed;
        var ny = d1[0] / speed;
        var pt = this.evaluate(p0, p1, p2, p3, t);
        var sign = kappa >= 0 ? 1.0 : -1.0;

        return {
            kappa: kappa,
            radius: radius,
            center: [pt[0] + sign * nx * radius, pt[1] + sign * ny * radius]
        };
    },

    // Detect if a cubic Bézier segment is a straight line segment
    isLinear: function(p0, p1, p2, p3, tol) {
        var threshold = tol || 0.5;
        // Check distance from p1 and p2 to line (p0 -> p3)
        var dx = p3[0] - p0[0];
        var dy = p3[1] - p0[1];
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-5) return true;

        var dist1 = Math.abs((p1[1] - p0[1]) * dx - (p1[0] - p0[0]) * dy) / len;
        var dist2 = Math.abs((p2[1] - p0[1]) * dx - (p2[0] - p0[0]) * dy) / len;
        return (dist1 <= threshold && dist2 <= threshold);
    },

    // Detect if a cubic Bézier segment is a circular arc and return circumcenter and radius
    detectArc: function(p0, p1, p2, p3, tolerance) {
        if (this.isLinear(p0, p1, p2, p3, 1.0)) return null;

        var tol = tolerance || 0.08;
        // Sample curvature at t = 0.25, 0.50, 0.75
        var c1 = this.curvature(p0, p1, p2, p3, 0.25);
        var c2 = this.curvature(p0, p1, p2, p3, 0.50);
        var c3 = this.curvature(p0, p1, p2, p3, 0.75);

        if (!c1.center || !c2.center || !c3.center) return null;

        var avgR = (c1.radius + c2.radius + c3.radius) / 3.0;
        if (avgR < 8.0 || avgR > 3000.0) return null; // Reject tiny noise and near-flat curves

        // Compute radius variance
        var maxDev = Math.max(
            Math.abs(c1.radius - avgR),
            Math.abs(c2.radius - avgR),
            Math.abs(c3.radius - avgR)
        ) / avgR;

        // Compute center point consistency
        var avgCenterX = (c1.center[0] + c2.center[0] + c3.center[0]) / 3.0;
        var avgCenterY = (c1.center[1] + c2.center[1] + c3.center[1]) / 3.0;
        var centerDev = Math.max(
            Vector2D.dist(c1.center, [avgCenterX, avgCenterY]),
            Vector2D.dist(c2.center, [avgCenterX, avgCenterY]),
            Vector2D.dist(c3.center, [avgCenterX, avgCenterY])
        ) / avgR;

        if (maxDev <= tol && centerDev <= tol * 1.5) {
            return {
                center: [avgCenterX, avgCenterY],
                radius: avgR,
                isFullCircleApprox: (Vector2D.dist(p0, p3) < avgR * 0.2)
            };
        }

        return null;
    },

    // Solve quadratic equation: a*t^2 + b*t + c = 0
    solveQuadratic: function(a, b, c) {
        var roots = [];
        if (Math.abs(a) < 1e-7) {
            if (Math.abs(b) >= 1e-7) {
                var t = -c / b;
                if (t >= 0.0 && t <= 1.0) roots.push(t);
            }
            return roots;
        }

        var disc = b * b - 4.0 * a * c;
        if (disc >= 0) {
            var sqrtD = Math.sqrt(disc);
            var t1 = (-b + sqrtD) / (2.0 * a);
            var t2 = (-b - sqrtD) / (2.0 * a);
            if (t1 >= 0.0 && t1 <= 1.0) roots.push(t1);
            if (t2 >= 0.0 && t2 <= 1.0 && Math.abs(t2 - t1) > 1e-4) roots.push(t2);
        }
        return roots;
    },

    // Find horizontal and vertical extrema parameters t in [0, 1]
    findExtrema: function(p0, p1, p2, p3) {
        // x'(t) = 3*(1-t)^2*(p1.x - p0.x) + 6*(1-t)*t*(p2.x - p1.x) + 3*t^2*(p3.x - p2.x) = 0
        // a = 3*(p3.x - 3*p2.x + 3*p1.x - p0.x)
        // b = 6*(p2.x - 2*p1.x + p0.x)
        // c = 3*(p1.x - p0.x)
        var ax = 3.0 * (p3[0] - 3.0 * p2[0] + 3.0 * p1[0] - p0[0]);
        var bx = 6.0 * (p2[0] - 2.0 * p1[0] + p0[0]);
        var cx = 3.0 * (p1[0] - p0[0]);
        var xRoots = this.solveQuadratic(ax, bx, cx);

        var ay = 3.0 * (p3[1] - 3.0 * p2[1] + 3.0 * p1[1] - p0[1]);
        var by = 6.0 * (p2[1] - 2.0 * p1[1] + p0[1]);
        var cy = 3.0 * (p1[1] - p0[1]);
        var yRoots = this.solveQuadratic(ay, by, cy);

        var extrema = [];
        for (var i = 0; i < xRoots.length; i++) {
            var t = xRoots[i];
            extrema.push({ t: t, pt: this.evaluate(p0, p1, p2, p3, t), type: "vertical_tangent" });
        }
        for (var j = 0; j < yRoots.length; j++) {
            var tY = yRoots[j];
            extrema.push({ t: tY, pt: this.evaluate(p0, p1, p2, p3, tY), type: "horizontal_tangent" });
        }

        return extrema;
    }
};


// =================== src/math/GeometryUtils.jsx ===================
/**
 * LogoGridStudio Pro - Geometry & Illustrator Object Traversal
 * Recursive path unpacking, bounds aggregation, and vector utilities
 */

var GeometryUtils = {
    // Recursively extract all PathItems from selection / items
    extractPaths: function(items) {
        var paths = [];
        if (!items || items.length === 0) return paths;

        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            this._collectPaths(item, paths);
        }
        return paths;
    },

    _collectPaths: function(item, paths) {
        if (!item) return;

        if (item.typename === "PathItem") {
            paths.push(item);
        } else if (item.typename === "CompoundPathItem") {
            for (var j = 0; j < item.pathItems.length; j++) {
                paths.push(item.pathItems[j]);
            }
        } else if (item.typename === "GroupItem") {
            for (var k = 0; k < item.pageItems.length; k++) {
                this._collectPaths(item.pageItems[k], paths);
            }
        }
    },

    // Aggregate geometric bounds [top, left, bottom, right] for an array of items
    getSelectionBounds: function(items) {
        if (!items || items.length === 0) return [0, 0, 0, 0];

        var top = -Infinity;
        var left = Infinity;
        var bottom = Infinity;
        var right = -Infinity;

        for (var i = 0; i < items.length; i++) {
            var b = items[i].geometricBounds; // [top, left, bottom, right]
            if (b[0] > top) top = b[0];
            if (b[1] < left) left = b[1];
            if (b[2] < bottom) bottom = b[2];
            if (b[3] > right) right = b[3];
        }

        return [top, left, bottom, right];
    },

    // Get active artboard bounds [top, left, bottom, right]
    getArtboardBounds: function(doc) {
        var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
        var r = ab.artboardRect; // [left, top, right, bottom]
        return [r[1], r[0], r[3], r[2]]; // Return [top, left, bottom, right]
    },

    // Check if point is inside bounding box
    isPointInBox: function(pt, box) {
        var top = box[0], left = box[1], bottom = box[2], right = box[3];
        return (pt[0] >= left && pt[0] <= right && pt[1] <= top && pt[1] >= bottom);
    }
};


// =================== src/utils/ThemeManager.jsx ===================
/**
 * LogoGridStudio Pro - Theme & Color Engine
 * Converts RGB themes to native Illustrator RGB/CMYK color objects
 */

var ThemeManager = {
    // Convert [r, g, b] (0-255) to Illustrator Color object
    makeColor: function(doc, rgbArr) {
        var r = rgbArr[0], g = rgbArr[1], b = rgbArr[2];
        if (doc && doc.documentColorSpace === DocumentColorSpace.CMYK) {
            var cmyk = new CMYKColor();
            // Standard RGB to CMYK formula
            var rNorm = r / 255.0, gNorm = g / 255.0, bNorm = b / 255.0;
            var k = 1.0 - Math.max(rNorm, Math.max(gNorm, bNorm));
            if (k < 1.0) {
                cmyk.cyan = Math.round(((1.0 - rNorm - k) / (1.0 - k)) * 100);
                cmyk.magenta = Math.round(((1.0 - gNorm - k) / (1.0 - k)) * 100);
                cmyk.yellow = Math.round(((1.0 - bNorm - k) / (1.0 - k)) * 100);
                cmyk.black = Math.round(k * 100);
            } else {
                cmyk.cyan = 0; cmyk.magenta = 0; cmyk.yellow = 0; cmyk.black = 100;
            }
            return cmyk;
        } else {
            var rgb = new RGBColor();
            rgb.red = r;
            rgb.green = g;
            rgb.blue = b;
            return rgb;
        }
    },

    // Get active theme with native Illustrator colors
    getResolvedTheme: function(doc, themeKey) {
        var tKey = themeKey || "CYAN";
        var rawTheme = LGS_CONSTANTS.THEMES[tKey] || LGS_CONSTANTS.THEMES.CYAN;
        var res = { name: rawTheme.name };

        for (var prop in rawTheme) {
            if (rawTheme.hasOwnProperty(prop) && prop !== "name") {
                res[prop] = this.makeColor(doc, rawTheme[prop]);
            }
        }
        return res;
    }
};


// =================== src/utils/LayerManager.jsx ===================
/**
 * LogoGridStudio Pro - Layer Management & Non-Destructive Hierarchy
 * Creates and organizes the dedicated _LOGO_GRID_SYSTEM layer stack
 */

var LayerManager = {
    // Get or create the master root layer
    getRootLayer: function(doc) {
        var rootName = LGS_CONSTANTS.ROOT_LAYER_NAME;
        var layer;
        try {
            layer = doc.layers.getByName(rootName);
            layer.visible = true;
            layer.locked = false;
        } catch (e) {
            layer = doc.layers.add();
            layer.name = rootName;
            layer.zOrder(ZOrderMethod.BRINGTOFRONT);
        }
        return layer;
    },

    // Get or create a specific module layer (e.g. _Construction_Grid) under the root layer
    getModuleLayer: function(doc, moduleName) {
        var root = this.getRootLayer(doc);
        var sub;
        try {
            sub = root.layers.getByName(moduleName);
            sub.visible = true;
            sub.locked = false;
        } catch (e) {
            sub = root.layers.add();
            sub.name = moduleName;
        }
        return sub;
    },

    // Get or create sub-sublayer (e.g. _Anchors inside _Construction_Grid)
    getOrCreateSublayer: function(parentLayer, subName) {
        var sub;
        try {
            sub = parentLayer.layers.getByName(subName);
            sub.visible = true;
            sub.locked = false;
        } catch (e) {
            sub = parentLayer.layers.add();
            sub.name = subName;
        }
        return sub;
    },

    // Clear contents of a module layer before regenerating
    clearLayer: function(layer) {
        if (!layer) return;
        for (var i = layer.pageItems.length - 1; i >= 0; i--) {
            layer.pageItems[i].remove();
        }
        for (var j = layer.layers.length - 1; j >= 0; j--) {
            layer.layers[j].remove();
        }
    }
};


// =================== src/engine/ConstructionEngine.jsx ===================
/**
 * LogoGridStudio Pro - Construction Grid Engine
 * Generates Anchors, Handles, Wireframes, Tangent Extensions, and Osculating Arc Circles
 */

var ConstructionEngine = {
    generate: function(doc, targetItems, config, theme) {
        var paths = GeometryUtils.extractPaths(targetItems);
        if (paths.length === 0) {
            alert("No vector paths found in selection. Please select your logo artwork.");
            return;
        }

        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.CONSTRUCTION);
        LayerManager.clearLayer(moduleLayer);

        var subOutlines = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.OUTLINES);
        var subCircles = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.CIRCLES);
        var subGridlines = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.GRIDLINES);
        var subHandles = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.HANDLES);
        var subAnchors = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.ANCHORS);

        var bounds = GeometryUtils.getSelectionBounds(targetItems);
        var pad = config.overflowPadding || 80;
        var extBounds = [bounds[0] + pad, bounds[1] - pad, bounds[2] - pad, bounds[3] + pad];

        for (var i = 0; i < paths.length; i++) {
            var path = paths[i];
            var pts = path.pathPoints;
            if (!pts || pts.length === 0) continue;

            // 1. Wireframe Outlines
            if (config.enableOutlines) {
                var clone = path.duplicate(subOutlines, ElementPlacement.PLACEATEND);
                clone.filled = false;
                clone.stroked = true;
                clone.strokeWidth = config.outlineWidth || 0.5;
                clone.strokeColor = theme.outline;
            }

            // 2. Anchors & Bézier Handles
            for (var j = 0; j < pts.length; j++) {
                var pt = pts[j];
                var anchor = pt.anchor;

                // Anchors
                if (config.enableAnchors) {
                    this.drawAnchor(subAnchors, anchor, config.anchorStyle, config.anchorSize || 4.5, theme);
                }

                // Handles
                if (config.enableHandles) {
                    var lDir = pt.leftDirection;
                    var rDir = pt.rightDirection;

                    if (Vector2D.distSq(lDir, anchor) > 1.0) {
                        this.drawHandle(subHandles, anchor, lDir, config.handleStrokeWidth || 0.4, theme);
                    }
                    if (Vector2D.distSq(rDir, anchor) > 1.0) {
                        this.drawHandle(subHandles, anchor, rDir, config.handleStrokeWidth || 0.4, theme);
                    }
                }
            }

            // 3. Circular Trajectories & Fitted Circles
            if (config.enableCircles) {
                for (var j = 0; j < pts.length; j++) {
                    var nextIdx = (j + 1) % pts.length;
                    if (!path.closed && j === pts.length - 1) break;

                    var p0 = pts[j].anchor;
                    var p1 = pts[j].rightDirection;
                    var p2 = pts[nextIdx].leftDirection;
                    var p3 = pts[nextIdx].anchor;

                    var arc = BezierMath.detectArc(p0, p1, p2, p3, config.circleTolerance || 0.08);
                    if (arc && arc.center) {
                        this.drawCircle(subCircles, arc.center, arc.radius, theme);
                    }
                }
            }

            // 4. Tangent & Extrema Extensions (Gridlines)
            if (config.enableGridlines) {
                this.drawGridlines(subGridlines, path, extBounds, config.gridlineSensitivity || 1, theme);
            }
        }
    },

    drawAnchor: function(layer, pt, style, size, theme) {
        var s = size || 4.5;
        var halfS = s / 2.0;
        var item;

        if (style === "Circle") {
            item = layer.pathItems.ellipse(pt[1] + halfS, pt[0] - halfS, s, s);
        } else if (style === "Diamond") {
            item = layer.pathItems.add();
            item.setEntirePath([
                [pt[0], pt[1] + s],
                [pt[0] + s, pt[1]],
                [pt[0], pt[1] - s],
                [pt[0] - s, pt[1]]
            ]);
            item.closed = true;
        } else if (style === "Crosshair") {
            var h = layer.pathItems.add();
            h.setEntirePath([[pt[0] - s, pt[1]], [pt[0] + s, pt[1]]]);
            h.stroked = true; h.filled = false; h.strokeWidth = 0.5; h.strokeColor = theme.anchorStroke;

            var v = layer.pathItems.add();
            v.setEntirePath([[pt[0], pt[1] - s], [pt[0], pt[1] + s]]);
            v.stroked = true; v.filled = false; v.strokeWidth = 0.5; v.strokeColor = theme.anchorStroke;
            return;
        } else { // Square
            item = layer.pathItems.rectangle(pt[1] + halfS, pt[0] - halfS, s, s);
        }

        item.filled = true;
        item.fillColor = theme.anchorFill;
        item.stroked = true;
        item.strokeWidth = 0.5;
        item.strokeColor = theme.anchorStroke;
    },

    drawHandle: function(layer, anchor, handlePt, strokeW, theme) {
        var line = layer.pathItems.add();
        line.setEntirePath([anchor, handlePt]);
        line.stroked = true;
        line.filled = false;
        line.strokeWidth = strokeW || 0.4;
        line.strokeColor = theme.handleLine;

        // Small circle at handle tip
        var tip = layer.pathItems.ellipse(handlePt[1] + 1.75, handlePt[0] - 1.75, 3.5, 3.5);
        tip.filled = true;
        tip.fillColor = theme.handleTip;
        tip.stroked = true;
        tip.strokeWidth = 0.35;
        tip.strokeColor = theme.handleLine;
    },

    drawCircle: function(layer, center, radius, theme) {
        var c = layer.pathItems.ellipse(center[1] + radius, center[0] - radius, radius * 2.0, radius * 2.0);
        c.filled = false;
        c.stroked = true;
        c.strokeWidth = 0.45;
        c.strokeColor = theme.circle;
        c.strokeDashes = [4, 3];
    },

    drawGridlines: function(layer, path, extBounds, sensitivity, theme) {
        var pts = path.pathPoints;
        var renderedY = [];
        var renderedX = [];

        for (var i = 0; i < pts.length; i++) {
            var anchor = pts[i].anchor;

            // Avoid duplicate lines if anchors share x/y
            var hasX = false, hasY = false;
            for (var k = 0; k < renderedX.length; k++) {
                if (Math.abs(renderedX[k] - anchor[0]) < 1.0) { hasX = true; break; }
            }
            for (var m = 0; m < renderedY.length; m++) {
                if (Math.abs(renderedY[m] - anchor[1]) < 1.0) { hasY = true; break; }
            }

            if (!hasY) {
                var hLine = layer.pathItems.add();
                hLine.setEntirePath([[extBounds[1], anchor[1]], [extBounds[3], anchor[1]]]);
                hLine.stroked = true; hLine.filled = false;
                hLine.strokeWidth = 0.25;
                hLine.strokeColor = theme.gridline;
                renderedY.push(anchor[1]);
            }

            if (!hasX) {
                var vLine = layer.pathItems.add();
                vLine.setEntirePath([[anchor[0], extBounds[0]], [anchor[0], extBounds[2]]]);
                vLine.stroked = true; vLine.filled = false;
                vLine.strokeWidth = 0.25;
                vLine.strokeColor = theme.gridline;
                renderedX.push(anchor[0]);
            }

            // If high sensitivity, also calculate extrema for curves
            if (sensitivity >= 2 && pts.length > 1) {
                var nextIdx = (i + 1) % pts.length;
                if (path.closed || i < pts.length - 1) {
                    var extrema = BezierMath.findExtrema(pts[i].anchor, pts[i].rightDirection, pts[nextIdx].leftDirection, pts[nextIdx].anchor);
                    for (var e = 0; e < extrema.length; e++) {
                        var ePt = extrema[e].pt;
                        if (extrema[e].type === "horizontal_tangent") {
                            var eh = layer.pathItems.add();
                            eh.setEntirePath([[extBounds[1], ePt[1]], [extBounds[3], ePt[1]]]);
                            eh.stroked = true; eh.filled = false; eh.strokeWidth = 0.25; eh.strokeColor = theme.gridline;
                        } else {
                            var ev = layer.pathItems.add();
                            ev.setEntirePath([[ePt[0], extBounds[0]], [ePt[0], extBounds[2]]]);
                            ev.stroked = true; ev.filled = false; ev.strokeWidth = 0.25; ev.strokeColor = theme.gridline;
                        }
                    }
                }
            }
        }
    }
};


// =================== src/engine/ClearspaceEngine.jsx ===================
/**
 * LogoGridStudio Pro - Clearspace & Dimension Engine
 * Calculates proportional 'X' exclusion zones, engineering dimension lines, arrowheads, and callout badges
 */

var ClearspaceEngine = {
    generate: function(doc, targetItems, config, theme) {
        if (!targetItems || targetItems.length === 0) {
            alert("Please select your logo artwork to generate clearspace.");
            return;
        }

        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.CLEARSPACE);
        LayerManager.clearLayer(moduleLayer);

        var subBox = LayerManager.getOrCreateSublayer(moduleLayer, "Exclusion_Boundary");
        var subDims = LayerManager.getOrCreateSublayer(moduleLayer, "Dimension_Lines");
        var subHatch = LayerManager.getOrCreateSublayer(moduleLayer, "Exclusion_Hatching");

        var bounds = GeometryUtils.getSelectionBounds(targetItems);
        var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
        var width = right - left, height = top - bottom;

        // 1. Calculate 'X' Unit
        var xVal = 40.0;
        var mode = config.unitMode || "Logomark";

        if (mode === "Logomark") {
            // If multiple items, try to find the icon/mark (often smaller width or square-ish)
            if (targetItems.length > 1) {
                var firstBounds = targetItems[0].geometricBounds;
                var markH = firstBounds[0] - firstBounds[2];
                var markW = firstBounds[3] - firstBounds[1];
                xVal = Math.min(markH, markW) * 0.5;
            } else {
                xVal = Math.min(width, height) * 0.25;
            }
        } else if (mode === "Height") {
            xVal = height * 0.25;
        } else if (mode === "Width") {
            xVal = width * 0.25;
        } else {
            xVal = config.customXPt || 40.0;
        }

        var multiplier = config.multiplier || 1.0;
        var margin = xVal * multiplier;

        // 2. Exclusion Boundary
        var outTop = top + margin;
        var outLeft = left - margin;
        var outWidth = width + (margin * 2.0);
        var outHeight = height + (margin * 2.0);

        var outerRect = subBox.pathItems.rectangle(outTop, outLeft, outWidth, outHeight);
        outerRect.filled = false;
        outerRect.stroked = true;
        outerRect.strokeWidth = 0.75;
        outerRect.strokeColor = theme.clearspaceBox;
        outerRect.strokeDashes = [5, 4];

        // Inner alignment bounding box
        var innerRect = subBox.pathItems.rectangle(top, left, width, height);
        innerRect.filled = false;
        innerRect.stroked = true;
        innerRect.strokeWidth = 0.35;
        innerRect.strokeColor = theme.clearspaceBox;
        innerRect.strokeDashes = [2, 2];

        // 3. Engineering Dimension Lines with Arrowheads & Badges
        if (config.enableDimensionLines !== false) {
            var label = (multiplier === 1.0) ? "X" : (multiplier + "X");

            // Top dimension
            this.drawDimensionArrow(subDims, [left, top + margin], [left, top], label, "vertical", theme);
            // Left dimension
            this.drawDimensionArrow(subDims, [left - margin, top], [left, top], label, "horizontal", theme);
            // Right dimension
            this.drawDimensionArrow(subDims, [right, top], [right + margin, top], label, "horizontal", theme);
            // Bottom dimension
            this.drawDimensionArrow(subDims, [left, bottom], [left, bottom - margin], label, "vertical", theme);
        }

        // 4. Exclusion Zone Hatching
        if (config.enableHatching) {
            this.drawExclusionHatching(subHatch, outTop, outLeft, outWidth, outHeight, margin, theme);
        }
    },

    drawDimensionArrow: function(layer, pStart, pEnd, labelText, orientation, theme) {
        var line = layer.pathItems.add();
        line.setEntirePath([pStart, pEnd]);
        line.stroked = true;
        line.filled = false;
        line.strokeWidth = 0.5;
        line.strokeColor = theme.dimension;

        // End Ticks / Arrows
        var tickLen = 4.0;
        if (orientation === "horizontal") {
            // Vertical ticks at start and end
            var t1 = layer.pathItems.add();
            t1.setEntirePath([[pStart[0], pStart[1] + tickLen], [pStart[0], pStart[1] - tickLen]]);
            t1.stroked = true; t1.strokeWidth = 0.5; t1.strokeColor = theme.dimension;

            var t2 = layer.pathItems.add();
            t2.setEntirePath([[pEnd[0], pEnd[1] + tickLen], [pEnd[0], pEnd[1] - tickLen]]);
            t2.stroked = true; t2.strokeWidth = 0.5; t2.strokeColor = theme.dimension;
        } else {
            // Horizontal ticks at start and end
            var t3 = layer.pathItems.add();
            t3.setEntirePath([[pStart[0] - tickLen, pStart[1]], [pStart[0] + tickLen, pStart[1]]]);
            t3.stroked = true; t3.strokeWidth = 0.5; t3.strokeColor = theme.dimension;

            var t4 = layer.pathItems.add();
            t4.setEntirePath([[pEnd[0] - tickLen, pEnd[1]], [pEnd[0] + tickLen, pEnd[1]]]);
            t4.stroked = true; t4.strokeWidth = 0.5; t4.strokeColor = theme.dimension;
        }

        // 'X' Typography Callout
        var midX = (pStart[0] + pEnd[0]) / 2.0;
        var midY = (pStart[1] + pEnd[1]) / 2.0;

        try {
            var tf = layer.textFrames.add();
            tf.contents = labelText;
            tf.position = [midX - 3.5, midY + 4.0];
            tf.textRange.characterAttributes.size = 8.0;
            tf.textRange.characterAttributes.fillColor = theme.dimension;
        } catch (e) {
            // Text frame fallback if font issue
        }
    },

    drawExclusionHatching: function(layer, outTop, outLeft, outWidth, outHeight, margin, theme) {
        var hGroup = layer.groupItems.add();
        var step = 14.0;

        // Top band
        for (var x = outLeft; x < outLeft + outWidth; x += step) {
            var l = hGroup.pathItems.add();
            l.setEntirePath([[x, outTop], [x + margin, outTop - margin]]);
            l.stroked = true; l.filled = false; l.strokeWidth = 0.25; l.strokeColor = theme.clearspaceHatch;
            l.opacity = 35;
        }

        // Bottom band
        var bTop = outTop - outHeight + margin;
        for (var bx = outLeft; bx < outLeft + outWidth; bx += step) {
            var lb = hGroup.pathItems.add();
            lb.setEntirePath([[bx, bTop], [bx + margin, bTop - margin]]);
            lb.stroked = true; lb.filled = false; lb.strokeWidth = 0.25; lb.strokeColor = theme.clearspaceHatch;
            lb.opacity = 35;
        }
    }
};


// =================== src/engine/LockupEngine.jsx ===================
/**
 * LogoGridStudio Pro - Lockup & Alignment Engine
 * Analyzes multi-element brand assets (Symbol, Wordmark, Tagline) and draws alignment axes & gap brackets
 */

var LockupEngine = {
    generate: function(doc, targetItems, config, theme) {
        if (!targetItems || targetItems.length < 2) {
            alert("Please select at least 2 elements (e.g. Logomark and Logotype) to generate lockup guides.");
            return;
        }

        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.LOCKUP);
        LayerManager.clearLayer(moduleLayer);

        var subAxes = LayerManager.getOrCreateSublayer(moduleLayer, "Alignment_Axes");
        var subBrackets = LayerManager.getOrCreateSublayer(moduleLayer, "Spacing_Brackets");
        var subBoxes = LayerManager.getOrCreateSublayer(moduleLayer, "Component_Boxes");

        // Sort items by horizontal position (left to right)
        var items = [];
        for (var k = 0; k < targetItems.length; k++) {
            items.push(targetItems[k]);
        }
        items.sort(function(a, b) {
            return a.geometricBounds[1] - b.geometricBounds[1];
        });

        var totalBounds = GeometryUtils.getSelectionBounds(items);
        var spanLeft = totalBounds[1] - 40;
        var spanRight = totalBounds[3] + 40;

        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var b = item.geometricBounds; // [top, left, bottom, right]
            var top = b[0], left = b[1], bottom = b[2], right = b[3];
            var centerY = (top + bottom) / 2.0;

            // 1. Component Bounding Box
            var box = subBoxes.pathItems.rectangle(top, left, right - left, top - bottom);
            box.filled = false;
            box.stroked = true;
            box.strokeWidth = 0.35;
            box.strokeColor = theme.lockupAxis;
            box.strokeDashes = [3, 3];

            // 2. Centerline
            if (config.enableLockupAxes !== false) {
                var cLine = subAxes.pathItems.add();
                cLine.setEntirePath([[spanLeft, centerY], [spanRight, centerY]]);
                cLine.stroked = true; cLine.filled = false; cLine.strokeWidth = 0.45;
                cLine.strokeColor = theme.lockupAxis;
                cLine.strokeDashes = [8, 3, 2, 3];
            }

            // 3. Baseline & Cap-Height guides for text / second component
            if (config.enableBaselineCap !== false) {
                // Baseline
                var baseL = subAxes.pathItems.add();
                baseL.setEntirePath([[spanLeft, bottom], [spanRight, bottom]]);
                baseL.stroked = true; baseL.filled = false; baseL.strokeWidth = 0.35;
                baseL.strokeColor = theme.lockupAxis;

                // Cap-height / Top bound
                var capL = subAxes.pathItems.add();
                capL.setEntirePath([[spanLeft, top], [spanRight, top]]);
                capL.stroked = true; capL.filled = false; capL.strokeWidth = 0.35;
                capL.strokeColor = theme.lockupAxis;
            }

            // 4. Inter-element Spacing Bracket
            if (config.enableGapBracket !== false && i < items.length - 1) {
                var nextItem = items[i + 1];
                var nextB = nextItem.geometricBounds;
                var gapStart = right;
                var gapEnd = nextB[1];

                if (gapEnd > gapStart) {
                    var midY = (top + bottom) / 2.0;
                    this.drawGapBracket(subBrackets, gapStart, gapEnd, midY, theme);
                }
            }
        }
    },

    drawGapBracket: function(layer, xStart, xEnd, y, theme) {
        var gap = Math.round(xEnd - xStart);
        var line = layer.pathItems.add();
        line.setEntirePath([[xStart, y], [xEnd, y]]);
        line.stroked = true;
        line.filled = false;
        line.strokeWidth = 0.75;
        line.strokeColor = theme.dimension;

        // End Ticks
        var tickSize = 4.0;
        var t1 = layer.pathItems.add();
        t1.setEntirePath([[xStart, y + tickSize], [xStart, y - tickSize]]);
        t1.stroked = true; t1.strokeWidth = 0.5; t1.strokeColor = theme.dimension;

        var t2 = layer.pathItems.add();
        t2.setEntirePath([[xEnd, y + tickSize], [xEnd, y - tickSize]]);
        t2.stroked = true; t2.strokeWidth = 0.5; t2.strokeColor = theme.dimension;

        // Typography Callout
        try {
            var tf = layer.textFrames.add();
            tf.contents = gap + " pt";
            tf.position = [xStart + (gap / 2.0) - 10, y + 14];
            tf.textRange.characterAttributes.size = 7.5;
            tf.textRange.characterAttributes.fillColor = theme.dimension;
        } catch (e) {}
    }
};


// =================== src/engine/BaseGridEngine.jsx ===================
/**
 * LogoGridStudio Pro - Base Grid & Foundation Engine
 * Generates Modular Square, Isometric 30/60, Hexagonal, Golden Ratio, and Polar Radial grids
 */

var BaseGridEngine = {
    generate: function(doc, config, theme) {
        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.BASE_GRID);
        LayerManager.clearLayer(moduleLayer);

        var bounds;
        if (doc.selection && doc.selection.length > 0) {
            bounds = GeometryUtils.getSelectionBounds(doc.selection);
            var pad = 60.0;
            bounds = [bounds[0] + pad, bounds[1] - pad, bounds[2] - pad, bounds[3] + pad];
        } else {
            bounds = GeometryUtils.getArtboardBounds(doc);
        }

        var gridType = config.baseGridType || "Square";

        if (gridType === "Square") {
            this.drawSquareGrid(moduleLayer, bounds, config.gridCellSize || 20, config.gridSubdivisions || 4, theme);
        } else if (gridType === "Isometric") {
            this.drawIsometricGrid(moduleLayer, bounds, config.gridCellSize || 30, theme);
        } else if (gridType === "Hexagon") {
            this.drawHexagonGrid(moduleLayer, bounds, config.gridCellSize || 25, theme);
        } else if (gridType === "Golden") {
            this.drawGoldenRatioGrid(moduleLayer, bounds, config.goldenScale || 120, theme);
        } else if (gridType === "Polar") {
            this.drawPolarGrid(moduleLayer, bounds, config.polarRings || 6, config.polarSpokes || 12, theme);
        }
    },

    drawSquareGrid: function(layer, bounds, cellSize, subdivs, theme) {
        var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
        var width = right - left, height = top - bottom;
        var subSize = cellSize / (subdivs || 4);

        var subMajor = LayerManager.getOrCreateSublayer(layer, "Major_Grid");
        var subMinor = LayerManager.getOrCreateSublayer(layer, "Minor_Grid");

        // Minor grid lines
        for (var x = left; x <= right; x += subSize) {
            var isMajor = (Math.abs((x - left) % cellSize) < 1.0 || Math.abs((x - left) % cellSize - cellSize) < 1.0);
            var targetLayer = isMajor ? subMajor : subMinor;
            var vl = targetLayer.pathItems.add();
            vl.setEntirePath([[x, top], [x, bottom]]);
            vl.stroked = true; vl.filled = false;
            vl.strokeWidth = isMajor ? 0.45 : 0.2;
            vl.strokeColor = isMajor ? theme.baseGridMajor : theme.baseGridMinor;
        }

        for (var y = bottom; y <= top; y += subSize) {
            var isMajorY = (Math.abs((y - bottom) % cellSize) < 1.0 || Math.abs((y - bottom) % cellSize - cellSize) < 1.0);
            var targetLayerY = isMajorY ? subMajor : subMinor;
            var hl = targetLayerY.pathItems.add();
            hl.setEntirePath([[left, y], [right, y]]);
            hl.stroked = true; hl.filled = false;
            hl.strokeWidth = isMajorY ? 0.45 : 0.2;
            hl.strokeColor = isMajorY ? theme.baseGridMajor : theme.baseGridMinor;
        }
    },

    drawIsometricGrid: function(layer, bounds, cellSize, theme) {
        var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
        var width = right - left, height = top - bottom;
        var isoGroup = layer.groupItems.add();

        // 1. Vertical lines
        for (var vx = left; vx <= right; vx += cellSize) {
            var v = isoGroup.pathItems.add();
            v.setEntirePath([[vx, top], [vx, bottom]]);
            v.stroked = true; v.filled = false; v.strokeWidth = 0.3; v.strokeColor = theme.baseGridMajor;
        }

        // 2. 30-degree and -30-degree diagonals (tan(30) = 1 / sqrt(3) ~= 0.57735)
        var tan30 = 0.577350269;
        var diagStep = cellSize / (tan30 * 2.0);

        for (var d = left - height * 2; d <= right + height * 2; d += diagStep) {
            // Diagonal / (30 deg)
            var p1 = [d, bottom];
            var p2 = [d + height / tan30, top];
            var dLine1 = isoGroup.pathItems.add();
            dLine1.setEntirePath([p1, p2]);
            dLine1.stroked = true; dLine1.filled = false; dLine1.strokeWidth = 0.3; dLine1.strokeColor = theme.baseGridMajor;

            // Diagonal \ (-30 deg)
            var p3 = [d, top];
            var p4 = [d + height / tan30, bottom];
            var dLine2 = isoGroup.pathItems.add();
            dLine2.setEntirePath([p3, p4]);
            dLine2.stroked = true; dLine2.filled = false; dLine2.strokeWidth = 0.3; dLine2.strokeColor = theme.baseGridMajor;
        }
    },

    drawHexagonGrid: function(layer, bounds, hexRadius, theme) {
        var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
        var r = hexRadius || 25.0;
        var w = Math.sqrt(3) * r;
        var h = 1.5 * r;
        var hexGroup = layer.groupItems.add();

        var row = 0;
        for (var y = top; y >= bottom - r; y -= h) {
            var xOffset = (row % 2 === 1) ? (w / 2.0) : 0.0;
            for (var x = left + xOffset; x <= right + w; x += w) {
                var hex = hexGroup.pathItems.add();
                var pts = [];
                for (var a = 0; a < 6; a++) {
                    var angleRad = (Math.PI / 180.0) * (60.0 * a + 30.0);
                    pts.push([x + r * Math.cos(angleRad), y + r * Math.sin(angleRad)]);
                }
                hex.setEntirePath(pts);
                hex.closed = true;
                hex.stroked = true; hex.filled = false; hex.strokeWidth = 0.35; hex.strokeColor = theme.baseGridMajor;
            }
            row++;
        }
    },

    drawGoldenRatioGrid: function(layer, bounds, baseScale, theme) {
        var phi = 1.6180339887;
        var centerX = (bounds[1] + bounds[3]) / 2.0;
        var centerY = (bounds[0] + bounds[2]) / 2.0;
        var s = baseScale || 100.0;

        var subCircles = LayerManager.getOrCreateSublayer(layer, "Golden_Circles");
        var subRects = LayerManager.getOrCreateSublayer(layer, "Golden_Rectangles");

        // 1. Concentric Golden Ratio Circles
        var radii = [s / (phi * phi * phi), s / (phi * phi), s / phi, s, s * phi, s * phi * phi];
        for (var i = 0; i < radii.length; i++) {
            var rad = radii[i];
            var c = subCircles.pathItems.ellipse(centerY + rad, centerX - rad, rad * 2.0, rad * 2.0);
            c.filled = false; c.stroked = true; c.strokeWidth = 0.4; c.strokeColor = theme.circle;
            c.strokeDashes = [4, 4];
        }

        // 2. Golden Rectangles Matrix
        var rectW = s * phi;
        var rectH = s;
        var gRect = subRects.pathItems.rectangle(centerY + rectH / 2.0, centerX - rectW / 2.0, rectW, rectH);
        gRect.filled = false; gRect.stroked = true; gRect.strokeWidth = 0.5; gRect.strokeColor = theme.baseGridMajor;
    },

    drawPolarGrid: function(layer, bounds, ringCount, spokeCount, theme) {
        var centerX = (bounds[1] + bounds[3]) / 2.0;
        var centerY = (bounds[0] + bounds[2]) / 2.0;
        var maxR = Math.min(bounds[3] - bounds[1], bounds[0] - bounds[2]) / 2.0;
        var ringStep = maxR / (ringCount || 6);

        var polarGroup = layer.groupItems.add();

        // 1. Concentric Rings
        for (var r = ringStep; r <= maxR; r += ringStep) {
            var ring = polarGroup.pathItems.ellipse(centerY + r, centerX - r, r * 2.0, r * 2.0);
            ring.filled = false; ring.stroked = true; ring.strokeWidth = 0.35; ring.strokeColor = theme.baseGridMajor;
        }

        // 2. Radial Spokes
        var spokes = spokeCount || 12;
        for (var s = 0; s < spokes; s++) {
            var angleRad = (Math.PI * 2.0 / spokes) * s;
            var endX = centerX + maxR * Math.cos(angleRad);
            var endY = centerY + maxR * Math.sin(angleRad);
            var spoke = polarGroup.pathItems.add();
            spoke.setEntirePath([[centerX, centerY], [endX, endY]]);
            spoke.stroked = true; spoke.filled = false; spoke.strokeWidth = 0.3; spoke.strokeColor = theme.baseGridMinor;
        }
    }
};


// =================== src/engine/BentoEngine.jsx ===================
/**
 * LogoGridStudio Pro - Bento Presentation Grid Engine
 * Algorithmic Bento matrix generation (Simple, Brick, Centered layouts across 3-12 cells)
 */

var BentoEngine = {
    generate: function(doc, config, theme) {
        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.BENTO);
        LayerManager.clearLayer(moduleLayer);

        var bounds;
        if (doc.selection && doc.selection.length > 0 && doc.selection[0].typename === "PathItem") {
            bounds = doc.selection[0].geometricBounds;
        } else {
            var abBounds = GeometryUtils.getArtboardBounds(doc);
            var pad = 60.0;
            bounds = [abBounds[0] - pad, abBounds[1] + pad, abBounds[2] + pad, abBounds[3] - pad];
        }

        var top = bounds[0], left = bounds[1];
        var totalW = bounds[3] - bounds[1];
        var totalH = bounds[0] - bounds[2];

        var layoutType = config.bentoLayout || "simple";
        var count = config.bentoSections || 6;
        var gutter = config.bentoGutter || 12;
        var radius = config.bentoCornerRadius || 8;
        var rcw = config.bentoRandomWidths || false;

        var matrix = this.computeMatrix(layoutType, count, rcw);
        if (!matrix) return;

        var cols = matrix.cols, rows = matrix.rows;
        var cellW = (totalW - gutter * (cols - 1)) / cols;
        var cellH = (totalH - gutter * (rows - 1)) / rows;

        var bentoGroup = moduleLayer.groupItems.add();

        for (var i = 0; i < matrix.cells.length; i++) {
            var cell = matrix.cells[i];
            var cCol = cell.col;
            var cRow = cell.row;
            var cColspan = cell.colspan || 1;
            var cRowspan = cell.rowspan || 1;

            var x = left + cCol * (cellW + gutter);
            var y = top - cRow * (cellH + gutter);
            var w = cellW * cColspan + gutter * (cColspan - 1);
            var h = cellH * cRowspan + gutter * (cRowspan - 1);

            var rect = bentoGroup.pathItems.roundedRectangle(y, x, w, h, radius, radius);
            rect.filled = true;
            rect.fillColor = theme.bentoFill;
            rect.stroked = true;
            rect.strokeWidth = 0.5;
            rect.strokeColor = theme.bentoStroke;
        }
    },

    computeMatrix: function(type, count, rcw) {
        if (type === "simple") {
            return this._getSimpleLayout(count, rcw);
        } else if (type === "brick") {
            return this._getBrickLayout(count, rcw);
        } else if (type === "centered") {
            return this._getCenteredLayout(count, rcw);
        }
        return this._getSimpleLayout(count, rcw);
    },

    _getSimpleLayout: function(count, rcw) {
        var rows = count > 7 ? 4 : 3;
        var cols = count > 7 ? 4 : 3;

        switch (count) {
            case 3:
                var cw3 = !rcw ? 2 : 1.5;
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: cw3, rowspan: 2 },
                        { row: 0, col: cw3, colspan: 3 - cw3, rowspan: 2 },
                        { row: 2, col: 0, colspan: 3, rowspan: 1 }
                    ]
                };
            case 4:
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: 2, rowspan: 2 },
                        { row: 0, col: 2, colspan: 1, rowspan: 1 },
                        { row: 1, col: 2, colspan: 1, rowspan: 2 },
                        { row: 2, col: 0, colspan: 2, rowspan: 1 }
                    ]
                };
            case 5:
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: 1, rowspan: 1 },
                        { row: 1, col: 0, colspan: 1, rowspan: 2 },
                        { row: 0, col: 1, colspan: 2, rowspan: 2 },
                        { row: 2, col: 1, colspan: 1, rowspan: 1 },
                        { row: 2, col: 2, colspan: 1, rowspan: 1 }
                    ]
                };
            case 6:
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: 1, rowspan: 1 },
                        { row: 1, col: 0, colspan: 1, rowspan: 1 },
                        { row: 0, col: 1, colspan: 2, rowspan: 2 },
                        { row: 2, col: 0, colspan: 1, rowspan: 1 },
                        { row: 2, col: 1, colspan: 1, rowspan: 1 },
                        { row: 2, col: 2, colspan: 1, rowspan: 1 }
                    ]
                };
            case 7:
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: 1, rowspan: 2 },
                        { row: 0, col: 1, colspan: 1, rowspan: 1 },
                        { row: 0, col: 2, colspan: 1, rowspan: 1 },
                        { row: 1, col: 1, colspan: 2, rowspan: 1 },
                        { row: 2, col: 0, colspan: 1, rowspan: 1 },
                        { row: 2, col: 1, colspan: 1, rowspan: 1 },
                        { row: 2, col: 2, colspan: 1, rowspan: 1 }
                    ]
                };
            case 8:
                return {
                    cols: 4, rows: 4,
                    cells: [
                        { row: 0, col: 0, colspan: 2, rowspan: 2 },
                        { row: 0, col: 2, colspan: 2, rowspan: 1 },
                        { row: 1, col: 2, colspan: 1, rowspan: 1 },
                        { row: 1, col: 3, colspan: 1, rowspan: 3 },
                        { row: 2, col: 0, colspan: 1, rowspan: 2 },
                        { row: 2, col: 1, colspan: 1, rowspan: 1 },
                        { row: 2, col: 2, colspan: 1, rowspan: 1 },
                        { row: 3, col: 1, colspan: 2, rowspan: 1 }
                    ]
                };
            default:
                // Grid layout for 9 to 12
                var cells = [];
                for (var r = 0; r < rows; r++) {
                    for (var c = 0; c < cols; c++) {
                        if (cells.length < count) {
                            cells.push({ row: r, col: c, colspan: 1, rowspan: 1 });
                        }
                    }
                }
                return { cols: cols, rows: rows, cells: cells };
        }
    },

    _getBrickLayout: function(count, rcw) {
        var cols = 3, rows = 3;
        var cells = [];
        if (count === 3) {
            cells = [
                { row: 0, col: 0, colspan: 1.5, rowspan: 1.5 },
                { row: 0, col: 1.5, colspan: 1.5, rowspan: 1.5 },
                { row: 1.5, col: 0, colspan: 3, rowspan: 1.5 }
            ];
        } else if (count === 4) {
            cells = [
                { row: 0, col: 0, colspan: 1, rowspan: 1.5 },
                { row: 0, col: 1, colspan: 2, rowspan: 1.5 },
                { row: 1.5, col: 0, colspan: 2, rowspan: 1.5 },
                { row: 1.5, col: 2, colspan: 1, rowspan: 1.5 }
            ];
        } else {
            return this._getSimpleLayout(count, rcw);
        }
        return { cols: cols, rows: rows, cells: cells };
    },

    _getCenteredLayout: function(count, rcw) {
        return {
            cols: 4, rows: 4,
            cells: [
                { row: 0, col: 0, colspan: 1, rowspan: 4 },
                { row: 0, col: 1, colspan: 2, rowspan: 2 },
                { row: 0, col: 3, colspan: 1, rowspan: 4 },
                { row: 2, col: 1, colspan: 1, rowspan: 2 },
                { row: 2, col: 2, colspan: 1, rowspan: 2 }
            ]
        };
    }
};


// =================== src/ui/ScriptUIBuilder.jsx ===================
/**
 * LogoGridStudio Pro - ScriptUI Dialog Interface
 * Clean, modern, responsive ScriptUI user interface with tabbed navigation
 */

var ScriptUIBuilder = {
    showDialog: function(doc) {
        if (!doc) {
            alert("No active document. Please open or create a document in Adobe Illustrator.");
            return;
        }

        var config = {};
        for (var key in LGS_CONSTANTS.DEFAULTS) {
            if (LGS_CONSTANTS.DEFAULTS.hasOwnProperty(key)) {
                config[key] = LGS_CONSTANTS.DEFAULTS[key];
            }
        }

        var win = new Window("dialog", LGS_CONSTANTS.APP_NAME + " v" + LGS_CONSTANTS.VERSION);
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 10;
        win.margins = 16;

        // Header
        var headerGroup = win.add("group");
        headerGroup.orientation = "row";
        headerGroup.alignChildren = ["left", "center"];
        var titleText = headerGroup.add("statictext", undefined, "⚡ " + LGS_CONSTANTS.APP_NAME);
        titleText.graphics.font = ScriptUI.newFont("dialog", "bold", 15);
        var subText = headerGroup.add("statictext", undefined, "— Professional Logo & Brand Grid System");

        // Tabbed Panel
        var tpanel = win.add("tabbedpanel");
        tpanel.alignChildren = ["fill", "fill"];
        tpanel.preferredSize.width = 460;
        tpanel.preferredSize.height = 320;

        // ================= TAB 1: CONSTRUCTION =================
        var tabConst = tpanel.add("tab", undefined, "Construction");
        tabConst.alignChildren = ["fill", "top"];
        tabConst.spacing = 8;
        tabConst.margins = 12;

        var pAnchors = tabConst.add("panel", undefined, "Anchors & Handles");
        pAnchors.orientation = "row";
        pAnchors.alignChildren = ["left", "center"];
        pAnchors.spacing = 12;

        var chkAnchors = pAnchors.add("checkbox", undefined, "Anchors");
        chkAnchors.value = config.enableAnchors;
        pAnchors.add("statictext", undefined, "Style:");
        var ddAnchorStyle = pAnchors.add("dropdownlist", undefined, LGS_CONSTANTS.ANCHOR_STYLES);
        ddAnchorStyle.selection = 1; // Circle
        pAnchors.add("statictext", undefined, "Size:");
        var txtAnchorSize = pAnchors.add("edittext", undefined, config.anchorSize.toString());
        txtAnchorSize.characters = 3;

        var pHandles = tabConst.add("panel", undefined, "Bézier Handles & Outlines");
        pHandles.orientation = "row";
        pHandles.alignChildren = ["left", "center"];
        pHandles.spacing = 12;
        var chkHandles = pHandles.add("checkbox", undefined, "Handles");
        chkHandles.value = config.enableHandles;
        var chkOutlines = pHandles.add("checkbox", undefined, "Wireframe Outlines");
        chkOutlines.value = config.enableOutlines;

        var pGeo = tabConst.add("panel", undefined, "Tangents & Fitted Circles");
        pGeo.orientation = "column";
        pGeo.alignChildren = ["fill", "top"];
        pGeo.spacing = 6;

        var rowGeo1 = pGeo.add("group");
        rowGeo1.orientation = "row";
        var chkGridlines = rowGeo1.add("checkbox", undefined, "Tangent Extensions");
        chkGridlines.value = config.enableGridlines;
        rowGeo1.add("statictext", undefined, "Sensitivity:");
        var ddSensitivity = rowGeo1.add("dropdownlist", undefined, ["Low (Anchors)", "Medium", "High (Extrema)"]);
        ddSensitivity.selection = config.gridlineSensitivity;

        var rowGeo2 = pGeo.add("group");
        rowGeo2.orientation = "row";
        var chkCircles = rowGeo2.add("checkbox", undefined, "Fitted Arc Circles (R=...)");
        chkCircles.value = config.enableCircles;

        // ================= TAB 2: CLEARSPACE =================
        var tabClear = tpanel.add("tab", undefined, "Clearspace");
        tabClear.alignChildren = ["fill", "top"];
        tabClear.spacing = 8;
        tabClear.margins = 12;

        var pUnit = tabClear.add("panel", undefined, "Exclusion Zone (X Unit)");
        pUnit.orientation = "column";
        pUnit.alignChildren = ["fill", "top"];
        pUnit.spacing = 8;

        var rowUnit = pUnit.add("group");
        rowUnit.orientation = "row";
        rowUnit.add("statictext", undefined, "Unit Derivation:");
        var ddUnitMode = rowUnit.add("dropdownlist", undefined, ["Logomark Proportional", "Height Based", "Width Based", "Custom Points"]);
        ddUnitMode.selection = 0;
        rowUnit.add("statictext", undefined, "Multiplier:");
        var txtMult = rowUnit.add("edittext", undefined, "1.0");
        txtMult.characters = 3;

        var pClearOpts = tabClear.add("panel", undefined, "Annotations & Shading");
        pClearOpts.orientation = "column";
        pClearOpts.alignChildren = ["left", "top"];
        pClearOpts.spacing = 6;
        var chkDims = pClearOpts.add("checkbox", undefined, "Engineering Dimension Lines & Arrows");
        chkDims.value = config.enableDimensionLines;
        var chkHatch = pClearOpts.add("checkbox", undefined, "Subtle Exclusion Zone Hatching");
        chkHatch.value = config.enableHatching;

        // ================= TAB 3: LOCKUP =================
        var tabLockup = tpanel.add("tab", undefined, "Lockup & Align");
        tabLockup.alignChildren = ["fill", "top"];
        tabLockup.spacing = 8;
        tabLockup.margins = 12;

        var pLockup = tabLockup.add("panel", undefined, "Multi-Element Alignment Axes");
        pLockup.orientation = "column";
        pLockup.alignChildren = ["left", "top"];
        pLockup.spacing = 8;
        var chkLockupAxes = pLockup.add("checkbox", undefined, "Centerline Optical Axes");
        chkLockupAxes.value = config.enableLockupAxes;
        var chkBaseCap = pLockup.add("checkbox", undefined, "Baseline & Cap-Height Boundaries");
        chkBaseCap.value = config.enableBaselineCap;
        var chkGap = pLockup.add("checkbox", undefined, "Inter-Element Spacing Gap Brackets");
        chkGap.value = config.enableGapBracket;

        // ================= TAB 4: BASE GRIDS =================
        var tabBase = tpanel.add("tab", undefined, "Base Grids");
        tabBase.alignChildren = ["fill", "top"];
        tabBase.spacing = 8;
        tabBase.margins = 12;

        var pBaseType = tabBase.add("panel", undefined, "Foundation Grid Matrix");
        pBaseType.orientation = "column";
        pBaseType.alignChildren = ["fill", "top"];
        pBaseType.spacing = 8;

        var rowBase1 = pBaseType.add("group");
        rowBase1.orientation = "row";
        rowBase1.add("statictext", undefined, "Grid Type:");
        var ddBaseGrid = rowBase1.add("dropdownlist", undefined, ["Square (Modular)", "Isometric (30°/60°)", "Hexagon", "Golden Ratio (Phi)", "Polar Radial"]);
        ddBaseGrid.selection = 0;

        var rowBase2 = pBaseType.add("group");
        rowBase2.orientation = "row";
        rowBase2.add("statictext", undefined, "Cell / Scale Size:");
        var txtGridSize = rowBase2.add("edittext", undefined, config.gridCellSize.toString());
        txtGridSize.characters = 4;
        rowBase2.add("statictext", undefined, "Subdivisions / Spokes:");
        var txtSubdivs = rowBase2.add("edittext", undefined, config.gridSubdivisions.toString());
        txtSubdivs.characters = 3;

        // ================= TAB 5: BENTO =================
        var tabBento = tpanel.add("tab", undefined, "Bento Layout");
        tabBento.alignChildren = ["fill", "top"];
        tabBento.spacing = 8;
        tabBento.margins = 12;

        var pBento = tabBento.add("panel", undefined, "Presentation Bento Matrix");
        pBento.orientation = "column";
        pBento.alignChildren = ["fill", "top"];
        pBento.spacing = 8;

        var rowB1 = pBento.add("group");
        rowB1.orientation = "row";
        rowB1.add("statictext", undefined, "Layout Style:");
        var ddBentoLayout = rowB1.add("dropdownlist", undefined, ["Simple", "Brick", "Centered"]);
        ddBentoLayout.selection = 0;
        rowB1.add("statictext", undefined, "Sections (3-12):");
        var txtBentoCount = rowB1.add("edittext", undefined, "6");
        txtBentoCount.characters = 2;

        var rowB2 = pBento.add("group");
        rowB2.orientation = "row";
        rowB2.add("statictext", undefined, "Gutter (pt):");
        var txtBentoGutter = rowB2.add("edittext", undefined, "12");
        txtBentoGutter.characters = 3;
        rowB2.add("statictext", undefined, "Corner Radius (pt):");
        var txtBentoRadius = rowB2.add("edittext", undefined, "8");
        txtBentoRadius.characters = 3;

        // ================= TAB 6: THEMES & SETTINGS =================
        var tabSettings = tpanel.add("tab", undefined, "Themes");
        tabSettings.alignChildren = ["fill", "top"];
        tabSettings.spacing = 8;
        tabSettings.margins = 12;

        var pTheme = tabSettings.add("panel", undefined, "Visual Palette & Stroke Presets");
        pTheme.orientation = "column";
        pTheme.alignChildren = ["fill", "top"];
        pTheme.spacing = 8;

        var rowT1 = pTheme.add("group");
        rowT1.orientation = "row";
        rowT1.add("statictext", undefined, "Color Profile:");
        var ddTheme = rowT1.add("dropdownlist", undefined, ["Blueprint Cyan", "Tech Magenta", "Minimal Slate", "Dark Neon"]);
        ddTheme.selection = 0;

        var rowT2 = pTheme.add("group");
        rowT2.orientation = "row";
        rowT2.add("statictext", undefined, "Artboard Overflow Padding (pt):");
        var txtPadding = rowT2.add("edittext", undefined, config.overflowPadding.toString());
        txtPadding.characters = 4;

        tpanel.selection = 0; // Default active tab

        // Action Buttons
        var btnGroup = win.add("group");
        btnGroup.orientation = "row";
        btnGroup.alignment = ["fill", "bottom"];
        btnGroup.alignChildren = ["fill", "center"];

        var btnClear = btnGroup.add("button", undefined, "Clear Grids");
        var btnGenTab = btnGroup.add("button", undefined, "Generate Active Tab", { name: "ok" });
        var btnGenAll = btnGroup.add("button", undefined, "✨ Generate All");
        var btnClose = btnGroup.add("button", undefined, "Close", { name: "cancel" });

        // Helper to collect live config
        function readConfig() {
            config.enableAnchors = chkAnchors.value;
            config.anchorStyle = ddAnchorStyle.selection ? ddAnchorStyle.selection.text : "Circle";
            config.anchorSize = parseFloat(txtAnchorSize.text) || 4.5;
            config.enableHandles = chkHandles.value;
            config.enableOutlines = chkOutlines.value;
            config.enableGridlines = chkGridlines.value;
            config.gridlineSensitivity = ddSensitivity.selection ? ddSensitivity.selection.index : 1;
            config.enableCircles = chkCircles.value;

            var uMap = ["Logomark", "Height", "Width", "Custom"];
            config.unitMode = uMap[ddUnitMode.selection ? ddUnitMode.selection.index : 0];
            config.multiplier = parseFloat(txtMult.text) || 1.0;
            config.enableDimensionLines = chkDims.value;
            config.enableHatching = chkHatch.value;

            config.enableLockupAxes = chkLockupAxes.value;
            config.enableBaselineCap = chkBaseCap.value;
            config.enableGapBracket = chkGap.value;

            var bMap = ["Square", "Isometric", "Hexagon", "Golden", "Polar"];
            config.baseGridType = bMap[ddBaseGrid.selection ? ddBaseGrid.selection.index : 0];
            config.gridCellSize = parseFloat(txtGridSize.text) || 20;
            config.gridSubdivisions = parseInt(txtSubdivs.text, 10) || 4;

            var blMap = ["simple", "brick", "centered"];
            config.bentoLayout = blMap[ddBentoLayout.selection ? ddBentoLayout.selection.index : 0];
            config.bentoSections = parseInt(txtBentoCount.text, 10) || 6;
            config.bentoGutter = parseFloat(txtBentoGutter.text) || 12;
            config.bentoCornerRadius = parseFloat(txtBentoRadius.text) || 8;

            var tKeys = ["CYAN", "MAGENTA", "SLATE", "DARK_MODE"];
            config.themeKey = tKeys[ddTheme.selection ? ddTheme.selection.index : 0];
            config.overflowPadding = parseFloat(txtPadding.text) || 80;

            return config;
        }

        // Button Handlers
        btnClear.onClick = function() {
            var root = doc.layers;
            try {
                var l = root.getByName(LGS_CONSTANTS.ROOT_LAYER_NAME);
                l.remove();
                app.redraw();
            } catch (e) {
                alert("No existing Logo Grid System found to clear.");
            }
        };

        btnGenTab.onClick = function() {
            var cfg = readConfig();
            var theme = ThemeManager.getResolvedTheme(doc, cfg.themeKey);
            var activeTabIndex = tpanel.selection ? tpanel.selection.index : 0;
            var sel = doc.selection;

            if (activeTabIndex === 0) { // Construction
                ConstructionEngine.generate(doc, sel, cfg, theme);
            } else if (activeTabIndex === 1) { // Clearspace
                ClearspaceEngine.generate(doc, sel, cfg, theme);
            } else if (activeTabIndex === 2) { // Lockup
                LockupEngine.generate(doc, sel, cfg, theme);
            } else if (activeTabIndex === 3) { // Base Grid
                BaseGridEngine.generate(doc, cfg, theme);
            } else if (activeTabIndex === 4) { // Bento
                BentoEngine.generate(doc, cfg, theme);
            } else if (activeTabIndex === 5) { // Themes / All
                ConstructionEngine.generate(doc, sel, cfg, theme);
            }

            app.redraw();
        };

        btnGenAll.onClick = function() {
            var cfg = readConfig();
            var theme = ThemeManager.getResolvedTheme(doc, cfg.themeKey);
            var sel = doc.selection;

            if (sel && sel.length > 0) {
                ConstructionEngine.generate(doc, sel, cfg, theme);
                ClearspaceEngine.generate(doc, sel, cfg, theme);
                if (sel.length >= 2) {
                    LockupEngine.generate(doc, sel, cfg, theme);
                }
            }
            BaseGridEngine.generate(doc, cfg, theme);
            app.redraw();
        };

        win.center();
        win.show();
    }
};


// =================== Entry Point ===================

// Main execution entry point
(function() {
    #target illustrator
    app.coordinateSystem = CoordinateSystem.ARTBOARDCOORDINATESYSTEM;

    if (app.documents.length === 0) {
        alert("LogoGridStudio Pro requires an active document.\n\nPlease open or create a document in Adobe Illustrator.");
        return;
    }

    try {
        ScriptUIBuilder.showDialog(app.activeDocument);
    } catch (err) {
        alert("LogoGridStudio Pro Error: " + err.message + "\nLine: " + err.line);
    }
})();
