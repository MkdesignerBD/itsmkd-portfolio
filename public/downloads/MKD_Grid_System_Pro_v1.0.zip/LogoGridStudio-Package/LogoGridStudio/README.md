# ⚡ LogoGridStudio Pro

> **The Industry Top 0.1% Professional Logo Grid, Clearspace & Brand Layout Studio for Adobe Illustrator.**  
> 100% Standalone ExtendScript (`.jsx`) • Zero Installation Friction • Zero DRM • Zero Latency • Works on macOS & Windows (Illustrator CS6 to 2026+).

---

## 🚀 Quick Start & Installation

### Option 1: Instant Run (Zero Install)
1. Open Adobe Illustrator and open any vector artwork/logo.
2. In Illustrator, go to **`File > Scripts > Other Script...`** (or press `Cmd + F12` on macOS / `Ctrl + F12` on Windows).
3. Select [`LogoGridStudioPro.jsx`](./LogoGridStudioPro.jsx).
4. The **LogoGridStudio Pro** panel will appear immediately.

### Option 2: Permanent Menu Shortcut
Place [`LogoGridStudioPro.jsx`](./LogoGridStudioPro.jsx) into your Adobe Illustrator Scripts folder:
- **macOS**: `/Applications/Adobe Illustrator <Year>/Presets/en_US/Scripts/`
- **Windows**: `C:\Program Files\Adobe\Adobe Illustrator <Year>\Presets\en_US\Scripts\`
- Restart Illustrator. You can now launch it directly from **`File > Scripts > LogoGridStudioPro`**.

---

## 💎 Feature Modules

```
                       ┌──────────────────────────────────────────────────┐
                       │               LOGO GRID STUDIO PRO               │
                       └────────────────────────┬─────────────────────────┘
                                                │
    ┌──────────────────────┬────────────────────┴────────────────┬──────────────────────┐
    ▼                      ▼                                     ▼                      ▼
┌──────────────────┐ ┌──────────────────┐                 ┌──────────────────┐ ┌──────────────────┐
│   Construction   │ │    Clearspace    │                 │ Lockup & Layout  │ │    Base Grids    │
│      Engine      │ │    Dimension     │                 │     & Bento      │ │   & Foundation   │
└────────┬─────────┘ └────────┬─────────┘                 └────────┬─────────┘ └────────┬─────────┘
         │                    │                                    │                    │
         ├► 4 Anchor Styles   ├► Proportional 'X' Margin           ├► Symbol:Wordmark   ├► Modular Square
         │  (Dot, Square,     ├► Auto 'X' Detection (Logomark/Cap) ├► Baseline/Cap-Hgt  ├► Isometric 30/60
         │   Diamond, Cross)  ├► Engineering Dimension Arrows      ├► Gap Brackets      ├► Hexagonal
         ├► Bézier Handles    ├► Corner 'X' Badges                 ├► Bento Generator   ├► Golden Ratio
         ├► Wireframe Outlines├► Diagonal Exclusion Hatching       │  (3-12 cells,      │  (Phi Rectangles,
         ├► Tangents & Extrema├► Units: pt, px, mm, in             │   simple/brick/    │   Fibonacci Spiral,
         └► Curvature Circles └► Tinted Overlay Zones              │   centered)        │   Golden Circles)
            with R=... labels                                      └► Alignment Axes    └► Polar / Radial
```

### 1. 📐 Construction Grids
- **4 Anchor Styles**: Customize vertex markers with **Circle**, **Square**, **Diamond**, or **Crosshair** geometry and adjustable point size.
- **Bézier Handles**: Traces incoming and outgoing control vectors terminating in styled handle-tip markers.
- **Structural Wireframes**: Generates pure hairline vector contours without fills.
- **Tangent & Extrema Extensions**: Automatically solves $B'(t) = 0$ to project horizontal and vertical tangent guide lines across the artwork boundaries.
- **Osculating Arc Reconstruction**: Analyzes Bézier curve curvature $\kappa(t)$ and fits concentric guide circles showing geometric radius $R$.

### 2. 🛡️ Clearspace & Exclusion Zones
- **Auto 'X' Derivation**: Automatically calculates unit 'X' from the logo's height, width, or logomark ratio, or accepts custom point values.
- **Proportional Multipliers**: Generate $0.5X, 1.0X, 1.5X, 2.0X$ protection boundaries with a single click.
- **Engineering Dimension Lines**: Draws technical dimension lines with end ticks, arrowheads, and typography badges (`X`).
- **Diagonal Exclusion Hatching**: Creates optional translucent $45^\circ$ diagonal hazard hatching across the safety margin.

### 3. ⚖️ Lockup & Alignment
- **Optical Alignment Axes**: Computes horizontal/vertical centerlines, baselines, and cap-heights across Logomark, Wordmark, and Tagline.
- **Inter-Element Spacing Brackets**: Automatically measures Euclidean distance between mark and text, rendering technical dimension brackets and exact pt values.
- **Component Framing**: Visualizes individual element bounding boxes to identify balance discrepancies.

### 4. 🌐 Base Grids & Proportional Layouts
- **Modular Square Grid**: Configurable major grid cells and minor subdivisions.
- **Isometric Grid (30°/60°)**: 3-way triangular grid for geometric and 3D marks.
- **Hexagonal Honeycomb**: Hexagonal tessellation for modern identity systems.
- **Golden Ratio Suite**: Phi rectangles ($1 : 1.618$), Fibonacci logarithmic spirals, and concentric golden circles.
- **Polar / Radial Grid**: Concentric circular rings with angular spokes ($15^\circ, 30^\circ, 45^\circ$).

### 5. 🍱 Presentation Bento Grid Engine
- **Algorithmic Bento Matrix**: Generates 3 to 12 responsive presentation cards.
- **Layout Styles**: **Simple** (Hero + Supporting), **Brick** (Staggered spans), and **Centered** (Hero focus).
- **Interactive Controls**: Live control over gutters, cell counts, corner radii, and randomized width variance.

### 6. 🎨 Themes & Layer Architecture
- **4 Instant Color Themes**:
  - `Blueprint Cyan`: Classic technical architectural blueprint.
  - `Tech Magenta`: High-contrast cyberpunk neon style.
  - `Minimal Slate`: Understated, luxury brand guideline grey.
  - `Dark Neon`: Electric emerald green on dark canvas.
- **100% Non-Destructive**: All generated vector elements are placed into dedicated, organized sublayers under `_LOGO_GRID_SYSTEM`. Original artwork is never modified.

---

## 🛠️ Project Structure

```
LogoGridStudio/
├── LogoGridStudioPro.jsx          # Master Standalone Production Script
├── build.py                       # Modular JSX Compiler / Bundler
├── README.md                      # Documentation
├── test/
│   └── test_math.py               # Calculus & Geometry Verification Suite
└── src/
    ├── core/
    │   └── Constants.jsx          # Default configs, theme palettes
    ├── math/
    │   ├── Vector2D.jsx           # 2D vector mathematics & raycasting
    │   ├── BezierMath.jsx         # Bézier derivatives, curvature & arc fitting
    │   └── GeometryUtils.jsx      # Recursive path unpacking & bounds
    ├── engine/
    │   ├── ConstructionEngine.jsx # Anchors, handles, wireframes, circles
    │   ├── ClearspaceEngine.jsx   # Exclusion zone, dimension arrows, badges
    │   ├── LockupEngine.jsx       # Alignment axes, symbol:wordmark ratios
    │   ├── BaseGridEngine.jsx     # Square, Iso, Hex, Golden, Polar grids
    │   └── BentoEngine.jsx        # Bento presentation layouts
    ├── utils/
    │   ├── LayerManager.jsx       # Non-destructive layer stack
    │   └── ThemeManager.jsx       # Native RGB/CMYK color conversion
    └── ui/
        └── ScriptUIBuilder.jsx    # Tabbed ScriptUI user interface
```

---

## 🧪 Verification & Testing

To run the automated mathematical verification test suite:
```bash
python3 LogoGridStudio/test/test_math.py
```
*Validates Bézier derivatives, curvature radius, osculating circle fitting, bounding box intersections, and ES3 syntax compliance.*
