#!/usr/bin/env python3
"""
LogoGridStudio Pro - Compiler & Bundler
Bundles modular JSX files into a single, production-ready standalone ExtendScript file.
"""

import os
import sys

MODULE_ORDER = [
    "src/core/Constants.jsx",
    "src/math/Vector2D.jsx",
    "src/math/BezierMath.jsx",
    "src/math/GeometryUtils.jsx",
    "src/utils/ThemeManager.jsx",
    "src/utils/LayerManager.jsx",
    "src/engine/ConstructionEngine.jsx",
    "src/engine/ClearspaceEngine.jsx",
    "src/engine/LockupEngine.jsx",
    "src/engine/BaseGridEngine.jsx",
    "src/engine/BentoEngine.jsx",
    "src/ui/ScriptUIBuilder.jsx"
]

ENTRY_POINT = """
// Main execution entry point
(function() {
    #target illustrator
    app.coordinateSystem = CoordinateSystem.ARTBOARDCOORDINATESYSTEM;

    if (app.documents.length === 0) {
        alert("LogoGridStudio Pro requires an active document.\\n\\nPlease open or create a document in Adobe Illustrator.");
        return;
    }

    try {
        ScriptUIBuilder.showDialog(app.activeDocument);
    } catch (err) {
        alert("LogoGridStudio Pro Error: " + err.message + "\\nLine: " + err.line);
    }
})();
"""

def bundle():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(base_dir, "LogoGridStudioPro.jsx")
    root_output_path = os.path.join(os.path.dirname(base_dir), "LogoGridStudioPro.jsx")

    header = """/**
 * LogoGridStudio Pro v1.0.0
 * Professional Logo Grid & Brand Geometry Studio for Adobe Illustrator
 * Compatible with Adobe Illustrator CS6 to 2026+ (macOS & Windows)
 *
 * 100% Standalone ExtendScript (Zero installation, zero DRM, zero latency)
 * Features:
 *   1. Construction Grids (Anchors, Handles, Wireframes, Tangent Extensions, Arc Circles)
 *   2. Clearspace & Exclusion Zones (Auto 'X' Detection, Dimension Lines, Callouts, Hatching)
 *   3. Lockup & Alignment (Symbol-to-Wordmark axes, Baselines, Cap-heights, Spacing Brackets)
 *   4. Base Grids (Modular Square, Isometric 30/60, Hexagonal, Golden Ratio, Polar Radial)
 *   5. Bento Matrix (Presentation layouts: Simple, Brick, Centered across 3-12 sections)
 *   6. Multi-Theme Presets (Blueprint Cyan, Tech Magenta, Minimal Slate, Dark Neon)
 */

"""

    bundled_content = [header]

    for rel_path in MODULE_ORDER:
        full_path = os.path.join(base_dir, rel_path)
        if not os.path.exists(full_path):
            print(f"Error: Missing module {full_path}")
            sys.exit(1)
        with open(full_path, "r", encoding="utf-8") as f:
            content = f.read()
            bundled_content.append(f"// =================== {rel_path} ===================\n")
            bundled_content.append(content)
            bundled_content.append("\n\n")

    bundled_content.append("// =================== Entry Point ===================\n")
    bundled_content.append(ENTRY_POINT)

    final_script = "".join(bundled_content)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(final_script)
    print(f"Successfully generated {output_path} ({len(final_script)} bytes)")

    # Also copy to workspace root for quick access
    with open(root_output_path, "w", encoding="utf-8") as f:
        f.write(final_script)
    print(f"Successfully copied to {root_output_path}")

if __name__ == "__main__":
    bundle()
