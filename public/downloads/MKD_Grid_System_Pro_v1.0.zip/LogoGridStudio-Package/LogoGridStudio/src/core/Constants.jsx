/**
 * LogoGridStudio Pro - Constants & Default Settings
 * Compatible with Adobe Illustrator CS6 to 2026+ (ExtendScript ES3)
 */

var LGS_CONSTANTS = {
    APP_NAME: "LogoGridStudio Pro",
    VERSION: "1.0.0",
    AUTHOR: "Antigravity",
    ROOT_LAYER_NAME: "_LOGO_GRID_SYSTEM",
    
    // Sublayer Names
    SUBLAYERS: {
        CONSTRUCTION: "_Construction_Grid",
        ANCHORS: "_Anchors",
        HANDLES: "_Handles",
        OUTLINES: "_Outlines",
        GRIDLINES: "_Gridlines",
        CIRCLES: "_Fitted_Circles",
        CLEARSPACE: "_Clearspace_System",
        LOCKUP: "_Lockup_Alignment",
        BASE_GRID: "_Base_Grid",
        BENTO: "_Bento_Presentation",
        ANNOTATIONS: "_Annotations"
    },

    // Anchor Marker Styles
    ANCHOR_STYLES: ["Square", "Circle", "Diamond", "Crosshair"],

    // Themes (RGB 0-255 format)
    THEMES: {
        CYAN: {
            name: "Blueprint Cyan",
            anchorFill: [0, 210, 255],
            anchorStroke: [0, 120, 200],
            handleLine: [0, 180, 240],
            handleTip: [0, 230, 255],
            outline: [0, 150, 220],
            gridline: [0, 190, 255],
            circle: [0, 220, 255],
            clearspaceBox: [0, 210, 255],
            clearspaceHatch: [0, 180, 240],
            dimension: [0, 220, 255],
            lockupAxis: [0, 210, 255],
            baseGridMajor: [0, 180, 240],
            baseGridMinor: [0, 120, 180],
            bentoFill: [240, 248, 255],
            bentoStroke: [0, 180, 240]
        },
        MAGENTA: {
            name: "Tech Magenta",
            anchorFill: [255, 40, 140],
            anchorStroke: [180, 10, 90],
            handleLine: [255, 70, 160],
            handleTip: [255, 120, 190],
            outline: [220, 30, 120],
            gridline: [255, 50, 150],
            circle: [255, 80, 170],
            clearspaceBox: [255, 40, 140],
            clearspaceHatch: [255, 80, 170],
            dimension: [255, 50, 150],
            lockupAxis: [255, 40, 140],
            baseGridMajor: [255, 60, 150],
            baseGridMinor: [180, 40, 100],
            bentoFill: [255, 240, 248],
            bentoStroke: [255, 60, 150]
        },
        SLATE: {
            name: "Minimal Slate",
            anchorFill: [80, 90, 105],
            anchorStroke: [40, 45, 55],
            handleLine: [120, 130, 145],
            handleTip: [70, 80, 95],
            outline: [60, 70, 85],
            gridline: [140, 150, 165],
            circle: [110, 120, 135],
            clearspaceBox: [80, 90, 105],
            clearspaceHatch: [160, 170, 185],
            dimension: [70, 80, 95],
            lockupAxis: [80, 90, 105],
            baseGridMajor: [100, 110, 125],
            baseGridMinor: [180, 190, 200],
            bentoFill: [245, 247, 250],
            bentoStroke: [140, 150, 165]
        },
        DARK_MODE: {
            name: "Dark Neon",
            anchorFill: [50, 255, 170],
            anchorStroke: [20, 180, 110],
            handleLine: [80, 255, 190],
            handleTip: [120, 255, 210],
            outline: [40, 220, 140],
            gridline: [60, 240, 160],
            circle: [70, 255, 180],
            clearspaceBox: [50, 255, 170],
            clearspaceHatch: [40, 200, 130],
            dimension: [60, 255, 180],
            lockupAxis: [50, 255, 170],
            baseGridMajor: [60, 230, 150],
            baseGridMinor: [30, 140, 90],
            bentoFill: [20, 30, 25],
            bentoStroke: [50, 255, 170]
        }
    },

    // Default configuration object
    DEFAULTS: {
        themeKey: "CYAN",
        
        // Construction Tab
        enableAnchors: true,
        anchorStyle: "Circle",
        anchorSize: 4.5,
        enableHandles: true,
        handleStrokeWidth: 0.4,
        enableOutlines: true,
        outlineWidth: 0.5,
        enableGridlines: true,
        gridlineSensitivity: 1, // 0 = low, 1 = med, 2 = all
        enableCircles: true,
        circleTolerance: 0.08,
        overflowPadding: 80,

        // Clearspace Tab
        unitMode: "Logomark", // "Logomark", "Height", "Width", "Custom"
        multiplier: 1.0,
        customXPt: 40,
        enableHatching: true,
        enableDimensionLines: true,
        enableXBadges: true,

        // Lockup Tab
        enableLockupAxes: true,
        enableBaselineCap: true,
        enableGapBracket: true,

        // Base Grid Tab
        baseGridType: "Square", // "Square", "Isometric", "Hexagon", "Golden", "Polar"
        gridCellSize: 20,
        gridSubdivisions: 4,
        goldenScale: 100,
        polarRings: 6,
        polarSpokes: 12,

        // Bento Tab
        bentoLayout: "simple", // "simple", "brick", "centered"
        bentoSections: 6,
        bentoGutter: 12,
        bentoCornerRadius: 8,
        bentoRandomWidths: false
    }
};
