/**
 * LogoGridStudio Pro - Base Grid & Foundation Engine
 * Generates Modular Square, Isometric 30/60, Hexagonal, Golden Ratio, and Polar Radial grids
 */

var BaseGridEngine = {
    generate: function(doc, config, theme) {
        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.BASE_GRID);
        LayerManager.clearLayer(moduleLayer);

        var bounds;
        if (doc.selection && doc.selection.length > 0) {
            bounds = GeometryUtils.getSelectionBounds(doc.selection);
            var pad = 60.0;
            bounds = [bounds[0] + pad, bounds[1] - pad, bounds[2] - pad, bounds[3] + pad];
        } else {
            bounds = GeometryUtils.getArtboardBounds(doc);
        }

        var gridType = config.baseGridType || "Square";

        if (gridType === "Square") {
            this.drawSquareGrid(moduleLayer, bounds, config.gridCellSize || 20, config.gridSubdivisions || 4, theme);
        } else if (gridType === "Isometric") {
            this.drawIsometricGrid(moduleLayer, bounds, config.gridCellSize || 30, theme);
        } else if (gridType === "Hexagon") {
            this.drawHexagonGrid(moduleLayer, bounds, config.gridCellSize || 25, theme);
        } else if (gridType === "Golden") {
            this.drawGoldenRatioGrid(moduleLayer, bounds, config.goldenScale || 120, theme);
        } else if (gridType === "Polar") {
            this.drawPolarGrid(moduleLayer, bounds, config.polarRings || 6, config.polarSpokes || 12, theme);
        }
    },

    drawSquareGrid: function(layer, bounds, cellSize, subdivs, theme) {
        var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
        var width = right - left, height = top - bottom;
        var subSize = cellSize / (subdivs || 4);

        var subMajor = LayerManager.getOrCreateSublayer(layer, "Major_Grid");
        var subMinor = LayerManager.getOrCreateSublayer(layer, "Minor_Grid");

        // Minor grid lines
        for (var x = left; x <= right; x += subSize) {
            var isMajor = (Math.abs((x - left) % cellSize) < 1.0 || Math.abs((x - left) % cellSize - cellSize) < 1.0);
            var targetLayer = isMajor ? subMajor : subMinor;
            var vl = targetLayer.pathItems.add();
            vl.setEntirePath([[x, top], [x, bottom]]);
            vl.stroked = true; vl.filled = false;
            vl.strokeWidth = isMajor ? 0.45 : 0.2;
            vl.strokeColor = isMajor ? theme.baseGridMajor : theme.baseGridMinor;
        }

        for (var y = bottom; y <= top; y += subSize) {
            var isMajorY = (Math.abs((y - bottom) % cellSize) < 1.0 || Math.abs((y - bottom) % cellSize - cellSize) < 1.0);
            var targetLayerY = isMajorY ? subMajor : subMinor;
            var hl = targetLayerY.pathItems.add();
            hl.setEntirePath([[left, y], [right, y]]);
            hl.stroked = true; hl.filled = false;
            hl.strokeWidth = isMajorY ? 0.45 : 0.2;
            hl.strokeColor = isMajorY ? theme.baseGridMajor : theme.baseGridMinor;
        }
    },

    drawIsometricGrid: function(layer, bounds, cellSize, theme) {
        var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
        var width = right - left, height = top - bottom;
        var isoGroup = layer.groupItems.add();

        // 1. Vertical lines
        for (var vx = left; vx <= right; vx += cellSize) {
            var v = isoGroup.pathItems.add();
            v.setEntirePath([[vx, top], [vx, bottom]]);
            v.stroked = true; v.filled = false; v.strokeWidth = 0.3; v.strokeColor = theme.baseGridMajor;
        }

        // 2. 30-degree and -30-degree diagonals (tan(30) = 1 / sqrt(3) ~= 0.57735)
        var tan30 = 0.577350269;
        var diagStep = cellSize / (tan30 * 2.0);

        for (var d = left - height * 2; d <= right + height * 2; d += diagStep) {
            // Diagonal / (30 deg)
            var p1 = [d, bottom];
            var p2 = [d + height / tan30, top];
            var dLine1 = isoGroup.pathItems.add();
            dLine1.setEntirePath([p1, p2]);
            dLine1.stroked = true; dLine1.filled = false; dLine1.strokeWidth = 0.3; dLine1.strokeColor = theme.baseGridMajor;

            // Diagonal \ (-30 deg)
            var p3 = [d, top];
            var p4 = [d + height / tan30, bottom];
            var dLine2 = isoGroup.pathItems.add();
            dLine2.setEntirePath([p3, p4]);
            dLine2.stroked = true; dLine2.filled = false; dLine2.strokeWidth = 0.3; dLine2.strokeColor = theme.baseGridMajor;
        }
    },

    drawHexagonGrid: function(layer, bounds, hexRadius, theme) {
        var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
        var r = hexRadius || 25.0;
        var w = Math.sqrt(3) * r;
        var h = 1.5 * r;
        var hexGroup = layer.groupItems.add();

        var row = 0;
        for (var y = top; y >= bottom - r; y -= h) {
            var xOffset = (row % 2 === 1) ? (w / 2.0) : 0.0;
            for (var x = left + xOffset; x <= right + w; x += w) {
                var hex = hexGroup.pathItems.add();
                var pts = [];
                for (var a = 0; a < 6; a++) {
                    var angleRad = (Math.PI / 180.0) * (60.0 * a + 30.0);
                    pts.push([x + r * Math.cos(angleRad), y + r * Math.sin(angleRad)]);
                }
                hex.setEntirePath(pts);
                hex.closed = true;
                hex.stroked = true; hex.filled = false; hex.strokeWidth = 0.35; hex.strokeColor = theme.baseGridMajor;
            }
            row++;
        }
    },

    drawGoldenRatioGrid: function(layer, bounds, baseScale, theme) {
        var phi = 1.6180339887;
        var centerX = (bounds[1] + bounds[3]) / 2.0;
        var centerY = (bounds[0] + bounds[2]) / 2.0;
        var s = baseScale || 100.0;

        var subCircles = LayerManager.getOrCreateSublayer(layer, "Golden_Circles");
        var subRects = LayerManager.getOrCreateSublayer(layer, "Golden_Rectangles");

        // 1. Concentric Golden Ratio Circles
        var radii = [s / (phi * phi * phi), s / (phi * phi), s / phi, s, s * phi, s * phi * phi];
        for (var i = 0; i < radii.length; i++) {
            var rad = radii[i];
            var c = subCircles.pathItems.ellipse(centerY + rad, centerX - rad, rad * 2.0, rad * 2.0);
            c.filled = false; c.stroked = true; c.strokeWidth = 0.4; c.strokeColor = theme.circle;
            c.strokeDashes = [4, 4];
        }

        // 2. Golden Rectangles Matrix
        var rectW = s * phi;
        var rectH = s;
        var gRect = subRects.pathItems.rectangle(centerY + rectH / 2.0, centerX - rectW / 2.0, rectW, rectH);
        gRect.filled = false; gRect.stroked = true; gRect.strokeWidth = 0.5; gRect.strokeColor = theme.baseGridMajor;
    },

    drawPolarGrid: function(layer, bounds, ringCount, spokeCount, theme) {
        var centerX = (bounds[1] + bounds[3]) / 2.0;
        var centerY = (bounds[0] + bounds[2]) / 2.0;
        var maxR = Math.min(bounds[3] - bounds[1], bounds[0] - bounds[2]) / 2.0;
        var ringStep = maxR / (ringCount || 6);

        var polarGroup = layer.groupItems.add();

        // 1. Concentric Rings
        for (var r = ringStep; r <= maxR; r += ringStep) {
            var ring = polarGroup.pathItems.ellipse(centerY + r, centerX - r, r * 2.0, r * 2.0);
            ring.filled = false; ring.stroked = true; ring.strokeWidth = 0.35; ring.strokeColor = theme.baseGridMajor;
        }

        // 2. Radial Spokes
        var spokes = spokeCount || 12;
        for (var s = 0; s < spokes; s++) {
            var angleRad = (Math.PI * 2.0 / spokes) * s;
            var endX = centerX + maxR * Math.cos(angleRad);
            var endY = centerY + maxR * Math.sin(angleRad);
            var spoke = polarGroup.pathItems.add();
            spoke.setEntirePath([[centerX, centerY], [endX, endY]]);
            spoke.stroked = true; spoke.filled = false; spoke.strokeWidth = 0.3; spoke.strokeColor = theme.baseGridMinor;
        }
    }
};
