/**
 * LogoGridStudio Pro - Bento Presentation Grid Engine
 * Algorithmic Bento matrix generation (Simple, Brick, Centered layouts across 3-12 cells)
 */

var BentoEngine = {
    generate: function(doc, config, theme) {
        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.BENTO);
        LayerManager.clearLayer(moduleLayer);

        var bounds;
        if (doc.selection && doc.selection.length > 0 && doc.selection[0].typename === "PathItem") {
            bounds = doc.selection[0].geometricBounds;
        } else {
            var abBounds = GeometryUtils.getArtboardBounds(doc);
            var pad = 60.0;
            bounds = [abBounds[0] - pad, abBounds[1] + pad, abBounds[2] + pad, abBounds[3] - pad];
        }

        var top = bounds[0], left = bounds[1];
        var totalW = bounds[3] - bounds[1];
        var totalH = bounds[0] - bounds[2];

        var layoutType = config.bentoLayout || "simple";
        var count = config.bentoSections || 6;
        var gutter = config.bentoGutter || 12;
        var radius = config.bentoCornerRadius || 8;
        var rcw = config.bentoRandomWidths || false;

        var matrix = this.computeMatrix(layoutType, count, rcw);
        if (!matrix) return;

        var cols = matrix.cols, rows = matrix.rows;
        var cellW = (totalW - gutter * (cols - 1)) / cols;
        var cellH = (totalH - gutter * (rows - 1)) / rows;

        var bentoGroup = moduleLayer.groupItems.add();

        for (var i = 0; i < matrix.cells.length; i++) {
            var cell = matrix.cells[i];
            var cCol = cell.col;
            var cRow = cell.row;
            var cColspan = cell.colspan || 1;
            var cRowspan = cell.rowspan || 1;

            var x = left + cCol * (cellW + gutter);
            var y = top - cRow * (cellH + gutter);
            var w = cellW * cColspan + gutter * (cColspan - 1);
            var h = cellH * cRowspan + gutter * (cRowspan - 1);

            var rect = bentoGroup.pathItems.roundedRectangle(y, x, w, h, radius, radius);
            rect.filled = true;
            rect.fillColor = theme.bentoFill;
            rect.stroked = true;
            rect.strokeWidth = 0.5;
            rect.strokeColor = theme.bentoStroke;
        }
    },

    computeMatrix: function(type, count, rcw) {
        if (type === "simple") {
            return this._getSimpleLayout(count, rcw);
        } else if (type === "brick") {
            return this._getBrickLayout(count, rcw);
        } else if (type === "centered") {
            return this._getCenteredLayout(count, rcw);
        }
        return this._getSimpleLayout(count, rcw);
    },

    _getSimpleLayout: function(count, rcw) {
        var rows = count > 7 ? 4 : 3;
        var cols = count > 7 ? 4 : 3;

        switch (count) {
            case 3:
                var cw3 = !rcw ? 2 : 1.5;
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: cw3, rowspan: 2 },
                        { row: 0, col: cw3, colspan: 3 - cw3, rowspan: 2 },
                        { row: 2, col: 0, colspan: 3, rowspan: 1 }
                    ]
                };
            case 4:
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: 2, rowspan: 2 },
                        { row: 0, col: 2, colspan: 1, rowspan: 1 },
                        { row: 1, col: 2, colspan: 1, rowspan: 2 },
                        { row: 2, col: 0, colspan: 2, rowspan: 1 }
                    ]
                };
            case 5:
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: 1, rowspan: 1 },
                        { row: 1, col: 0, colspan: 1, rowspan: 2 },
                        { row: 0, col: 1, colspan: 2, rowspan: 2 },
                        { row: 2, col: 1, colspan: 1, rowspan: 1 },
                        { row: 2, col: 2, colspan: 1, rowspan: 1 }
                    ]
                };
            case 6:
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: 1, rowspan: 1 },
                        { row: 1, col: 0, colspan: 1, rowspan: 1 },
                        { row: 0, col: 1, colspan: 2, rowspan: 2 },
                        { row: 2, col: 0, colspan: 1, rowspan: 1 },
                        { row: 2, col: 1, colspan: 1, rowspan: 1 },
                        { row: 2, col: 2, colspan: 1, rowspan: 1 }
                    ]
                };
            case 7:
                return {
                    cols: 3, rows: 3,
                    cells: [
                        { row: 0, col: 0, colspan: 1, rowspan: 2 },
                        { row: 0, col: 1, colspan: 1, rowspan: 1 },
                        { row: 0, col: 2, colspan: 1, rowspan: 1 },
                        { row: 1, col: 1, colspan: 2, rowspan: 1 },
                        { row: 2, col: 0, colspan: 1, rowspan: 1 },
                        { row: 2, col: 1, colspan: 1, rowspan: 1 },
                        { row: 2, col: 2, colspan: 1, rowspan: 1 }
                    ]
                };
            case 8:
                return {
                    cols: 4, rows: 4,
                    cells: [
                        { row: 0, col: 0, colspan: 2, rowspan: 2 },
                        { row: 0, col: 2, colspan: 2, rowspan: 1 },
                        { row: 1, col: 2, colspan: 1, rowspan: 1 },
                        { row: 1, col: 3, colspan: 1, rowspan: 3 },
                        { row: 2, col: 0, colspan: 1, rowspan: 2 },
                        { row: 2, col: 1, colspan: 1, rowspan: 1 },
                        { row: 2, col: 2, colspan: 1, rowspan: 1 },
                        { row: 3, col: 1, colspan: 2, rowspan: 1 }
                    ]
                };
            default:
                // Grid layout for 9 to 12
                var cells = [];
                for (var r = 0; r < rows; r++) {
                    for (var c = 0; c < cols; c++) {
                        if (cells.length < count) {
                            cells.push({ row: r, col: c, colspan: 1, rowspan: 1 });
                        }
                    }
                }
                return { cols: cols, rows: rows, cells: cells };
        }
    },

    _getBrickLayout: function(count, rcw) {
        var cols = 3, rows = 3;
        var cells = [];
        if (count === 3) {
            cells = [
                { row: 0, col: 0, colspan: 1.5, rowspan: 1.5 },
                { row: 0, col: 1.5, colspan: 1.5, rowspan: 1.5 },
                { row: 1.5, col: 0, colspan: 3, rowspan: 1.5 }
            ];
        } else if (count === 4) {
            cells = [
                { row: 0, col: 0, colspan: 1, rowspan: 1.5 },
                { row: 0, col: 1, colspan: 2, rowspan: 1.5 },
                { row: 1.5, col: 0, colspan: 2, rowspan: 1.5 },
                { row: 1.5, col: 2, colspan: 1, rowspan: 1.5 }
            ];
        } else {
            return this._getSimpleLayout(count, rcw);
        }
        return { cols: cols, rows: rows, cells: cells };
    },

    _getCenteredLayout: function(count, rcw) {
        return {
            cols: 4, rows: 4,
            cells: [
                { row: 0, col: 0, colspan: 1, rowspan: 4 },
                { row: 0, col: 1, colspan: 2, rowspan: 2 },
                { row: 0, col: 3, colspan: 1, rowspan: 4 },
                { row: 2, col: 1, colspan: 1, rowspan: 2 },
                { row: 2, col: 2, colspan: 1, rowspan: 2 }
            ]
        };
    }
};
