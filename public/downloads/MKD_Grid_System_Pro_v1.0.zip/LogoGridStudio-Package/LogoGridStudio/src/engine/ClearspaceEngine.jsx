/**
 * LogoGridStudio Pro - Clearspace & Dimension Engine
 * Calculates proportional 'X' exclusion zones, engineering dimension lines, arrowheads, and callout badges
 */

var ClearspaceEngine = {
    generate: function(doc, targetItems, config, theme) {
        if (!targetItems || targetItems.length === 0) {
            alert("Please select your logo artwork to generate clearspace.");
            return;
        }

        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.CLEARSPACE);
        LayerManager.clearLayer(moduleLayer);

        var subBox = LayerManager.getOrCreateSublayer(moduleLayer, "Exclusion_Boundary");
        var subDims = LayerManager.getOrCreateSublayer(moduleLayer, "Dimension_Lines");
        var subHatch = LayerManager.getOrCreateSublayer(moduleLayer, "Exclusion_Hatching");

        var bounds = GeometryUtils.getSelectionBounds(targetItems);
        var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
        var width = right - left, height = top - bottom;

        // 1. Calculate 'X' Unit
        var xVal = 40.0;
        var mode = config.unitMode || "Logomark";

        if (mode === "Logomark") {
            // If multiple items, try to find the icon/mark (often smaller width or square-ish)
            if (targetItems.length > 1) {
                var firstBounds = targetItems[0].geometricBounds;
                var markH = firstBounds[0] - firstBounds[2];
                var markW = firstBounds[3] - firstBounds[1];
                xVal = Math.min(markH, markW) * 0.5;
            } else {
                xVal = Math.min(width, height) * 0.25;
            }
        } else if (mode === "Height") {
            xVal = height * 0.25;
        } else if (mode === "Width") {
            xVal = width * 0.25;
        } else {
            xVal = config.customXPt || 40.0;
        }

        var multiplier = config.multiplier || 1.0;
        var margin = xVal * multiplier;

        // 2. Exclusion Boundary
        var outTop = top + margin;
        var outLeft = left - margin;
        var outWidth = width + (margin * 2.0);
        var outHeight = height + (margin * 2.0);

        var outerRect = subBox.pathItems.rectangle(outTop, outLeft, outWidth, outHeight);
        outerRect.filled = false;
        outerRect.stroked = true;
        outerRect.strokeWidth = 0.75;
        outerRect.strokeColor = theme.clearspaceBox;
        outerRect.strokeDashes = [5, 4];

        // Inner alignment bounding box
        var innerRect = subBox.pathItems.rectangle(top, left, width, height);
        innerRect.filled = false;
        innerRect.stroked = true;
        innerRect.strokeWidth = 0.35;
        innerRect.strokeColor = theme.clearspaceBox;
        innerRect.strokeDashes = [2, 2];

        // 3. Engineering Dimension Lines with Arrowheads & Badges
        if (config.enableDimensionLines !== false) {
            var label = (multiplier === 1.0) ? "X" : (multiplier + "X");

            // Top dimension
            this.drawDimensionArrow(subDims, [left, top + margin], [left, top], label, "vertical", theme);
            // Left dimension
            this.drawDimensionArrow(subDims, [left - margin, top], [left, top], label, "horizontal", theme);
            // Right dimension
            this.drawDimensionArrow(subDims, [right, top], [right + margin, top], label, "horizontal", theme);
            // Bottom dimension
            this.drawDimensionArrow(subDims, [left, bottom], [left, bottom - margin], label, "vertical", theme);
        }

        // 4. Exclusion Zone Hatching
        if (config.enableHatching) {
            this.drawExclusionHatching(subHatch, outTop, outLeft, outWidth, outHeight, margin, theme);
        }
    },

    drawDimensionArrow: function(layer, pStart, pEnd, labelText, orientation, theme) {
        var line = layer.pathItems.add();
        line.setEntirePath([pStart, pEnd]);
        line.stroked = true;
        line.filled = false;
        line.strokeWidth = 0.5;
        line.strokeColor = theme.dimension;

        // End Ticks / Arrows
        var tickLen = 4.0;
        if (orientation === "horizontal") {
            // Vertical ticks at start and end
            var t1 = layer.pathItems.add();
            t1.setEntirePath([[pStart[0], pStart[1] + tickLen], [pStart[0], pStart[1] - tickLen]]);
            t1.stroked = true; t1.strokeWidth = 0.5; t1.strokeColor = theme.dimension;

            var t2 = layer.pathItems.add();
            t2.setEntirePath([[pEnd[0], pEnd[1] + tickLen], [pEnd[0], pEnd[1] - tickLen]]);
            t2.stroked = true; t2.strokeWidth = 0.5; t2.strokeColor = theme.dimension;
        } else {
            // Horizontal ticks at start and end
            var t3 = layer.pathItems.add();
            t3.setEntirePath([[pStart[0] - tickLen, pStart[1]], [pStart[0] + tickLen, pStart[1]]]);
            t3.stroked = true; t3.strokeWidth = 0.5; t3.strokeColor = theme.dimension;

            var t4 = layer.pathItems.add();
            t4.setEntirePath([[pEnd[0] - tickLen, pEnd[1]], [pEnd[0] + tickLen, pEnd[1]]]);
            t4.stroked = true; t4.strokeWidth = 0.5; t4.strokeColor = theme.dimension;
        }

        // 'X' Typography Callout
        var midX = (pStart[0] + pEnd[0]) / 2.0;
        var midY = (pStart[1] + pEnd[1]) / 2.0;

        try {
            var tf = layer.textFrames.add();
            tf.contents = labelText;
            tf.position = [midX - 3.5, midY + 4.0];
            tf.textRange.characterAttributes.size = 8.0;
            tf.textRange.characterAttributes.fillColor = theme.dimension;
        } catch (e) {
            // Text frame fallback if font issue
        }
    },

    drawExclusionHatching: function(layer, outTop, outLeft, outWidth, outHeight, margin, theme) {
        var hGroup = layer.groupItems.add();
        var step = 14.0;

        // Top band
        for (var x = outLeft; x < outLeft + outWidth; x += step) {
            var l = hGroup.pathItems.add();
            l.setEntirePath([[x, outTop], [x + margin, outTop - margin]]);
            l.stroked = true; l.filled = false; l.strokeWidth = 0.25; l.strokeColor = theme.clearspaceHatch;
            l.opacity = 35;
        }

        // Bottom band
        var bTop = outTop - outHeight + margin;
        for (var bx = outLeft; bx < outLeft + outWidth; bx += step) {
            var lb = hGroup.pathItems.add();
            lb.setEntirePath([[bx, bTop], [bx + margin, bTop - margin]]);
            lb.stroked = true; lb.filled = false; lb.strokeWidth = 0.25; lb.strokeColor = theme.clearspaceHatch;
            lb.opacity = 35;
        }
    }
};
