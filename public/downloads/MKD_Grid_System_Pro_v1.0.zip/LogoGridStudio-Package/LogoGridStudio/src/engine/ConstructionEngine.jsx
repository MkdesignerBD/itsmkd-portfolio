/**
 * LogoGridStudio Pro - Construction Grid Engine
 * Generates Anchors, Handles, Wireframes, Tangent Extensions, and Osculating Arc Circles
 */

var ConstructionEngine = {
    generate: function(doc, targetItems, config, theme) {
        var paths = GeometryUtils.extractPaths(targetItems);
        if (paths.length === 0) {
            alert("No vector paths found in selection. Please select your logo artwork.");
            return;
        }

        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.CONSTRUCTION);
        LayerManager.clearLayer(moduleLayer);

        var subOutlines = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.OUTLINES);
        var subCircles = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.CIRCLES);
        var subGridlines = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.GRIDLINES);
        var subHandles = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.HANDLES);
        var subAnchors = LayerManager.getOrCreateSublayer(moduleLayer, LGS_CONSTANTS.SUBLAYERS.ANCHORS);

        var bounds = GeometryUtils.getSelectionBounds(targetItems);
        var pad = config.overflowPadding || 80;
        var extBounds = [bounds[0] + pad, bounds[1] - pad, bounds[2] - pad, bounds[3] + pad];

        for (var i = 0; i < paths.length; i++) {
            var path = paths[i];
            var pts = path.pathPoints;
            if (!pts || pts.length === 0) continue;

            // 1. Wireframe Outlines
            if (config.enableOutlines) {
                var clone = path.duplicate(subOutlines, ElementPlacement.PLACEATEND);
                clone.filled = false;
                clone.stroked = true;
                clone.strokeWidth = config.outlineWidth || 0.5;
                clone.strokeColor = theme.outline;
            }

            // 2. Anchors & Bézier Handles
            for (var j = 0; j < pts.length; j++) {
                var pt = pts[j];
                var anchor = pt.anchor;

                // Anchors
                if (config.enableAnchors) {
                    this.drawAnchor(subAnchors, anchor, config.anchorStyle, config.anchorSize || 4.5, theme);
                }

                // Handles
                if (config.enableHandles) {
                    var lDir = pt.leftDirection;
                    var rDir = pt.rightDirection;

                    if (Vector2D.distSq(lDir, anchor) > 1.0) {
                        this.drawHandle(subHandles, anchor, lDir, config.handleStrokeWidth || 0.4, theme);
                    }
                    if (Vector2D.distSq(rDir, anchor) > 1.0) {
                        this.drawHandle(subHandles, anchor, rDir, config.handleStrokeWidth || 0.4, theme);
                    }
                }
            }

            // 3. Circular Trajectories & Fitted Circles
            if (config.enableCircles) {
                for (var j = 0; j < pts.length; j++) {
                    var nextIdx = (j + 1) % pts.length;
                    if (!path.closed && j === pts.length - 1) break;

                    var p0 = pts[j].anchor;
                    var p1 = pts[j].rightDirection;
                    var p2 = pts[nextIdx].leftDirection;
                    var p3 = pts[nextIdx].anchor;

                    var arc = BezierMath.detectArc(p0, p1, p2, p3, config.circleTolerance || 0.08);
                    if (arc && arc.center) {
                        this.drawCircle(subCircles, arc.center, arc.radius, theme);
                    }
                }
            }

            // 4. Tangent & Extrema Extensions (Gridlines)
            if (config.enableGridlines) {
                this.drawGridlines(subGridlines, path, extBounds, config.gridlineSensitivity || 1, theme);
            }
        }
    },

    drawAnchor: function(layer, pt, style, size, theme) {
        var s = size || 4.5;
        var halfS = s / 2.0;
        var item;

        if (style === "Circle") {
            item = layer.pathItems.ellipse(pt[1] + halfS, pt[0] - halfS, s, s);
        } else if (style === "Diamond") {
            item = layer.pathItems.add();
            item.setEntirePath([
                [pt[0], pt[1] + s],
                [pt[0] + s, pt[1]],
                [pt[0], pt[1] - s],
                [pt[0] - s, pt[1]]
            ]);
            item.closed = true;
        } else if (style === "Crosshair") {
            var h = layer.pathItems.add();
            h.setEntirePath([[pt[0] - s, pt[1]], [pt[0] + s, pt[1]]]);
            h.stroked = true; h.filled = false; h.strokeWidth = 0.5; h.strokeColor = theme.anchorStroke;

            var v = layer.pathItems.add();
            v.setEntirePath([[pt[0], pt[1] - s], [pt[0], pt[1] + s]]);
            v.stroked = true; v.filled = false; v.strokeWidth = 0.5; v.strokeColor = theme.anchorStroke;
            return;
        } else { // Square
            item = layer.pathItems.rectangle(pt[1] + halfS, pt[0] - halfS, s, s);
        }

        item.filled = true;
        item.fillColor = theme.anchorFill;
        item.stroked = true;
        item.strokeWidth = 0.5;
        item.strokeColor = theme.anchorStroke;
    },

    drawHandle: function(layer, anchor, handlePt, strokeW, theme) {
        var line = layer.pathItems.add();
        line.setEntirePath([anchor, handlePt]);
        line.stroked = true;
        line.filled = false;
        line.strokeWidth = strokeW || 0.4;
        line.strokeColor = theme.handleLine;

        // Small circle at handle tip
        var tip = layer.pathItems.ellipse(handlePt[1] + 1.75, handlePt[0] - 1.75, 3.5, 3.5);
        tip.filled = true;
        tip.fillColor = theme.handleTip;
        tip.stroked = true;
        tip.strokeWidth = 0.35;
        tip.strokeColor = theme.handleLine;
    },

    drawCircle: function(layer, center, radius, theme) {
        var c = layer.pathItems.ellipse(center[1] + radius, center[0] - radius, radius * 2.0, radius * 2.0);
        c.filled = false;
        c.stroked = true;
        c.strokeWidth = 0.45;
        c.strokeColor = theme.circle;
        c.strokeDashes = [4, 3];
    },

    drawGridlines: function(layer, path, extBounds, sensitivity, theme) {
        var pts = path.pathPoints;
        var renderedY = [];
        var renderedX = [];

        for (var i = 0; i < pts.length; i++) {
            var anchor = pts[i].anchor;

            // Avoid duplicate lines if anchors share x/y
            var hasX = false, hasY = false;
            for (var k = 0; k < renderedX.length; k++) {
                if (Math.abs(renderedX[k] - anchor[0]) < 1.0) { hasX = true; break; }
            }
            for (var m = 0; m < renderedY.length; m++) {
                if (Math.abs(renderedY[m] - anchor[1]) < 1.0) { hasY = true; break; }
            }

            if (!hasY) {
                var hLine = layer.pathItems.add();
                hLine.setEntirePath([[extBounds[1], anchor[1]], [extBounds[3], anchor[1]]]);
                hLine.stroked = true; hLine.filled = false;
                hLine.strokeWidth = 0.25;
                hLine.strokeColor = theme.gridline;
                renderedY.push(anchor[1]);
            }

            if (!hasX) {
                var vLine = layer.pathItems.add();
                vLine.setEntirePath([[anchor[0], extBounds[0]], [anchor[0], extBounds[2]]]);
                vLine.stroked = true; vLine.filled = false;
                vLine.strokeWidth = 0.25;
                vLine.strokeColor = theme.gridline;
                renderedX.push(anchor[0]);
            }

            // If high sensitivity, also calculate extrema for curves
            if (sensitivity >= 2 && pts.length > 1) {
                var nextIdx = (i + 1) % pts.length;
                if (path.closed || i < pts.length - 1) {
                    var extrema = BezierMath.findExtrema(pts[i].anchor, pts[i].rightDirection, pts[nextIdx].leftDirection, pts[nextIdx].anchor);
                    for (var e = 0; e < extrema.length; e++) {
                        var ePt = extrema[e].pt;
                        if (extrema[e].type === "horizontal_tangent") {
                            var eh = layer.pathItems.add();
                            eh.setEntirePath([[extBounds[1], ePt[1]], [extBounds[3], ePt[1]]]);
                            eh.stroked = true; eh.filled = false; eh.strokeWidth = 0.25; eh.strokeColor = theme.gridline;
                        } else {
                            var ev = layer.pathItems.add();
                            ev.setEntirePath([[ePt[0], extBounds[0]], [ePt[0], extBounds[2]]]);
                            ev.stroked = true; ev.filled = false; ev.strokeWidth = 0.25; ev.strokeColor = theme.gridline;
                        }
                    }
                }
            }
        }
    }
};
