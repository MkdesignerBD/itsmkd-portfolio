/**
 * LogoGridStudio Pro - Lockup & Alignment Engine
 * Analyzes multi-element brand assets (Symbol, Wordmark, Tagline) and draws alignment axes & gap brackets
 */

var LockupEngine = {
    generate: function(doc, targetItems, config, theme) {
        if (!targetItems || targetItems.length < 2) {
            alert("Please select at least 2 elements (e.g. Logomark and Logotype) to generate lockup guides.");
            return;
        }

        var moduleLayer = LayerManager.getModuleLayer(doc, LGS_CONSTANTS.SUBLAYERS.LOCKUP);
        LayerManager.clearLayer(moduleLayer);

        var subAxes = LayerManager.getOrCreateSublayer(moduleLayer, "Alignment_Axes");
        var subBrackets = LayerManager.getOrCreateSublayer(moduleLayer, "Spacing_Brackets");
        var subBoxes = LayerManager.getOrCreateSublayer(moduleLayer, "Component_Boxes");

        // Sort items by horizontal position (left to right)
        var items = [];
        for (var k = 0; k < targetItems.length; k++) {
            items.push(targetItems[k]);
        }
        items.sort(function(a, b) {
            return a.geometricBounds[1] - b.geometricBounds[1];
        });

        var totalBounds = GeometryUtils.getSelectionBounds(items);
        var spanLeft = totalBounds[1] - 40;
        var spanRight = totalBounds[3] + 40;

        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var b = item.geometricBounds; // [top, left, bottom, right]
            var top = b[0], left = b[1], bottom = b[2], right = b[3];
            var centerY = (top + bottom) / 2.0;

            // 1. Component Bounding Box
            var box = subBoxes.pathItems.rectangle(top, left, right - left, top - bottom);
            box.filled = false;
            box.stroked = true;
            box.strokeWidth = 0.35;
            box.strokeColor = theme.lockupAxis;
            box.strokeDashes = [3, 3];

            // 2. Centerline
            if (config.enableLockupAxes !== false) {
                var cLine = subAxes.pathItems.add();
                cLine.setEntirePath([[spanLeft, centerY], [spanRight, centerY]]);
                cLine.stroked = true; cLine.filled = false; cLine.strokeWidth = 0.45;
                cLine.strokeColor = theme.lockupAxis;
                cLine.strokeDashes = [8, 3, 2, 3];
            }

            // 3. Baseline & Cap-Height guides for text / second component
            if (config.enableBaselineCap !== false) {
                // Baseline
                var baseL = subAxes.pathItems.add();
                baseL.setEntirePath([[spanLeft, bottom], [spanRight, bottom]]);
                baseL.stroked = true; baseL.filled = false; baseL.strokeWidth = 0.35;
                baseL.strokeColor = theme.lockupAxis;

                // Cap-height / Top bound
                var capL = subAxes.pathItems.add();
                capL.setEntirePath([[spanLeft, top], [spanRight, top]]);
                capL.stroked = true; capL.filled = false; capL.strokeWidth = 0.35;
                capL.strokeColor = theme.lockupAxis;
            }

            // 4. Inter-element Spacing Bracket
            if (config.enableGapBracket !== false && i < items.length - 1) {
                var nextItem = items[i + 1];
                var nextB = nextItem.geometricBounds;
                var gapStart = right;
                var gapEnd = nextB[1];

                if (gapEnd > gapStart) {
                    var midY = (top + bottom) / 2.0;
                    this.drawGapBracket(subBrackets, gapStart, gapEnd, midY, theme);
                }
            }
        }
    },

    drawGapBracket: function(layer, xStart, xEnd, y, theme) {
        var gap = Math.round(xEnd - xStart);
        var line = layer.pathItems.add();
        line.setEntirePath([[xStart, y], [xEnd, y]]);
        line.stroked = true;
        line.filled = false;
        line.strokeWidth = 0.75;
        line.strokeColor = theme.dimension;

        // End Ticks
        var tickSize = 4.0;
        var t1 = layer.pathItems.add();
        t1.setEntirePath([[xStart, y + tickSize], [xStart, y - tickSize]]);
        t1.stroked = true; t1.strokeWidth = 0.5; t1.strokeColor = theme.dimension;

        var t2 = layer.pathItems.add();
        t2.setEntirePath([[xEnd, y + tickSize], [xEnd, y - tickSize]]);
        t2.stroked = true; t2.strokeWidth = 0.5; t2.strokeColor = theme.dimension;

        // Typography Callout
        try {
            var tf = layer.textFrames.add();
            tf.contents = gap + " pt";
            tf.position = [xStart + (gap / 2.0) - 10, y + 14];
            tf.textRange.characterAttributes.size = 7.5;
            tf.textRange.characterAttributes.fillColor = theme.dimension;
        } catch (e) {}
    }
};
