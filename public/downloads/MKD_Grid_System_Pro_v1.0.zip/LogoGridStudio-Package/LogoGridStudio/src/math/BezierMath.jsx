/**
 * LogoGridStudio Pro - Bézier Calculus & Arc Fitting Engine
 * High-precision cubic Bézier evaluation, curvature radius, osculating circles, and extrema detection
 */

var BezierMath = {
    // Evaluate cubic Bézier point at parameter t in [0, 1]
    evaluate: function(p0, p1, p2, p3, t) {
        var mt = 1.0 - t;
        var mt2 = mt * mt;
        var mt3 = mt2 * mt;
        var t2 = t * t;
        var t3 = t2 * t;
        return [
            mt3 * p0[0] + 3.0 * mt2 * t * p1[0] + 3.0 * mt * t2 * p2[0] + t3 * p3[0],
            mt3 * p0[1] + 3.0 * mt2 * t * p1[1] + 3.0 * mt * t2 * p2[1] + t3 * p3[1]
        ];
    },

    // First derivative B'(t) = velocity vector
    derivative: function(p0, p1, p2, p3, t) {
        var mt = 1.0 - t;
        return [
            3.0 * mt * mt * (p1[0] - p0[0]) + 6.0 * mt * t * (p2[0] - p1[0]) + 3.0 * t * t * (p3[0] - p2[0]),
            3.0 * mt * mt * (p1[1] - p0[1]) + 6.0 * mt * t * (p2[1] - p1[1]) + 3.0 * t * t * (p3[1] - p2[1])
        ];
    },

    // Second derivative B''(t) = acceleration vector
    secondDerivative: function(p0, p1, p2, p3, t) {
        var mt = 1.0 - t;
        return [
            6.0 * mt * (p2[0] - 2.0 * p1[0] + p0[0]) + 6.0 * t * (p3[0] - 2.0 * p2[0] + p1[0]),
            6.0 * mt * (p2[1] - 2.0 * p1[1] + p0[1]) + 6.0 * t * (p3[1] - 2.0 * p2[1] + p1[1])
        ];
    },

    // Curvature kappa, radius R = 1/|kappa|, and osculating circle center
    curvature: function(p0, p1, p2, p3, t) {
        var d1 = this.derivative(p0, p1, p2, p3, t);
        var d2 = this.secondDerivative(p0, p1, p2, p3, t);
        var num = d1[0] * d2[1] - d1[1] * d2[0];
        var speedSq = d1[0] * d1[0] + d1[1] * d1[1];
        var den = Math.pow(speedSq, 1.5);

        if (den < 1e-7 || Math.abs(num) < 1e-7) {
            return { kappa: 0, radius: Infinity, center: null };
        }

        var kappa = num / den;
        var radius = 1.0 / Math.abs(kappa);
        var speed = Math.sqrt(speedSq);
        var nx = -d1[1] / speed;
        var ny = d1[0] / speed;
        var pt = this.evaluate(p0, p1, p2, p3, t);
        var sign = kappa >= 0 ? 1.0 : -1.0;

        return {
            kappa: kappa,
            radius: radius,
            center: [pt[0] + sign * nx * radius, pt[1] + sign * ny * radius]
        };
    },

    // Detect if a cubic Bézier segment is a straight line segment
    isLinear: function(p0, p1, p2, p3, tol) {
        var threshold = tol || 0.5;
        // Check distance from p1 and p2 to line (p0 -> p3)
        var dx = p3[0] - p0[0];
        var dy = p3[1] - p0[1];
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-5) return true;

        var dist1 = Math.abs((p1[1] - p0[1]) * dx - (p1[0] - p0[0]) * dy) / len;
        var dist2 = Math.abs((p2[1] - p0[1]) * dx - (p2[0] - p0[0]) * dy) / len;
        return (dist1 <= threshold && dist2 <= threshold);
    },

    // Detect if a cubic Bézier segment is a circular arc and return circumcenter and radius
    detectArc: function(p0, p1, p2, p3, tolerance) {
        if (this.isLinear(p0, p1, p2, p3, 1.0)) return null;

        var tol = tolerance || 0.08;
        // Sample curvature at t = 0.25, 0.50, 0.75
        var c1 = this.curvature(p0, p1, p2, p3, 0.25);
        var c2 = this.curvature(p0, p1, p2, p3, 0.50);
        var c3 = this.curvature(p0, p1, p2, p3, 0.75);

        if (!c1.center || !c2.center || !c3.center) return null;

        var avgR = (c1.radius + c2.radius + c3.radius) / 3.0;
        if (avgR < 8.0 || avgR > 3000.0) return null; // Reject tiny noise and near-flat curves

        // Compute radius variance
        var maxDev = Math.max(
            Math.abs(c1.radius - avgR),
            Math.abs(c2.radius - avgR),
            Math.abs(c3.radius - avgR)
        ) / avgR;

        // Compute center point consistency
        var avgCenterX = (c1.center[0] + c2.center[0] + c3.center[0]) / 3.0;
        var avgCenterY = (c1.center[1] + c2.center[1] + c3.center[1]) / 3.0;
        var centerDev = Math.max(
            Vector2D.dist(c1.center, [avgCenterX, avgCenterY]),
            Vector2D.dist(c2.center, [avgCenterX, avgCenterY]),
            Vector2D.dist(c3.center, [avgCenterX, avgCenterY])
        ) / avgR;

        if (maxDev <= tol && centerDev <= tol * 1.5) {
            return {
                center: [avgCenterX, avgCenterY],
                radius: avgR,
                isFullCircleApprox: (Vector2D.dist(p0, p3) < avgR * 0.2)
            };
        }

        return null;
    },

    // Solve quadratic equation: a*t^2 + b*t + c = 0
    solveQuadratic: function(a, b, c) {
        var roots = [];
        if (Math.abs(a) < 1e-7) {
            if (Math.abs(b) >= 1e-7) {
                var t = -c / b;
                if (t >= 0.0 && t <= 1.0) roots.push(t);
            }
            return roots;
        }

        var disc = b * b - 4.0 * a * c;
        if (disc >= 0) {
            var sqrtD = Math.sqrt(disc);
            var t1 = (-b + sqrtD) / (2.0 * a);
            var t2 = (-b - sqrtD) / (2.0 * a);
            if (t1 >= 0.0 && t1 <= 1.0) roots.push(t1);
            if (t2 >= 0.0 && t2 <= 1.0 && Math.abs(t2 - t1) > 1e-4) roots.push(t2);
        }
        return roots;
    },

    // Find horizontal and vertical extrema parameters t in [0, 1]
    findExtrema: function(p0, p1, p2, p3) {
        // x'(t) = 3*(1-t)^2*(p1.x - p0.x) + 6*(1-t)*t*(p2.x - p1.x) + 3*t^2*(p3.x - p2.x) = 0
        // a = 3*(p3.x - 3*p2.x + 3*p1.x - p0.x)
        // b = 6*(p2.x - 2*p1.x + p0.x)
        // c = 3*(p1.x - p0.x)
        var ax = 3.0 * (p3[0] - 3.0 * p2[0] + 3.0 * p1[0] - p0[0]);
        var bx = 6.0 * (p2[0] - 2.0 * p1[0] + p0[0]);
        var cx = 3.0 * (p1[0] - p0[0]);
        var xRoots = this.solveQuadratic(ax, bx, cx);

        var ay = 3.0 * (p3[1] - 3.0 * p2[1] + 3.0 * p1[1] - p0[1]);
        var by = 6.0 * (p2[1] - 2.0 * p1[1] + p0[1]);
        var cy = 3.0 * (p1[1] - p0[1]);
        var yRoots = this.solveQuadratic(ay, by, cy);

        var extrema = [];
        for (var i = 0; i < xRoots.length; i++) {
            var t = xRoots[i];
            extrema.push({ t: t, pt: this.evaluate(p0, p1, p2, p3, t), type: "vertical_tangent" });
        }
        for (var j = 0; j < yRoots.length; j++) {
            var tY = yRoots[j];
            extrema.push({ t: tY, pt: this.evaluate(p0, p1, p2, p3, tY), type: "horizontal_tangent" });
        }

        return extrema;
    }
};
