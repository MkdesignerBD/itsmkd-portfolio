/**
 * LogoGridStudio Pro - Geometry & Illustrator Object Traversal
 * Recursive path unpacking, bounds aggregation, and vector utilities
 */

var GeometryUtils = {
    // Recursively extract all PathItems from selection / items
    extractPaths: function(items) {
        var paths = [];
        if (!items || items.length === 0) return paths;

        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            this._collectPaths(item, paths);
        }
        return paths;
    },

    _collectPaths: function(item, paths) {
        if (!item) return;

        if (item.typename === "PathItem") {
            paths.push(item);
        } else if (item.typename === "CompoundPathItem") {
            for (var j = 0; j < item.pathItems.length; j++) {
                paths.push(item.pathItems[j]);
            }
        } else if (item.typename === "GroupItem") {
            for (var k = 0; k < item.pageItems.length; k++) {
                this._collectPaths(item.pageItems[k], paths);
            }
        }
    },

    // Aggregate geometric bounds [top, left, bottom, right] for an array of items
    getSelectionBounds: function(items) {
        if (!items || items.length === 0) return [0, 0, 0, 0];

        var top = -Infinity;
        var left = Infinity;
        var bottom = Infinity;
        var right = -Infinity;

        for (var i = 0; i < items.length; i++) {
            var b = items[i].geometricBounds; // [top, left, bottom, right]
            if (b[0] > top) top = b[0];
            if (b[1] < left) left = b[1];
            if (b[2] < bottom) bottom = b[2];
            if (b[3] > right) right = b[3];
        }

        return [top, left, bottom, right];
    },

    // Get active artboard bounds [top, left, bottom, right]
    getArtboardBounds: function(doc) {
        var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
        var r = ab.artboardRect; // [left, top, right, bottom]
        return [r[1], r[0], r[3], r[2]]; // Return [top, left, bottom, right]
    },

    // Check if point is inside bounding box
    isPointInBox: function(pt, box) {
        var top = box[0], left = box[1], bottom = box[2], right = box[3];
        return (pt[0] >= left && pt[0] <= right && pt[1] <= top && pt[1] >= bottom);
    }
};
