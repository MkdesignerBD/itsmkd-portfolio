/**
 * LogoGridStudio Pro - Vector2D Math Engine
 * High-performance 2D vector and linear geometry utilities
 */

var Vector2D = {
    create: function(x, y) {
        return [x, y];
    },

    add: function(v1, v2) {
        return [v1[0] + v2[0], v1[1] + v2[1]];
    },

    sub: function(v1, v2) {
        return [v1[0] - v2[0], v1[1] - v2[1]];
    },

    scale: function(v, s) {
        return [v[0] * s, v[1] * s];
    },

    length: function(v) {
        return Math.sqrt(v[0] * v[0] + v[1] * v[1]);
    },

    lengthSq: function(v) {
        return v[0] * v[0] + v[1] * v[1];
    },

    dist: function(v1, v2) {
        var dx = v1[0] - v2[0];
        var dy = v1[1] - v2[1];
        return Math.sqrt(dx * dx + dy * dy);
    },

    distSq: function(v1, v2) {
        var dx = v1[0] - v2[0];
        var dy = v1[1] - v2[1];
        return dx * dx + dy * dy;
    },

    normalize: function(v) {
        var len = Math.sqrt(v[0] * v[0] + v[1] * v[1]);
        if (len === 0) return [0, 0];
        return [v[0] / len, v[1] / len];
    },

    dot: function(v1, v2) {
        return v1[0] * v2[0] + v1[1] * v2[1];
    },

    cross: function(v1, v2) {
        return v1[0] * v2[1] - v1[1] * v2[0];
    },

    lerp: function(v1, v2, t) {
        return [v1[0] + (v2[0] - v1[0]) * t, v1[1] + (v2[1] - v1[1]) * t];
    },

    rotate: function(v, angleRad) {
        var cosA = Math.cos(angleRad);
        var sinA = Math.sin(angleRad);
        return [v[0] * cosA - v[1] * sinA, v[0] * sinA + v[1] * cosA];
    },

    rotateAround: function(pt, center, angleRad) {
        var translated = [pt[0] - center[0], pt[1] - center[1]];
        var rotated = this.rotate(translated, angleRad);
        return [rotated[0] + center[0], rotated[1] + center[1]];
    },

    perp: function(v) {
        return [-v[1], v[0]];
    },

    // Raycast intersection of infinite line through (p1, p2) with bounding box [top, left, bottom, right]
    lineBoxIntersection: function(p1, p2, box) {
        var top = box[0], left = box[1], bottom = box[2], right = box[3];
        var dx = p2[0] - p1[0];
        var dy = p2[1] - p1[1];
        var hits = [];

        // Vertical line
        if (Math.abs(dx) < 1e-7) {
            if (p1[0] >= left && p1[0] <= right) {
                return [[p1[0], top], [p1[0], bottom]];
            }
            return null;
        }

        // Horizontal line
        if (Math.abs(dy) < 1e-7) {
            if (p1[1] <= top && p1[1] >= bottom) {
                return [[left, p1[1]], [right, p1[1]]];
            }
            return null;
        }

        // Check intersection with all 4 boundaries: y = top, y = bottom, x = left, x = right
        // 1. y = top
        var xTop = p1[0] + (top - p1[1]) * (dx / dy);
        if (xTop >= left && xTop <= right) hits.push([xTop, top]);

        // 2. y = bottom
        var xBot = p1[0] + (bottom - p1[1]) * (dx / dy);
        if (xBot >= left && xBot <= right) hits.push([xBot, bottom]);

        // 3. x = left
        var yLeft = p1[1] + (left - p1[0]) * (dy / dx);
        if (yLeft <= top && yLeft >= bottom) hits.push([left, yLeft]);

        // 4. x = right
        var yRight = p1[1] + (right - p1[0]) * (dy / dx);
        if (yRight <= top && yRight >= bottom) hits.push([right, yRight]);

        // Deduplicate close points
        var uniqueHits = [];
        for (var i = 0; i < hits.length; i++) {
            var isDup = false;
            for (var j = 0; j < uniqueHits.length; j++) {
                if (this.distSq(hits[i], uniqueHits[j]) < 1.0) {
                    isDup = true;
                    break;
                }
            }
            if (!isDup) uniqueHits.push(hits[i]);
        }

        if (uniqueHits.length >= 2) {
            return [uniqueHits[0], uniqueHits[1]];
        }
        return null;
    }
};
