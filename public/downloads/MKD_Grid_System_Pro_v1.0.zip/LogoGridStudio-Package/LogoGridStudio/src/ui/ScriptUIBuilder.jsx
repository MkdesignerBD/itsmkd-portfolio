/**
 * LogoGridStudio Pro - ScriptUI Dialog Interface
 * Clean, modern, responsive ScriptUI user interface with tabbed navigation
 */

var ScriptUIBuilder = {
    showDialog: function(doc) {
        if (!doc) {
            alert("No active document. Please open or create a document in Adobe Illustrator.");
            return;
        }

        var config = {};
        for (var key in LGS_CONSTANTS.DEFAULTS) {
            if (LGS_CONSTANTS.DEFAULTS.hasOwnProperty(key)) {
                config[key] = LGS_CONSTANTS.DEFAULTS[key];
            }
        }

        var win = new Window("dialog", LGS_CONSTANTS.APP_NAME + " v" + LGS_CONSTANTS.VERSION);
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 10;
        win.margins = 16;

        // Header
        var headerGroup = win.add("group");
        headerGroup.orientation = "row";
        headerGroup.alignChildren = ["left", "center"];
        var titleText = headerGroup.add("statictext", undefined, "⚡ " + LGS_CONSTANTS.APP_NAME);
        titleText.graphics.font = ScriptUI.newFont("dialog", "bold", 15);
        var subText = headerGroup.add("statictext", undefined, "— Professional Logo & Brand Grid System");

        // Tabbed Panel
        var tpanel = win.add("tabbedpanel");
        tpanel.alignChildren = ["fill", "fill"];
        tpanel.preferredSize.width = 460;
        tpanel.preferredSize.height = 320;

        // ================= TAB 1: CONSTRUCTION =================
        var tabConst = tpanel.add("tab", undefined, "Construction");
        tabConst.alignChildren = ["fill", "top"];
        tabConst.spacing = 8;
        tabConst.margins = 12;

        var pAnchors = tabConst.add("panel", undefined, "Anchors & Handles");
        pAnchors.orientation = "row";
        pAnchors.alignChildren = ["left", "center"];
        pAnchors.spacing = 12;

        var chkAnchors = pAnchors.add("checkbox", undefined, "Anchors");
        chkAnchors.value = config.enableAnchors;
        pAnchors.add("statictext", undefined, "Style:");
        var ddAnchorStyle = pAnchors.add("dropdownlist", undefined, LGS_CONSTANTS.ANCHOR_STYLES);
        ddAnchorStyle.selection = 1; // Circle
        pAnchors.add("statictext", undefined, "Size:");
        var txtAnchorSize = pAnchors.add("edittext", undefined, config.anchorSize.toString());
        txtAnchorSize.characters = 3;

        var pHandles = tabConst.add("panel", undefined, "Bézier Handles & Outlines");
        pHandles.orientation = "row";
        pHandles.alignChildren = ["left", "center"];
        pHandles.spacing = 12;
        var chkHandles = pHandles.add("checkbox", undefined, "Handles");
        chkHandles.value = config.enableHandles;
        var chkOutlines = pHandles.add("checkbox", undefined, "Wireframe Outlines");
        chkOutlines.value = config.enableOutlines;

        var pGeo = tabConst.add("panel", undefined, "Tangents & Fitted Circles");
        pGeo.orientation = "column";
        pGeo.alignChildren = ["fill", "top"];
        pGeo.spacing = 6;

        var rowGeo1 = pGeo.add("group");
        rowGeo1.orientation = "row";
        var chkGridlines = rowGeo1.add("checkbox", undefined, "Tangent Extensions");
        chkGridlines.value = config.enableGridlines;
        rowGeo1.add("statictext", undefined, "Sensitivity:");
        var ddSensitivity = rowGeo1.add("dropdownlist", undefined, ["Low (Anchors)", "Medium", "High (Extrema)"]);
        ddSensitivity.selection = config.gridlineSensitivity;

        var rowGeo2 = pGeo.add("group");
        rowGeo2.orientation = "row";
        var chkCircles = rowGeo2.add("checkbox", undefined, "Fitted Arc Circles (R=...)");
        chkCircles.value = config.enableCircles;

        // ================= TAB 2: CLEARSPACE =================
        var tabClear = tpanel.add("tab", undefined, "Clearspace");
        tabClear.alignChildren = ["fill", "top"];
        tabClear.spacing = 8;
        tabClear.margins = 12;

        var pUnit = tabClear.add("panel", undefined, "Exclusion Zone (X Unit)");
        pUnit.orientation = "column";
        pUnit.alignChildren = ["fill", "top"];
        pUnit.spacing = 8;

        var rowUnit = pUnit.add("group");
        rowUnit.orientation = "row";
        rowUnit.add("statictext", undefined, "Unit Derivation:");
        var ddUnitMode = rowUnit.add("dropdownlist", undefined, ["Logomark Proportional", "Height Based", "Width Based", "Custom Points"]);
        ddUnitMode.selection = 0;
        rowUnit.add("statictext", undefined, "Multiplier:");
        var txtMult = rowUnit.add("edittext", undefined, "1.0");
        txtMult.characters = 3;

        var pClearOpts = tabClear.add("panel", undefined, "Annotations & Shading");
        pClearOpts.orientation = "column";
        pClearOpts.alignChildren = ["left", "top"];
        pClearOpts.spacing = 6;
        var chkDims = pClearOpts.add("checkbox", undefined, "Engineering Dimension Lines & Arrows");
        chkDims.value = config.enableDimensionLines;
        var chkHatch = pClearOpts.add("checkbox", undefined, "Subtle Exclusion Zone Hatching");
        chkHatch.value = config.enableHatching;

        // ================= TAB 3: LOCKUP =================
        var tabLockup = tpanel.add("tab", undefined, "Lockup & Align");
        tabLockup.alignChildren = ["fill", "top"];
        tabLockup.spacing = 8;
        tabLockup.margins = 12;

        var pLockup = tabLockup.add("panel", undefined, "Multi-Element Alignment Axes");
        pLockup.orientation = "column";
        pLockup.alignChildren = ["left", "top"];
        pLockup.spacing = 8;
        var chkLockupAxes = pLockup.add("checkbox", undefined, "Centerline Optical Axes");
        chkLockupAxes.value = config.enableLockupAxes;
        var chkBaseCap = pLockup.add("checkbox", undefined, "Baseline & Cap-Height Boundaries");
        chkBaseCap.value = config.enableBaselineCap;
        var chkGap = pLockup.add("checkbox", undefined, "Inter-Element Spacing Gap Brackets");
        chkGap.value = config.enableGapBracket;

        // ================= TAB 4: BASE GRIDS =================
        var tabBase = tpanel.add("tab", undefined, "Base Grids");
        tabBase.alignChildren = ["fill", "top"];
        tabBase.spacing = 8;
        tabBase.margins = 12;

        var pBaseType = tabBase.add("panel", undefined, "Foundation Grid Matrix");
        pBaseType.orientation = "column";
        pBaseType.alignChildren = ["fill", "top"];
        pBaseType.spacing = 8;

        var rowBase1 = pBaseType.add("group");
        rowBase1.orientation = "row";
        rowBase1.add("statictext", undefined, "Grid Type:");
        var ddBaseGrid = rowBase1.add("dropdownlist", undefined, ["Square (Modular)", "Isometric (30°/60°)", "Hexagon", "Golden Ratio (Phi)", "Polar Radial"]);
        ddBaseGrid.selection = 0;

        var rowBase2 = pBaseType.add("group");
        rowBase2.orientation = "row";
        rowBase2.add("statictext", undefined, "Cell / Scale Size:");
        var txtGridSize = rowBase2.add("edittext", undefined, config.gridCellSize.toString());
        txtGridSize.characters = 4;
        rowBase2.add("statictext", undefined, "Subdivisions / Spokes:");
        var txtSubdivs = rowBase2.add("edittext", undefined, config.gridSubdivisions.toString());
        txtSubdivs.characters = 3;

        // ================= TAB 5: BENTO =================
        var tabBento = tpanel.add("tab", undefined, "Bento Layout");
        tabBento.alignChildren = ["fill", "top"];
        tabBento.spacing = 8;
        tabBento.margins = 12;

        var pBento = tabBento.add("panel", undefined, "Presentation Bento Matrix");
        pBento.orientation = "column";
        pBento.alignChildren = ["fill", "top"];
        pBento.spacing = 8;

        var rowB1 = pBento.add("group");
        rowB1.orientation = "row";
        rowB1.add("statictext", undefined, "Layout Style:");
        var ddBentoLayout = rowB1.add("dropdownlist", undefined, ["Simple", "Brick", "Centered"]);
        ddBentoLayout.selection = 0;
        rowB1.add("statictext", undefined, "Sections (3-12):");
        var txtBentoCount = rowB1.add("edittext", undefined, "6");
        txtBentoCount.characters = 2;

        var rowB2 = pBento.add("group");
        rowB2.orientation = "row";
        rowB2.add("statictext", undefined, "Gutter (pt):");
        var txtBentoGutter = rowB2.add("edittext", undefined, "12");
        txtBentoGutter.characters = 3;
        rowB2.add("statictext", undefined, "Corner Radius (pt):");
        var txtBentoRadius = rowB2.add("edittext", undefined, "8");
        txtBentoRadius.characters = 3;

        // ================= TAB 6: THEMES & SETTINGS =================
        var tabSettings = tpanel.add("tab", undefined, "Themes");
        tabSettings.alignChildren = ["fill", "top"];
        tabSettings.spacing = 8;
        tabSettings.margins = 12;

        var pTheme = tabSettings.add("panel", undefined, "Visual Palette & Stroke Presets");
        pTheme.orientation = "column";
        pTheme.alignChildren = ["fill", "top"];
        pTheme.spacing = 8;

        var rowT1 = pTheme.add("group");
        rowT1.orientation = "row";
        rowT1.add("statictext", undefined, "Color Profile:");
        var ddTheme = rowT1.add("dropdownlist", undefined, ["Blueprint Cyan", "Tech Magenta", "Minimal Slate", "Dark Neon"]);
        ddTheme.selection = 0;

        var rowT2 = pTheme.add("group");
        rowT2.orientation = "row";
        rowT2.add("statictext", undefined, "Artboard Overflow Padding (pt):");
        var txtPadding = rowT2.add("edittext", undefined, config.overflowPadding.toString());
        txtPadding.characters = 4;

        tpanel.selection = 0; // Default active tab

        // Action Buttons
        var btnGroup = win.add("group");
        btnGroup.orientation = "row";
        btnGroup.alignment = ["fill", "bottom"];
        btnGroup.alignChildren = ["fill", "center"];

        var btnClear = btnGroup.add("button", undefined, "Clear Grids");
        var btnGenTab = btnGroup.add("button", undefined, "Generate Active Tab", { name: "ok" });
        var btnGenAll = btnGroup.add("button", undefined, "✨ Generate All");
        var btnClose = btnGroup.add("button", undefined, "Close", { name: "cancel" });

        // Helper to collect live config
        function readConfig() {
            config.enableAnchors = chkAnchors.value;
            config.anchorStyle = ddAnchorStyle.selection ? ddAnchorStyle.selection.text : "Circle";
            config.anchorSize = parseFloat(txtAnchorSize.text) || 4.5;
            config.enableHandles = chkHandles.value;
            config.enableOutlines = chkOutlines.value;
            config.enableGridlines = chkGridlines.value;
            config.gridlineSensitivity = ddSensitivity.selection ? ddSensitivity.selection.index : 1;
            config.enableCircles = chkCircles.value;

            var uMap = ["Logomark", "Height", "Width", "Custom"];
            config.unitMode = uMap[ddUnitMode.selection ? ddUnitMode.selection.index : 0];
            config.multiplier = parseFloat(txtMult.text) || 1.0;
            config.enableDimensionLines = chkDims.value;
            config.enableHatching = chkHatch.value;

            config.enableLockupAxes = chkLockupAxes.value;
            config.enableBaselineCap = chkBaseCap.value;
            config.enableGapBracket = chkGap.value;

            var bMap = ["Square", "Isometric", "Hexagon", "Golden", "Polar"];
            config.baseGridType = bMap[ddBaseGrid.selection ? ddBaseGrid.selection.index : 0];
            config.gridCellSize = parseFloat(txtGridSize.text) || 20;
            config.gridSubdivisions = parseInt(txtSubdivs.text, 10) || 4;

            var blMap = ["simple", "brick", "centered"];
            config.bentoLayout = blMap[ddBentoLayout.selection ? ddBentoLayout.selection.index : 0];
            config.bentoSections = parseInt(txtBentoCount.text, 10) || 6;
            config.bentoGutter = parseFloat(txtBentoGutter.text) || 12;
            config.bentoCornerRadius = parseFloat(txtBentoRadius.text) || 8;

            var tKeys = ["CYAN", "MAGENTA", "SLATE", "DARK_MODE"];
            config.themeKey = tKeys[ddTheme.selection ? ddTheme.selection.index : 0];
            config.overflowPadding = parseFloat(txtPadding.text) || 80;

            return config;
        }

        // Button Handlers
        btnClear.onClick = function() {
            var root = doc.layers;
            try {
                var l = root.getByName(LGS_CONSTANTS.ROOT_LAYER_NAME);
                l.remove();
                app.redraw();
            } catch (e) {
                alert("No existing Logo Grid System found to clear.");
            }
        };

        btnGenTab.onClick = function() {
            var cfg = readConfig();
            var theme = ThemeManager.getResolvedTheme(doc, cfg.themeKey);
            var activeTabIndex = tpanel.selection ? tpanel.selection.index : 0;
            var sel = doc.selection;

            if (activeTabIndex === 0) { // Construction
                ConstructionEngine.generate(doc, sel, cfg, theme);
            } else if (activeTabIndex === 1) { // Clearspace
                ClearspaceEngine.generate(doc, sel, cfg, theme);
            } else if (activeTabIndex === 2) { // Lockup
                LockupEngine.generate(doc, sel, cfg, theme);
            } else if (activeTabIndex === 3) { // Base Grid
                BaseGridEngine.generate(doc, cfg, theme);
            } else if (activeTabIndex === 4) { // Bento
                BentoEngine.generate(doc, cfg, theme);
            } else if (activeTabIndex === 5) { // Themes / All
                ConstructionEngine.generate(doc, sel, cfg, theme);
            }

            app.redraw();
        };

        btnGenAll.onClick = function() {
            var cfg = readConfig();
            var theme = ThemeManager.getResolvedTheme(doc, cfg.themeKey);
            var sel = doc.selection;

            if (sel && sel.length > 0) {
                ConstructionEngine.generate(doc, sel, cfg, theme);
                ClearspaceEngine.generate(doc, sel, cfg, theme);
                if (sel.length >= 2) {
                    LockupEngine.generate(doc, sel, cfg, theme);
                }
            }
            BaseGridEngine.generate(doc, cfg, theme);
            app.redraw();
        };

        win.center();
        win.show();
    }
};
