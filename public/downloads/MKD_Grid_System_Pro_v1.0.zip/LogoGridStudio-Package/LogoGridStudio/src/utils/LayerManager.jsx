/**
 * LogoGridStudio Pro - Layer Management & Non-Destructive Hierarchy
 * Creates and organizes the dedicated _LOGO_GRID_SYSTEM layer stack
 */

var LayerManager = {
    // Get or create the master root layer
    getRootLayer: function(doc) {
        var rootName = LGS_CONSTANTS.ROOT_LAYER_NAME;
        var layer;
        try {
            layer = doc.layers.getByName(rootName);
            layer.visible = true;
            layer.locked = false;
        } catch (e) {
            layer = doc.layers.add();
            layer.name = rootName;
            layer.zOrder(ZOrderMethod.BRINGTOFRONT);
        }
        return layer;
    },

    // Get or create a specific module layer (e.g. _Construction_Grid) under the root layer
    getModuleLayer: function(doc, moduleName) {
        var root = this.getRootLayer(doc);
        var sub;
        try {
            sub = root.layers.getByName(moduleName);
            sub.visible = true;
            sub.locked = false;
        } catch (e) {
            sub = root.layers.add();
            sub.name = moduleName;
        }
        return sub;
    },

    // Get or create sub-sublayer (e.g. _Anchors inside _Construction_Grid)
    getOrCreateSublayer: function(parentLayer, subName) {
        var sub;
        try {
            sub = parentLayer.layers.getByName(subName);
            sub.visible = true;
            sub.locked = false;
        } catch (e) {
            sub = parentLayer.layers.add();
            sub.name = subName;
        }
        return sub;
    },

    // Clear contents of a module layer before regenerating
    clearLayer: function(layer) {
        if (!layer) return;
        for (var i = layer.pageItems.length - 1; i >= 0; i--) {
            layer.pageItems[i].remove();
        }
        for (var j = layer.layers.length - 1; j >= 0; j--) {
            layer.layers[j].remove();
        }
    }
};
