/**
 * LogoGridStudio Pro - Theme & Color Engine
 * Converts RGB themes to native Illustrator RGB/CMYK color objects
 */

var ThemeManager = {
    // Convert [r, g, b] (0-255) to Illustrator Color object
    makeColor: function(doc, rgbArr) {
        var r = rgbArr[0], g = rgbArr[1], b = rgbArr[2];
        if (doc && doc.documentColorSpace === DocumentColorSpace.CMYK) {
            var cmyk = new CMYKColor();
            // Standard RGB to CMYK formula
            var rNorm = r / 255.0, gNorm = g / 255.0, bNorm = b / 255.0;
            var k = 1.0 - Math.max(rNorm, Math.max(gNorm, bNorm));
            if (k < 1.0) {
                cmyk.cyan = Math.round(((1.0 - rNorm - k) / (1.0 - k)) * 100);
                cmyk.magenta = Math.round(((1.0 - gNorm - k) / (1.0 - k)) * 100);
                cmyk.yellow = Math.round(((1.0 - bNorm - k) / (1.0 - k)) * 100);
                cmyk.black = Math.round(k * 100);
            } else {
                cmyk.cyan = 0; cmyk.magenta = 0; cmyk.yellow = 0; cmyk.black = 100;
            }
            return cmyk;
        } else {
            var rgb = new RGBColor();
            rgb.red = r;
            rgb.green = g;
            rgb.blue = b;
            return rgb;
        }
    },

    // Get active theme with native Illustrator colors
    getResolvedTheme: function(doc, themeKey) {
        var tKey = themeKey || "CYAN";
        var rawTheme = LGS_CONSTANTS.THEMES[tKey] || LGS_CONSTANTS.THEMES.CYAN;
        var res = { name: rawTheme.name };

        for (var prop in rawTheme) {
            if (rawTheme.hasOwnProperty(prop) && prop !== "name") {
                res[prop] = this.makeColor(doc, rawTheme[prop]);
            }
        }
        return res;
    }
};
