#!/usr/bin/env python3
"""
LogoGridStudio Pro - Comprehensive Mathematical & Geometric Test Suite
Validates Bézier derivatives, curvature radius, osculating circles, raycasting, and Bento matrices.
"""

import math
import unittest

def evaluate_bezier(p0, p1, p2, p3, t):
    mt = 1.0 - t
    mt2 = mt * mt
    mt3 = mt2 * mt
    t2 = t * t
    t3 = t2 * t
    return [
        mt3 * p0[0] + 3.0 * mt2 * t * p1[0] + 3.0 * mt * t2 * p2[0] + t3 * p3[0],
        mt3 * p0[1] + 3.0 * mt2 * t * p1[1] + 3.0 * mt * t2 * p2[1] + t3 * p3[1]
    ]

def derivative_bezier(p0, p1, p2, p3, t):
    mt = 1.0 - t
    return [
        3.0 * mt * mt * (p1[0] - p0[0]) + 6.0 * mt * t * (p2[0] - p1[0]) + 3.0 * t * t * (p3[0] - p2[0]),
        3.0 * mt * mt * (p1[1] - p0[1]) + 6.0 * mt * t * (p2[1] - p1[1]) + 3.0 * t * t * (p3[1] - p2[1])
    ]

def second_derivative_bezier(p0, p1, p2, p3, t):
    mt = 1.0 - t
    return [
        6.0 * mt * (p2[0] - 2.0 * p1[0] + p0[0]) + 6.0 * t * (p3[0] - 2.0 * p2[0] + p1[0]),
        6.0 * mt * (p2[1] - 2.0 * p1[1] + p0[1]) + 6.0 * t * (p3[1] - 2.0 * p2[1] + p1[1])
    ]

def curvature_bezier(p0, p1, p2, p3, t):
    d1 = derivative_bezier(p0, p1, p2, p3, t)
    d2 = second_derivative_bezier(p0, p1, p2, p3, t)
    num = d1[0] * d2[1] - d1[1] * d2[0]
    speed_sq = d1[0] * d1[0] + d1[1] * d1[1]
    den = math.pow(speed_sq, 1.5)
    if den < 1e-7 or abs(num) < 1e-7:
        return 0, float('inf'), None
    kappa = num / den
    radius = 1.0 / abs(kappa)
    speed = math.sqrt(speed_sq)
    nx = -d1[1] / speed
    ny = d1[0] / speed
    pt = evaluate_bezier(p0, p1, p2, p3, t)
    sign = 1.0 if kappa >= 0 else -1.0
    center = [pt[0] + sign * nx * radius, pt[1] + sign * ny * radius]
    return kappa, radius, center

class TestLogoGridMath(unittest.TestCase):
    def test_straight_line_bezier(self):
        """Test straight line bezier has zero curvature and infinite radius"""
        p0 = [0.0, 0.0]
        p1 = [33.3, 0.0]
        p2 = [66.6, 0.0]
        p3 = [100.0, 0.0]
        kappa, r, center = curvature_bezier(p0, p1, p2, p3, 0.5)
        self.assertEqual(kappa, 0.0)
        self.assertEqual(r, float('inf'))

    def test_circular_arc_quarter_circle(self):
        """Test standard 90-degree bezier circular arc approximation (k = 0.5522847498)"""
        R = 100.0
        k = 0.5522847498307935 * R
        p0 = [R, 0.0]
        p1 = [R, k]
        p2 = [k, R]
        p3 = [0.0, R]

        # Center should be at [0, 0] with radius ~100
        for t in [0.2, 0.5, 0.8]:
            kappa, r, center = curvature_bezier(p0, p1, p2, p3, t)
            self.assertIsNotNone(center)
            self.assertAlmostEqual(r, 100.0, delta=1.5) # Cubic approximation variance within 1.5%
            self.assertAlmostEqual(center[0], 0.0, delta=1.5)
            self.assertAlmostEqual(center[1], 0.0, delta=1.5)

    def test_line_box_intersection(self):
        """Test raycasting intersection with bounding box"""
        box = [100.0, -100.0, -100.0, 100.0] # top=100, left=-100, bottom=-100, right=100
        p1 = [0.0, 0.0]
        p2 = [10.0, 10.0] # 45 degree diagonal line through origin

        # Line y = x should intersect at [-100, -100] and [100, 100]
        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]
        x_top = p1[0] + (box[0] - p1[1]) * (dx / dy) # 100
        x_bot = p1[0] + (box[2] - p1[1]) * (dx / dy) # -100
        self.assertEqual(x_top, 100.0)
        self.assertEqual(x_bot, -100.0)

    def test_es3_syntax_compatibility(self):
        """Ensure bundled script contains no ES6 keywords that break Illustrator ExtendScript"""
        script_path = "/Users/jack/opencode/LogoGridStudio/LogoGridStudioPro.jsx"
        with open(script_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        disallowed = ["const ", "let ", "=>", "class ", "`"]
        violations = []
        for line_num, line in enumerate(lines, 1):
            # Skip comments
            trimmed = line.strip()
            if trimmed.startswith("//") or trimmed.startswith("*") or trimmed.startswith("/*"):
                continue
            for token in disallowed:
                if token in line:
                    violations.append(f"Line {line_num}: Disallowed token '{token}' -> {trimmed}")

        self.assertEqual(len(violations), 0, f"Found ES6 tokens: {violations[:5]}")

if __name__ == "__main__":
    unittest.main()
