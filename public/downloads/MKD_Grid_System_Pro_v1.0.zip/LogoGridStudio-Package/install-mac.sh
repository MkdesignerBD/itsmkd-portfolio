#!/usr/bin/env bash
# ==============================================================================
# LogoGridStudio Pro - 1-Click macOS Installer
# Installs the CEP extension into Adobe Illustrator (CS6 to 2026+)
# ==============================================================================

echo "⚡ Installing LogoGridStudio Pro for Adobe Illustrator..."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXT_SOURCE="$SCRIPT_DIR/io.logogrid.studio"
TARGET_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"

if [ ! -d "$EXT_SOURCE" ]; then
    echo "❌ Error: Could not find io.logogrid.studio folder in $SCRIPT_DIR"
    exit 1
fi

# 1. Create CEP directory
mkdir -p "$TARGET_DIR"

# 2. Copy extension
echo "📦 Copying extension files to $TARGET_DIR/io.logogrid.studio..."
rm -rf "$TARGET_DIR/io.logogrid.studio"
cp -R "$EXT_SOURCE" "$TARGET_DIR/io.logogrid.studio"

# 3. Enable PlayerDebugMode for all Illustrator CSXS engine versions
echo "🔓 Enabling CEP PlayerDebugMode..."
defaults write com.adobe.CSXS.9 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.10 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.11 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.12 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.13 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.14 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.15 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.16 PlayerDebugMode 1 2>/dev/null

echo ""
echo "✅ Installation Complete!"
echo "🚀 Open or restart Adobe Illustrator and go to:"
echo "   Window > Extensions > LogoGridStudio Pro"
echo ""
