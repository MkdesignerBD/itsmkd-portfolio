@echo off
:: ==============================================================================
:: LogoGridStudio Pro - 1-Click Windows Installer
:: Installs the CEP extension into Adobe Illustrator (CS6 to 2026+)
:: ==============================================================================

echo ===================================================
echo   Installing LogoGridStudio Pro for Adobe Illustrator
echo ===================================================

set "EXT_SOURCE=%~dp0io.logogrid.studio"
set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions"

if not exist "%EXT_SOURCE%" (
    echo [ERROR] Could not find io.logogrid.studio folder!
    pause
    exit /b 1
)

:: 1. Create CEP directory
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

:: 2. Copy extension
echo [1/2] Copying extension files to %TARGET_DIR%\io.logogrid.studio...
if exist "%TARGET_DIR%\io.logogrid.studio" rmdir /s /q "%TARGET_DIR%\io.logogrid.studio"
xcopy "%EXT_SOURCE%" "%TARGET_DIR%\io.logogrid.studio\" /E /I /Y >nul

:: 3. Enable PlayerDebugMode in Windows Registry
echo [2/2] Enabling CEP PlayerDebugMode in Registry...
reg add "HKCU\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.13" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.14" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.15" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.16" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1

echo.
echo ===================================================
echo   Installation Complete!
echo   Open or restart Adobe Illustrator and go to:
echo   Window ^> Extensions ^> LogoGridStudio Pro
echo ===================================================
pause
