/**
 * LogoGridStudio Pro - Frontend Controller (v3.0)
 * Exact Akrivi Gridit UI Workflow & State Management with Safe ExtendScript IPC
 */

(function () {
  "use strict";

  var csInterface = new CSInterface();

  // Active States
  var activeSubTab = "tab-base";
  var activeBaseGridType = "Square";
  var activePills = {
    Anchors: true,
    Handles: true,
    Outlines: true,
    Gridlines: true
  };

  // DOM Elements
  var subTabItems = document.querySelectorAll(".subTab-item");
  var tabContents = document.querySelectorAll(".tabContent");
  var basePills = document.querySelectorAll("#baseGridTabs .pill-item");
  var constPills = document.querySelectorAll("#constPills .multi-pill");

  var toastBar = document.getElementById("toastBar");
  var toastMsg = document.getElementById("toastMsg");
  var statusDot = document.getElementById("statusDot");
  var statusText = document.getElementById("statusText");

  // SubTab Switching
  subTabItems.forEach(function (tab) {
    tab.addEventListener("click", function () {
      var targetId = tab.getAttribute("data-tab");
      activeSubTab = targetId;

      subTabItems.forEach(function (t) { t.classList.remove("active"); });
      tabContents.forEach(function (c) { c.classList.remove("active"); });

      tab.classList.add("active");
      var targetContent = document.getElementById(targetId);
      if (targetContent) targetContent.classList.add("active");
    });
  });

  // Base Grid Type Pills
  basePills.forEach(function (pill) {
    pill.addEventListener("click", function () {
      basePills.forEach(function (p) { p.classList.remove("active"); });
      pill.classList.add("active");
      activeBaseGridType = pill.getAttribute("data-btype");

      var rowGolden = document.getElementById("rowGoldenMargin");
      if (rowGolden) {
        rowGolden.style.display = (activeBaseGridType === "GoldenRt") ? "flex" : "none";
      }
    });
  });

  // Construction Multi-Select Component Pills
  constPills.forEach(function (pill) {
    pill.addEventListener("click", function () {
      var pName = pill.getAttribute("data-pill");
      activePills[pName] = !activePills[pName];
      if (activePills[pName]) {
        pill.classList.add("active");
      } else {
        pill.classList.remove("active");
      }
    });
  });

  // Accordion Toggles
  var accordions = document.querySelectorAll(".accordion");
  accordions.forEach(function (acc) {
    var header = acc.querySelector(".acc-header");
    if (header) {
      header.addEventListener("click", function () {
        acc.classList.toggle("open");
      });
    }
  });

  // Slider Live Sync Helpers
  function bindSlider(sliderId, badgeId, unit) {
    var s = document.getElementById(sliderId);
    var b = document.getElementById(badgeId);
    if (s && b) {
      s.addEventListener("input", function () {
        b.textContent = s.value + (unit || "");
      });
    }
  }

  bindSlider("anchorsStrokeWidth", "valAnchorsStroke", "pt");
  bindSlider("anchorsSize", "valAnchorsSize", "pt");
  bindSlider("handlesStrokeWidth", "valHandlesStroke", "pt");
  bindSlider("handlesSize", "valHandlesSize", "pt");
  bindSlider("outlinesStrokeWidth", "valOutlinesStroke", "pt");
  bindSlider("gridlinesStrokeWidth", "valGridlinesStroke", "pt");
  bindSlider("circComplexity", "valCircComplexity", "");

  var gridLevel = document.getElementById("gridlinesLevel");
  var valGridLevel = document.getElementById("valGridlinesLevel");
  if (gridLevel && valGridLevel) {
    gridLevel.addEventListener("input", function () {
      var names = ["0 (Low)", "1 (Med)", "2 (High)"];
      valGridLevel.textContent = names[parseInt(gridLevel.value, 10)] || "1 (Med)";
    });
  }

  // Swap Fill / Stroke buttons
  var swapAnchors = document.getElementById("swapAnchors");
  if (swapAnchors) {
    swapAnchors.addEventListener("click", function () {
      var f = document.getElementById("anchorsFill");
      var s = document.getElementById("anchorsStrokeColor");
      if (f && s) {
        var temp = f.value; f.value = s.value; s.value = temp;
      }
    });
  }

  var swapHandles = document.getElementById("swapHandles");
  if (swapHandles) {
    swapHandles.addEventListener("click", function () {
      var f2 = document.getElementById("handlesFill");
      var s2 = document.getElementById("handlesStrokeColor");
      if (f2 && s2) {
        var temp2 = f2.value; f2.value = s2.value; s2.value = temp2;
      }
    });
  }

  // Circular Trajectory toggle
  var chkCirc = document.getElementById("chkCircularEnabled");
  var rowCircComp = document.getElementById("rowCircComplexity");
  var rowCircMode = document.getElementById("rowCircMode");
  var rowCircNum = document.getElementById("rowCircNum");
  if (chkCirc) {
    chkCirc.addEventListener("change", function () {
      var display = chkCirc.checked ? "flex" : "none";
      if (rowCircComp) rowCircComp.style.display = display;
      if (rowCircMode) rowCircMode.style.display = display;
      if (rowCircNum) rowCircNum.style.display = display;
    });
  }

  // Clearspace Unit selector
  var selClearUnit = document.getElementById("selClearUnit");
  var rowClearVal = document.getElementById("rowClearValue");
  if (selClearUnit && rowClearVal) {
    selClearUnit.addEventListener("change", function () {
      rowClearVal.style.display = (selClearUnit.value === "lg") ? "none" : "flex";
    });
  }

  // Toast Banner
  function showToast(msg, isError) {
    if (!toastBar || !toastMsg) return;
    toastMsg.textContent = msg;
    toastBar.className = "toast-bar " + (isError ? "error" : "");
    toastBar.style.display = "block";
    setTimeout(function () { toastBar.style.display = "none"; }, 4000);
  }

  // Get Colors with No-Fill check
  function getSelectedColor(inputColId, selectModeId) {
    var modeElem = document.getElementById(selectModeId);
    if (modeElem && modeElem.value === "none") return "none";
    var colElem = document.getElementById(inputColId);
    return colElem ? colElem.value : "#00d2ff";
  }

  // Build Akrivi-Matching Payload
  function getFullOptions() {
    return {
      BaseGridGenerator: {
        gridType: activeBaseGridType,
        sideLength: parseFloat(document.getElementById("baseSideLength").value) || 190.0,
        marginGolden: parseFloat(document.getElementById("baseMarginGolden").value) || 10.0
      },
      LogoGridGenerator: {
        anchors: {
          size: parseFloat(document.getElementById("anchorsSize").value) || 6.0,
          fill: getSelectedColor("anchorsFill", "anchorsFillMode"),
          stroke: {
            width: parseFloat(document.getElementById("anchorsStrokeWidth").value) || 1.0,
            color: getSelectedColor("anchorsStrokeColor", "anchorsStrokeMode")
          }
        },
        handles: {
          size: parseFloat(document.getElementById("handlesSize").value) || 5.0,
          fill: getSelectedColor("handlesFill", "handlesFillMode"),
          stroke: {
            width: parseFloat(document.getElementById("handlesStrokeWidth").value) || 0.5,
            color: getSelectedColor("handlesStrokeColor", "handlesStrokeMode")
          }
        },
        outlines: {
          fill: "none",
          stroke: {
            width: parseFloat(document.getElementById("outlinesStrokeWidth").value) || 0.5,
            color: getSelectedColor("outlinesStrokeColor", "outlinesStrokeMode")
          }
        },
        gridlines: {
          fill: "none",
          stroke: {
            width: parseFloat(document.getElementById("gridlinesStrokeWidth").value) || 0.35,
            color: getSelectedColor("gridlinesStrokeColor", "gridlinesStrokeMode")
          }
        },
        gridlines_level: parseInt(document.getElementById("gridlinesLevel").value, 10) || 1,
        circular_trajectories: {
          enabled: document.getElementById("chkCircularEnabled").checked,
          thresholdError: parseInt(document.getElementById("circComplexity").value, 10) || 0,
          NumberCirTraj: {
            option: document.getElementById("selCircOption").value,
            number: parseInt(document.getElementById("numCircLimit").value, 10) || 5
          }
        }
      },
      ClearspaceGridGenerator: {
        unitExclusionZone: document.getElementById("selClearUnit").value,
        valueExclusionZone: parseFloat(document.getElementById("numClearVal").value) || 60,
        invertComponents: document.getElementById("chkInvertComponents").checked
      }
    };
  }

  // Safe Bridge Invocation
  function callAction(actionName, payloadObj) {
    var rawJson = JSON.stringify(payloadObj || {});
    var encoded = encodeURIComponent(rawJson);
    var script = '$.global.LGS_Bridge.executeAction("' + actionName + '", "' + encoded + '")';

    csInterface.evalScript(script, function (resStr) {
      try {
        var res = JSON.parse(resStr);
        if (res.success) {
          showToast("✓ " + (res.message || "Done!"), false);
        } else {
          showToast("✗ " + (res.error || "Error"), true);
        }
      } catch (e) {
        showToast(resStr || "Processed", false);
      }
      updateStatus();
    });
  }

  // Live Selection Monitor
  function updateStatus() {
    csInterface.evalScript("$.global.LGS_Bridge.getSelectionStatus()", function (resStr) {
      try {
        var res = JSON.parse(resStr);
        if (!res.doc) {
          statusDot.className = "status-dot";
          statusText.textContent = "No document";
        } else if (res.count === 0) {
          statusDot.className = "status-dot";
          statusText.textContent = "No selection";
        } else {
          statusDot.className = "status-dot active";
          statusText.textContent = res.count + " item" + (res.count > 1 ? "s" : "") + " selected";
        }
      } catch (e) {
        statusDot.className = "status-dot";
        statusText.textContent = "Ready";
      }
    });
  }

  updateStatus();
  setInterval(updateStatus, 1500);

  // Button Handlers
  // 1. Base Grid buttons
  document.getElementById("btnGenerateBGG").addEventListener("click", function () {
    var opts = getFullOptions();
    callAction("generateBGG", { options: opts.BaseGridGenerator });
  });

  document.getElementById("btnMakeGuidesBGG").addEventListener("click", function () {
    var opts = getFullOptions();
    callAction("makeGuideBGG", { options: opts.BaseGridGenerator });
  });

  // 2. Construction buttons
  document.getElementById("btnGenerateLGG").addEventListener("click", function () {
    var opts = getFullOptions();
    callAction("generateLGG", { options: opts.LogoGridGenerator, activePills: activePills });
  });

  document.getElementById("btnGenerateAllLGG").addEventListener("click", function () {
    var opts = getFullOptions();
    callAction("generateAllLGG", { options: opts.LogoGridGenerator });
  });

  // 3. Clearspace button
  document.getElementById("btnGenerateCGG").addEventListener("click", function () {
    var opts = getFullOptions();
    callAction("generateCGG", { options: opts.ClearspaceGridGenerator });
  });

  // 4. Global Clear button
  document.getElementById("btnClearGlobal").addEventListener("click", function () {
    callAction("clearGridSystem", {});
  });

})();
