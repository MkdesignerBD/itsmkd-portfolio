/**
 * LogoGridStudio Pro - Host ExtendScript Engine (v3.0)
 * 100% Full Akrivi Gridit Parity + Lockup & Bento Engines + Native Guide Conversion
 */

#target illustrator

if (typeof $.global.LGS_Bridge === "undefined") {
    $.global.LGS_Bridge = {};
}

// Robust JSON parser/serializer
var LGS_JSON = {
    parse: function(str) {
        if (!str) return {};
        try {
            var decoded = str;
            try { decoded = decodeURIComponent(str); } catch (e) {}
            return eval("(" + decoded + ")");
        } catch (err) {
            return {};
        }
    },
    stringify: function(obj) {
        var t = typeof obj;
        if (t !== "object" || obj === null) {
            if (t === "string") return '"' + obj.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r') + '"';
            return String(obj);
        }
        var isArr = (obj instanceof Array);
        var res = [];
        for (var k in obj) {
            if (obj.hasOwnProperty(k)) {
                var v = obj[k];
                var vStr = this.stringify(v);
                if (isArr) res.push(vStr);
                else res.push('"' + k + '":' + vStr);
            }
        }
        return isArr ? ("[" + res.join(",") + "]") : ("{" + res.join(",") + "}");
    }
};

var LGS_CONSTANTS = {
    APP_NAME: "LogoGridStudio Pro",
    ROOT_LAYER_NAME: "_LOGO_GRID_SYSTEM"
};

// =================== 2D Vector Math ===================
var Vector2D = {
    dist: function(v1, v2) {
        var dx = v1[0] - v2[0], dy = v1[1] - v2[1];
        return Math.sqrt(dx * dx + dy * dy);
    },
    distSq: function(v1, v2) {
        var dx = v1[0] - v2[0], dy = v1[1] - v2[1];
        return dx * dx + dy * dy;
    }
};

// =================== Bezier Calculus ===================
var BezierMath = {
    evaluate: function(p0, p1, p2, p3, t) {
        var mt = 1.0 - t, mt2 = mt * mt, mt3 = mt2 * mt;
        var t2 = t * t, t3 = t2 * t;
        return [
            mt3 * p0[0] + 3.0 * mt2 * t * p1[0] + 3.0 * mt * t2 * p2[0] + t3 * p3[0],
            mt3 * p0[1] + 3.0 * mt2 * t * p1[1] + 3.0 * mt * t2 * p2[1] + t3 * p3[1]
        ];
    },
    derivative: function(p0, p1, p2, p3, t) {
        var mt = 1.0 - t;
        return [
            3.0 * mt * mt * (p1[0] - p0[0]) + 6.0 * mt * t * (p2[0] - p1[0]) + 3.0 * t * t * (p3[0] - p2[0]),
            3.0 * mt * mt * (p1[1] - p0[1]) + 6.0 * mt * t * (p2[1] - p1[1]) + 3.0 * t * t * (p3[1] - p2[1])
        ];
    },
    secondDerivative: function(p0, p1, p2, p3, t) {
        var mt = 1.0 - t;
        return [
            6.0 * mt * (p2[0] - 2.0 * p1[0] + p0[0]) + 6.0 * t * (p3[0] - 2.0 * p2[0] + p1[0]),
            6.0 * mt * (p2[1] - 2.0 * p1[1] + p0[1]) + 6.0 * t * (p3[1] - 2.0 * p2[1] + p1[1])
        ];
    },
    curvature: function(p0, p1, p2, p3, t) {
        var d1 = this.derivative(p0, p1, p2, p3, t);
        var d2 = this.secondDerivative(p0, p1, p2, p3, t);
        var num = d1[0] * d2[1] - d1[1] * d2[0];
        var speedSq = d1[0] * d1[0] + d1[1] * d1[1];
        var den = Math.pow(speedSq, 1.5);
        if (den < 1e-7 || Math.abs(num) < 1e-7) return { kappa: 0, radius: Infinity, center: null };
        var kappa = num / den;
        var radius = 1.0 / Math.abs(kappa);
        var speed = Math.sqrt(speedSq);
        var nx = -d1[1] / speed, ny = d1[0] / speed;
        var pt = this.evaluate(p0, p1, p2, p3, t);
        var sign = kappa >= 0 ? 1.0 : -1.0;
        return { kappa: kappa, radius: radius, center: [pt[0] + sign * nx * radius, pt[1] + sign * ny * radius] };
    },
    isLinear: function(p0, p1, p2, p3, tol) {
        var threshold = tol || 0.5;
        var dx = p3[0] - p0[0], dy = p3[1] - p0[1];
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-5) return true;
        var dist1 = Math.abs((p1[1] - p0[1]) * dx - (p1[0] - p0[0]) * dy) / len;
        var dist2 = Math.abs((p2[1] - p0[1]) * dx - (p2[0] - p0[0]) * dy) / len;
        return (dist1 <= threshold && dist2 <= threshold);
    },
    detectArc: function(p0, p1, p2, p3, thresholdError) {
        if (this.isLinear(p0, p1, p2, p3, 1.0)) return null;
        // Base tolerance scaled by complexity (-30..+30)
        // thresholdError: -30 (strict/low) -> 0.04, 0 (default) -> 0.10, +30 (loose/high) -> 0.25
        var baseTol = 0.10 + (thresholdError || 0) * 0.0035;
        if (baseTol < 0.03) baseTol = 0.03;
        if (baseTol > 0.35) baseTol = 0.35;

        var c1 = this.curvature(p0, p1, p2, p3, 0.25);
        var c2 = this.curvature(p0, p1, p2, p3, 0.50);
        var c3 = this.curvature(p0, p1, p2, p3, 0.75);
        if (!c1.center || !c2.center || !c3.center) return null;
        var avgR = (c1.radius + c2.radius + c3.radius) / 3.0;
        if (avgR < 6.0 || avgR > 4000.0) return null;

        var maxDev = Math.max(Math.abs(c1.radius - avgR), Math.abs(c2.radius - avgR), Math.abs(c3.radius - avgR)) / avgR;
        var avgCenterX = (c1.center[0] + c2.center[0] + c3.center[0]) / 3.0;
        var avgCenterY = (c1.center[1] + c2.center[1] + c3.center[1]) / 3.0;
        var centerDev = Math.max(
            Vector2D.dist(c1.center, [avgCenterX, avgCenterY]),
            Vector2D.dist(c2.center, [avgCenterX, avgCenterY]),
            Vector2D.dist(c3.center, [avgCenterX, avgCenterY])
        ) / avgR;

        if (maxDev <= baseTol && centerDev <= baseTol * 1.8) {
            var chord = Vector2D.dist(p0, p3);
            return { center: [avgCenterX, avgCenterY], radius: avgR, length: chord };
        }
        return null;
    },
    solveQuadratic: function(a, b, c) {
        var roots = [];
        if (Math.abs(a) < 1e-7) {
            if (Math.abs(b) >= 1e-7) {
                var t = -c / b;
                if (t >= 0.0 && t <= 1.0) roots.push(t);
            }
            return roots;
        }
        var disc = b * b - 4.0 * a * c;
        if (disc >= 0) {
            var sqrtD = Math.sqrt(disc);
            var t1 = (-b + sqrtD) / (2.0 * a), t2 = (-b - sqrtD) / (2.0 * a);
            if (t1 >= 0.0 && t1 <= 1.0) roots.push(t1);
            if (t2 >= 0.0 && t2 <= 1.0 && Math.abs(t2 - t1) > 1e-4) roots.push(t2);
        }
        return roots;
    },
    findExtrema: function(p0, p1, p2, p3) {
        var ax = 3.0 * (p3[0] - 3.0 * p2[0] + 3.0 * p1[0] - p0[0]);
        var bx = 6.0 * (p2[0] - 2.0 * p1[0] + p0[0]);
        var cx = 3.0 * (p1[0] - p0[0]);
        var xRoots = this.solveQuadratic(ax, bx, cx);

        var ay = 3.0 * (p3[1] - 3.0 * p2[1] + 3.0 * p1[1] - p0[1]);
        var by = 6.0 * (p2[1] - 2.0 * p1[1] + p0[1]);
        var cy = 3.0 * (p1[1] - p0[1]);
        var yRoots = this.solveQuadratic(ay, by, cy);

        var extrema = [];
        for (var i = 0; i < xRoots.length; i++) {
            extrema.push({ t: xRoots[i], pt: this.evaluate(p0, p1, p2, p3, xRoots[i]), type: "vertical_tangent" });
        }
        for (var j = 0; j < yRoots.length; j++) {
            extrema.push({ t: yRoots[j], pt: this.evaluate(p0, p1, p2, p3, yRoots[j]), type: "horizontal_tangent" });
        }
        return extrema;
    }
};

// =================== Geometry Extractors ===================
var GeometryUtils = {
    extractPaths: function(items) {
        var paths = [];
        if (!items || items.length === 0) return paths;
        for (var i = 0; i < items.length; i++) {
            this._collectPaths(items[i], paths);
        }
        return paths;
    },
    _collectPaths: function(item, paths) {
        if (!item) return;
        if (item.typename === "PathItem") {
            paths.push(item);
        } else if (item.typename === "CompoundPathItem") {
            for (var j = 0; j < item.pathItems.length; j++) paths.push(item.pathItems[j]);
        } else if (item.typename === "GroupItem") {
            for (var k = 0; k < item.pageItems.length; k++) this._collectPaths(item.pageItems[k], paths);
        }
    },
    getSelectionBounds: function(items) {
        if (!items || items.length === 0) return [0, 0, 0, 0];
        var top = -Infinity, left = Infinity, bottom = Infinity, right = -Infinity;
        for (var i = 0; i < items.length; i++) {
            var b = items[i].geometricBounds;
            if (b[0] > top) top = b[0];
            if (b[1] < left) left = b[1];
            if (b[2] < bottom) bottom = b[2];
            if (b[3] > right) right = b[3];
        }
        return [top, left, bottom, right];
    },
    getArtboardBounds: function(doc) {
        var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()];
        var r = ab.artboardRect;
        return [r[1], r[0], r[3], r[2]];
    }
};

// =================== Color Utilities ===================
var ColorUtils = {
    parseColor: function(doc, colVal) {
        if (!colVal || colVal === "none" || (colVal instanceof Array && colVal.length === 0)) {
            return null; // Transparent / No color
        }
        if (typeof colVal === "string" && colVal.charAt(0) === "#") {
            var hex = colVal.substring(1);
            var num = parseInt(hex, 16);
            var r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
            return this.rgbColor(doc, [r, g, b]);
        }
        if (colVal instanceof Array) {
            if (colVal.length === 3) return this.rgbColor(doc, colVal);
            if (colVal.length === 4) {
                // If sum is <= 4, assume normalized 0..1, otherwise 0..100
                var c = new CMYKColor();
                c.cyan = (colVal[0] <= 1 && colVal[1] <= 1 && colVal[2] <= 1 && colVal[3] <= 1) ? colVal[0]*100 : colVal[0];
                c.magenta = (colVal[1] <= 1 && colVal[2] <= 1 && colVal[3] <= 1) ? colVal[1]*100 : colVal[1];
                c.yellow = (colVal[2] <= 1 && colVal[3] <= 1) ? colVal[2]*100 : colVal[2];
                c.black = (colVal[3] <= 1) ? colVal[3]*100 : colVal[3];
                return c;
            }
        }
        return this.rgbColor(doc, [0, 210, 255]);
    },
    rgbColor: function(doc, rgbArr) {
        var r = rgbArr[0], g = rgbArr[1], b = rgbArr[2];
        if (doc && doc.documentColorSpace === DocumentColorSpace.CMYK) {
            var cmyk = new CMYKColor();
            var rN = r / 255.0, gN = g / 255.0, bN = b / 255.0;
            var k = 1.0 - Math.max(rN, Math.max(gN, bN));
            if (k < 1.0) {
                cmyk.cyan = Math.round(((1.0 - rN - k) / (1.0 - k)) * 100);
                cmyk.magenta = Math.round(((1.0 - gN - k) / (1.0 - k)) * 100);
                cmyk.yellow = Math.round(((1.0 - bN - k) / (1.0 - k)) * 100);
                cmyk.black = Math.round(k * 100);
            } else {
                cmyk.cyan = 0; cmyk.magenta = 0; cmyk.yellow = 0; cmyk.black = 100;
            }
            return cmyk;
        } else {
            var rgb = new RGBColor();
            rgb.red = r; rgb.green = g; rgb.blue = b;
            return rgb;
        }
    }
};

// =================== Layer Manager ===================
var LayerManager = {
    getRootLayer: function(doc) {
        var rootName = LGS_CONSTANTS.ROOT_LAYER_NAME;
        var layer;
        try {
            layer = doc.layers.getByName(rootName);
            layer.visible = true; layer.locked = false;
        } catch (e) {
            layer = doc.layers.add();
            layer.name = rootName;
            layer.zOrder(ZOrderMethod.BRINGTOFRONT);
        }
        return layer;
    },
    getModuleLayer: function(doc, moduleName) {
        var root = this.getRootLayer(doc);
        var sub;
        try {
            sub = root.layers.getByName(moduleName);
            sub.visible = true; sub.locked = false;
        } catch (e) {
            sub = root.layers.add();
            sub.name = moduleName;
        }
        return sub;
    },
    clearLayer: function(layer) {
        if (!layer) return;
        for (var i = layer.pageItems.length - 1; i >= 0; i--) layer.pageItems[i].remove();
        for (var j = layer.layers.length - 1; j >= 0; j--) layer.layers[j].remove();
    }
};

// =================== 1. Logo Grid Generator (LGG) ===================
var LogoGridGenerator = {
    generate: function(doc, targetItems, opts, activePills) {
        var paths = GeometryUtils.extractPaths(targetItems);
        if (paths.length === 0) return "Please select your logo vector artwork.";

        var moduleLayer = LayerManager.getModuleLayer(doc, "_Logo_Grid");
        LayerManager.clearLayer(moduleLayer);

        var bounds = GeometryUtils.getSelectionBounds(targetItems);
        var pad = 90.0;
        var extBounds = [bounds[0] + pad, bounds[1] - pad, bounds[2] - pad, bounds[3] + pad];

        // Active component flags
        var doAnchors = !activePills || activePills.Anchors !== false;
        var doHandles = !activePills || activePills.Handles !== false;
        var doOutlines = !activePills || activePills.Outlines !== false;
        var doGridlines = !activePills || activePills.Gridlines !== false;
        var doCircles = opts.circular_trajectories && opts.circular_trajectories.enabled;

        // Customizer styles
        var aFill = ColorUtils.parseColor(doc, opts.anchors.fill);
        var aStroke = ColorUtils.parseColor(doc, opts.anchors.stroke.color);
        var aSize = opts.anchors.size || 6.0;
        var aStrokeW = opts.anchors.stroke.width || 1.0;

        var hFill = ColorUtils.parseColor(doc, opts.handles.fill);
        var hStroke = ColorUtils.parseColor(doc, opts.handles.stroke.color);
        var hSize = opts.handles.size || 5.0;
        var hStrokeW = opts.handles.stroke.width || 1.0;

        var oFill = ColorUtils.parseColor(doc, opts.outlines.fill);
        var oStroke = ColorUtils.parseColor(doc, opts.outlines.stroke.color);
        var oStrokeW = opts.outlines.stroke.width || 1.0;

        var gStroke = ColorUtils.parseColor(doc, opts.gridlines.stroke.color);
        var gStrokeW = opts.gridlines.stroke.width || 0.5;
        var gLevel = opts.gridlines_level || 1;

        var detectedArcs = [];

        for (var i = 0; i < paths.length; i++) {
            var path = paths[i];
            var pts = path.pathPoints;
            if (!pts || pts.length === 0) continue;

            // 1. Outlines
            if (doOutlines && (oFill || oStroke)) {
                var clone = path.duplicate(moduleLayer, ElementPlacement.PLACEATEND);
                clone.filled = (oFill !== null);
                if (oFill) clone.fillColor = oFill;
                clone.stroked = (oStroke !== null);
                if (oStroke) { clone.strokeColor = oStroke; clone.strokeWidth = oStrokeW; }
            }

            // 2. Anchors & Handles
            for (var j = 0; j < pts.length; j++) {
                var pt = pts[j];
                var anchor = pt.anchor;

                if (doAnchors) {
                    var aItem = moduleLayer.pathItems.rectangle(anchor[1] + aSize/2, anchor[0] - aSize/2, aSize, aSize);
                    aItem.filled = (aFill !== null);
                    if (aFill) aItem.fillColor = aFill;
                    aItem.stroked = (aStroke !== null);
                    if (aStroke) { aItem.strokeColor = aStroke; aItem.strokeWidth = aStrokeW; }
                }

                if (doHandles) {
                    if (Vector2D.distSq(pt.leftDirection, anchor) > 1.0) {
                        this._drawHandle(moduleLayer, anchor, pt.leftDirection, hFill, hStroke, hStrokeW, hSize);
                    }
                    if (Vector2D.distSq(pt.rightDirection, anchor) > 1.0) {
                        this._drawHandle(moduleLayer, anchor, pt.rightDirection, hFill, hStroke, hStrokeW, hSize);
                    }
                }
            }

            // 3. Gridlines
            if (doGridlines && gStroke) {
                this._drawGridlines(moduleLayer, path, extBounds, gLevel, gStroke, gStrokeW);
            }

            // 4. Circular Arcs
            if (doCircles) {
                var cErr = (opts.circular_trajectories && opts.circular_trajectories.thresholdError) || 0;
                for (var j2 = 0; j2 < pts.length; j2++) {
                    var nextIdx = (j2 + 1) % pts.length;
                    if (!path.closed && j2 === pts.length - 1) break;
                    var arc = BezierMath.detectArc(pts[j2].anchor, pts[j2].rightDirection, pts[nextIdx].leftDirection, pts[nextIdx].anchor, cErr);
                    if (arc && arc.center) detectedArcs.push(arc);
                }
            }
        }

        // Render Circular Trajectories
        if (doCircles && detectedArcs.length > 0) {
            var cOpt = (opts.circular_trajectories.NumberCirTraj && opts.circular_trajectories.NumberCirTraj.option) || "All";
            var cNum = (opts.circular_trajectories.NumberCirTraj && opts.circular_trajectories.NumberCirTraj.number) || 5;

            if (cOpt === "Number of sorted circles") {
                detectedArcs.sort(function(a, b) { return b.length - a.length; });
            }
            var limit = (cOpt === "All") ? detectedArcs.length : Math.min(cNum, detectedArcs.length);
            for (var ca = 0; ca < limit; ca++) {
                var arcItem = detectedArcs[ca];
                var circlePath = moduleLayer.pathItems.ellipse(arcItem.center[1] + arcItem.radius, arcItem.center[0] - arcItem.radius, arcItem.radius * 2.0, arcItem.radius * 2.0);
                circlePath.filled = false;
                circlePath.stroked = true;
                circlePath.strokeWidth = gStrokeW;
                circlePath.strokeColor = gStroke || ColorUtils.rgbColor(doc, [0, 210, 255]);
                circlePath.strokeDashes = [4, 4];
            }
        }

        return "Generated Logo Grids for " + paths.length + " paths.";
    },

    _drawHandle: function(layer, anchor, handlePt, fill, stroke, strokeW, size) {
        var line = layer.pathItems.add();
        line.setEntirePath([anchor, handlePt]);
        line.stroked = (stroke !== null);
        line.filled = false;
        if (stroke) { line.strokeColor = stroke; line.strokeWidth = strokeW; }

        var tip = layer.pathItems.ellipse(handlePt[1] + size/2, handlePt[0] - size/2, size, size);
        tip.filled = (fill !== null);
        if (fill) tip.fillColor = fill;
        tip.stroked = (stroke !== null);
        if (stroke) { tip.strokeColor = stroke; tip.strokeWidth = strokeW; }
    },

    _drawGridlines: function(layer, path, extBounds, level, stroke, strokeW) {
        var pts = path.pathPoints;
        var renderedY = [], renderedX = [];
        for (var i = 0; i < pts.length; i++) {
            var anchor = pts[i].anchor;
            var hasX = false, hasY = false;
            for (var k = 0; k < renderedX.length; k++) { if (Math.abs(renderedX[k] - anchor[0]) < 1.5) { hasX = true; break; } }
            for (var m = 0; m < renderedY.length; m++) { if (Math.abs(renderedY[m] - anchor[1]) < 1.5) { hasY = true; break; } }

            if (!hasY) {
                var h = layer.pathItems.add();
                h.setEntirePath([[extBounds[1], anchor[1]], [extBounds[3], anchor[1]]]);
                h.stroked = true; h.filled = false; h.strokeWidth = strokeW; h.strokeColor = stroke;
                renderedY.push(anchor[1]);
            }
            if (!hasX) {
                var v = layer.pathItems.add();
                v.setEntirePath([[anchor[0], extBounds[0]], [anchor[0], extBounds[2]]]);
                v.stroked = true; v.filled = false; v.strokeWidth = strokeW; v.strokeColor = stroke;
                renderedX.push(anchor[0]);
            }
            if (level >= 2 && pts.length > 1) {
                var nextIdx = (i + 1) % pts.length;
                if (path.closed || i < pts.length - 1) {
                    var extrema = BezierMath.findExtrema(pts[i].anchor, pts[i].rightDirection, pts[nextIdx].leftDirection, pts[nextIdx].anchor);
                    for (var e = 0; e < extrema.length; e++) {
                        var ePt = extrema[e].pt;
                        var eh = layer.pathItems.add();
                        if (extrema[e].type === "horizontal_tangent") {
                            eh.setEntirePath([[extBounds[1], ePt[1]], [extBounds[3], ePt[1]]]);
                        } else {
                            eh.setEntirePath([[ePt[0], extBounds[0]], [ePt[0], extBounds[2]]]);
                        }
                        eh.stroked = true; eh.filled = false; eh.strokeWidth = strokeW; eh.strokeColor = stroke;
                    }
                }
            }
        }
    }
};

// =================== 2. Base Grid Generator (BGG) ===================
var BaseGridGenerator = {
    generate: function(doc, opts, asGuides) {
        var moduleLayer = LayerManager.getModuleLayer(doc, "_Base_Grid");
        LayerManager.clearLayer(moduleLayer);

        var bounds;
        if (doc.selection && doc.selection.length > 0) {
            bounds = GeometryUtils.getSelectionBounds(doc.selection);
            var pad = 60.0;
            bounds = [bounds[0] + pad, bounds[1] - pad, bounds[2] - pad, bounds[3] + pad];
        } else {
            bounds = GeometryUtils.getArtboardBounds(doc);
        }

        var gridType = opts.gridType || "Square";
        var s = opts.sideLength || 190.0;
        var color = ColorUtils.rgbColor(doc, [0, 180, 240]);
        var gGroup = moduleLayer.groupItems.add();

        if (gridType === "Square") {
            var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
            for (var x = left; x <= right; x += s) {
                var vl = gGroup.pathItems.add();
                vl.setEntirePath([[x, top], [x, bottom]]);
                vl.stroked = true; vl.filled = false; vl.strokeWidth = 0.5; vl.strokeColor = color;
                if (asGuides) vl.guides = true;
            }
            for (var y = bottom; y <= top; y += s) {
                var hl = gGroup.pathItems.add();
                hl.setEntirePath([[left, y], [right, y]]);
                hl.stroked = true; hl.filled = false; hl.strokeWidth = 0.5; hl.strokeColor = color;
                if (asGuides) hl.guides = true;
            }
        } else if (gridType === "Isometric") {
            var t = bounds[0], l = bounds[1], b = bounds[2], r = bounds[3], h = t - b;
            for (var vx = l; vx <= r; vx += s) {
                var v = gGroup.pathItems.add();
                v.setEntirePath([[vx, t], [vx, b]]);
                v.stroked = true; v.filled = false; v.strokeWidth = 0.5; v.strokeColor = color;
                if (asGuides) v.guides = true;
            }
            var tan30 = 0.577350269;
            var dStep = s / (tan30 * 2.0);
            for (var d = l - h * 2; d <= r + h * 2; d += dStep) {
                var d1 = gGroup.pathItems.add();
                d1.setEntirePath([[d, b], [d + h / tan30, t]]);
                d1.stroked = true; d1.filled = false; d1.strokeWidth = 0.5; d1.strokeColor = color;
                if (asGuides) d1.guides = true;

                var d2 = gGroup.pathItems.add();
                d2.setEntirePath([[d, t], [d + h / tan30, b]]);
                d2.stroked = true; d2.filled = false; d2.strokeWidth = 0.5; d2.strokeColor = color;
                if (asGuides) d2.guides = true;
            }
        } else if (gridType === "Hexagon") {
            var hR = s / 2.0, hW = Math.sqrt(3) * hR, hH = 1.5 * hR;
            var row = 0;
            for (var hy = bounds[0]; hy >= bounds[2] - hR; hy -= hH) {
                var xOff = (row % 2 === 1) ? (hW / 2.0) : 0.0;
                for (var hx = bounds[1] + xOff; hx <= bounds[3] + hW; hx += hW) {
                    var hex = gGroup.pathItems.add();
                    var hPts = [];
                    for (var a = 0; a < 6; a++) {
                        var radA = (Math.PI / 180.0) * (60.0 * a + 30.0);
                        hPts.push([hx + hR * Math.cos(radA), hy + hR * Math.sin(radA)]);
                    }
                    hex.setEntirePath(hPts);
                    hex.closed = true; hex.stroked = true; hex.filled = false; hex.strokeWidth = 0.5; hex.strokeColor = color;
                    if (asGuides) hex.guides = true;
                }
                row++;
            }
        } else if (gridType === "GoldenRt") {
            var phi = 1.6180339887;
            var cX = (bounds[1] + bounds[3]) / 2.0, cY = (bounds[0] + bounds[2]) / 2.0;
            var mG = opts.marginGolden || 10.0;
            var radii = [s / (phi*phi), s / phi, s, s * phi];
            for (var ri = 0; ri < radii.length; ri++) {
                var rad = radii[ri];
                var gc = gGroup.pathItems.ellipse(cY + rad, cX - rad, rad * 2.0, rad * 2.0);
                gc.filled = false; gc.stroked = true; gc.strokeWidth = 0.5; gc.strokeColor = color;
                if (asGuides) gc.guides = true;
            }
            var gRect = gGroup.pathItems.rectangle(cY + (s*phi)/2 + mG, cX - (s*phi*phi)/2 - mG, s*phi*phi + mG*2, s*phi + mG*2);
            gRect.filled = false; gRect.stroked = true; gRect.strokeWidth = 0.5; gRect.strokeColor = color;
            if (asGuides) gRect.guides = true;
        }

        return "Generated " + gridType + " Base Grid.";
    }
};

// =================== 3. Clearspace Grid Generator (CGG) ===================
var ClearspaceGridGenerator = {
    generate: function(doc, targetItems, opts) {
        if (!targetItems || targetItems.length === 0) return "Please select artwork.";

        var moduleLayer = LayerManager.getModuleLayer(doc, "_Clearspace_Grid");
        LayerManager.clearLayer(moduleLayer);

        var bounds = GeometryUtils.getSelectionBounds(targetItems);
        var top = bounds[0], left = bounds[1], bottom = bounds[2], right = bounds[3];
        var width = right - left, height = top - bottom;

        var unit = opts.unitExclusionZone || "px";
        var val = opts.valueExclusionZone || 60;
        var margin = 60.0;

        if (unit === "lg") {
            if (targetItems.length > 1) {
                var primary = (opts.invertComponents === true) ? targetItems[targetItems.length - 1] : targetItems[0];
                var pb = primary.geometricBounds;
                margin = (pb[0] - pb[2]); // height of logomark
            } else {
                margin = height * 0.3;
            }
        } else if (unit === "cm") {
            margin = val * 28.3465;
        } else if (unit === "in") {
            margin = val * 72.0;
        } else {
            margin = val; // px/pt
        }

        var outTop = top + margin, outLeft = left - margin;
        var outWidth = width + (margin * 2.0), outHeight = height + (margin * 2.0);
        var boxColor = ColorUtils.rgbColor(doc, [0, 210, 255]);

        var outerRect = moduleLayer.pathItems.rectangle(outTop, outLeft, outWidth, outHeight);
        outerRect.filled = false; outerRect.stroked = true; outerRect.strokeWidth = 0.75;
        outerRect.strokeColor = boxColor; outerRect.strokeDashes = [5, 4];

        var innerRect = moduleLayer.pathItems.rectangle(top, left, width, height);
        innerRect.filled = false; innerRect.stroked = true; innerRect.strokeWidth = 0.35;
        innerRect.strokeColor = boxColor; innerRect.strokeDashes = [2, 2];

        // Dimension leader lines
        this._drawDim(moduleLayer, [left, top + margin], [left, top], "X", "vertical", boxColor);
        this._drawDim(moduleLayer, [left - margin, top], [left, top], "X", "horizontal", boxColor);
        this._drawDim(moduleLayer, [right, top], [right + margin, top], "X", "horizontal", boxColor);
        this._drawDim(moduleLayer, [left, bottom], [left, bottom - margin], "X", "vertical", boxColor);

        return "Generated Clearspace Grid (" + margin.toFixed(1) + "pt margin).";
    },

    _drawDim: function(layer, pStart, pEnd, labelText, orientation, color) {
        var line = layer.pathItems.add();
        line.setEntirePath([pStart, pEnd]);
        line.stroked = true; line.filled = false; line.strokeWidth = 0.5; line.strokeColor = color;
        var tick = 4.0;
        if (orientation === "horizontal") {
            var t1 = layer.pathItems.add(); t1.setEntirePath([[pStart[0], pStart[1] + tick], [pStart[0], pStart[1] - tick]]);
            t1.stroked = true; t1.strokeWidth = 0.5; t1.strokeColor = color;
            var t2 = layer.pathItems.add(); t2.setEntirePath([[pEnd[0], pEnd[1] + tick], [pEnd[0], pEnd[1] - tick]]);
            t2.stroked = true; t2.strokeWidth = 0.5; t2.strokeColor = color;
        } else {
            var t3 = layer.pathItems.add(); t3.setEntirePath([[pStart[0] - tick, pStart[1]], [pStart[0] + tick, pStart[1]]]);
            t3.stroked = true; t3.strokeWidth = 0.5; t3.strokeColor = color;
            var t4 = layer.pathItems.add(); t4.setEntirePath([[pEnd[0] - tick, pEnd[1]], [pEnd[0] + tick, pEnd[1]]]);
            t4.stroked = true; t4.strokeWidth = 0.5; t4.strokeColor = color;
        }
        try {
            var tf = layer.textFrames.add();
            tf.contents = labelText;
            tf.position = [(pStart[0] + pEnd[0]) / 2.0 - 3.0, (pStart[1] + pEnd[1]) / 2.0 + 4.0];
            tf.textRange.characterAttributes.size = 8.0;
            tf.textRange.characterAttributes.fillColor = color;
        } catch (e) {}
    }
};

// =================== Master Bridge ===================
$.global.LGS_Bridge = {
    getSelectionStatus: function() {
        if (app.documents.length === 0) return LGS_JSON.stringify({ doc: false, count: 0 });
        var sel = app.activeDocument.selection;
        return LGS_JSON.stringify({ doc: true, count: sel ? sel.length : 0 });
    },

    executeAction: function(actionName, encodedJson) {
        if (app.documents.length === 0) {
            return LGS_JSON.stringify({ success: false, error: "No active document open in Illustrator." });
        }
        try {
            app.coordinateSystem = CoordinateSystem.ARTBOARDCOORDINATESYSTEM;
            var doc = app.activeDocument;
            var payload = LGS_JSON.parse(encodedJson);
            var msg = "";

            if (actionName === "generateLGG") {
                msg = LogoGridGenerator.generate(doc, doc.selection, payload.options, payload.activePills);
            } else if (actionName === "generateAllLGG") {
                msg = LogoGridGenerator.generate(doc, doc.selection, payload.options, { Anchors: true, Handles: true, Outlines: true, Gridlines: true });
            } else if (actionName === "generateBGG") {
                msg = BaseGridGenerator.generate(doc, payload.options, false);
            } else if (actionName === "makeGuideBGG") {
                msg = BaseGridGenerator.generate(doc, payload.options, true);
            } else if (actionName === "generateCGG") {
                msg = ClearspaceGridGenerator.generate(doc, doc.selection, payload.options);
            } else if (actionName === "clearGridSystem") {
                try {
                    var root = doc.layers.getByName(LGS_CONSTANTS.ROOT_LAYER_NAME);
                    root.remove();
                    msg = "Grid layer cleared.";
                } catch (e) {
                    msg = "No grid layer found.";
                }
            } else {
                return LGS_JSON.stringify({ success: false, error: "Unknown action: " + actionName });
            }

            app.redraw();
            return LGS_JSON.stringify({ success: true, message: msg });
        } catch (err) {
            return LGS_JSON.stringify({ success: false, error: err.message || String(err), line: err.line || 0 });
        }
    }
};
